"""
Compresses chat attachments before upload — keeps things fast on slow
school wifi/data without a visible quality hit for images. Every function
degrades safely: if a needed tool/library is missing, it returns the
original file untouched rather than failing the send.
"""
import os
import shutil
import subprocess
import uuid
from pathlib import Path

CACHE_DIR = Path(__file__).resolve().parent.parent / "data" / "chat_media_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp"}
VIDEO_EXTS = {".mp4", ".mov", ".avi", ".mkv", ".webm"}

MAX_IMAGE_DIMENSION = 1600
IMAGE_QUALITY = 72
MAX_VIDEO_MB_UNCOMPRESSED = 25  # hard cap when ffmpeg isn't available to shrink it


def classify(path: str) -> str | None:
    ext = Path(path).suffix.lower()
    if ext in IMAGE_EXTS:
        return "image"
    if ext in VIDEO_EXTS:
        return "video"
    return None


def _unique_name(ext: str) -> str:
    return f"{uuid.uuid4().hex}{ext}"


def compress_image(src_path: str) -> tuple[str, int] | None:
    """Resizes/re-encodes to JPEG, keeping it visually close to the
    original at a fraction of the size. Returns (output_path, size_kb)."""
    try:
        from PIL import Image
    except ImportError:
        # Pillow not available — fall back to sending the original as-is.
        size_kb = os.path.getsize(src_path) // 1024
        return src_path, size_kb

    try:
        img = Image.open(src_path)
        img = img.convert("RGB") if img.mode not in ("RGB", "L") else img
        w, h = img.size
        scale = min(1.0, MAX_IMAGE_DIMENSION / max(w, h))
        if scale < 1.0:
            img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
        out_path = CACHE_DIR / _unique_name(".jpg")
        img.save(out_path, "JPEG", quality=IMAGE_QUALITY, optimize=True)
        return str(out_path), os.path.getsize(out_path) // 1024
    except Exception:
        size_kb = os.path.getsize(src_path) // 1024
        return src_path, size_kb


def compress_video(src_path: str) -> tuple[str, int] | None:
    """Best effort: re-encodes with ffmpeg if it's on PATH (smaller file,
    same look). Without ffmpeg installed, sends the original untouched as
    long as it's under the size cap — large uncompressed clips are
    rejected with a clear message instead of choking a slow connection."""
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg is None:
        size_mb = os.path.getsize(src_path) / (1024 * 1024)
        if size_mb > MAX_VIDEO_MB_UNCOMPRESSED:
            return None
        return src_path, int(size_mb * 1024)

    out_path = CACHE_DIR / _unique_name(".mp4")
    try:
        subprocess.run(
            [ffmpeg, "-y", "-i", str(src_path),
             "-vcodec", "libx264", "-crf", "28", "-preset", "veryfast",
             "-vf", "scale='min(1280,iw)':-2",
             "-acodec", "aac", "-b:a", "96k",
             str(out_path)],
            check=True, capture_output=True, timeout=180,
        )
        return str(out_path), os.path.getsize(out_path) // 1024
    except Exception:
        size_mb = os.path.getsize(src_path) / (1024 * 1024)
        if size_mb > MAX_VIDEO_MB_UNCOMPRESSED:
            return None
        return src_path, int(size_mb * 1024)


def prepare_attachment(src_path: str):
    """Returns (local_compressed_path, kind, size_kb) or (None, None, None)
    if the file type isn't supported or a video is too large to send."""
    kind = classify(src_path)
    if kind == "image":
        result = compress_image(src_path)
    elif kind == "video":
        result = compress_video(src_path)
    else:
        return None, None, None
    if result is None:
        return None, kind, None
    path, kb = result
    return path, kind, kb


def cache_path_for(url: str) -> Path:
    import hashlib
    ext = Path(url.split("?")[0]).suffix or ".bin"
    digest = hashlib.sha1(url.encode()).hexdigest()
    return CACHE_DIR / f"{digest}{ext}"
