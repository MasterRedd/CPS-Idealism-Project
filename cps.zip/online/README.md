# CPS Online Features (Chat, Boarding, Global MCAT)

This folder holds everything needed to connect CPS to a **free Supabase
project** — a hosted backend (database + realtime + file storage) that you
don't have to run or pay for at this scale. Nothing here is required for
the app's core day-to-day use (Students, Officers, Patrols, Incidents,
Reports); those keep working fully offline exactly as before.

## One-time setup (you do this, ~5 minutes)

1. Go to https://supabase.com → sign up (free) → **New Project**.
   Pick any name/region and a database password (save it somewhere safe —
   you likely won't need it again, but Supabase asks for it once).
2. Wait ~2 minutes for the project to finish provisioning.
3. Left sidebar → **SQL Editor** → **New query** → paste the entire
   contents of `supabase_schema.sql` from this folder → **Run**.
   This creates the tables for the MCAT registry, Chat, and Boarding.
4. Left sidebar → **Project Settings → API**. Copy:
   - **Project URL**
   - **anon public** key (NOT the `service_role` key — that one must
     never be shipped inside the app)
5. Left sidebar → **Storage** → **New bucket** → name it exactly
   `chat-media` → mark it **Public** → Create. This is where attached
   chat photos/videos live. (Required for Chat; skip if you only want
   the MCAT registry for now.)
6. In CPS: **Settings → Online** (admin only) → paste the URL/key →
   **Save & Test Connection**. This writes them to
   `online/credentials.local.json` on this device only.

Each device you install CPS on repeats step 6 with the same URL/key.

## What's built so far (Phase 1 — foundation)

- `config.py` — loads/saves your Supabase URL + key locally.
- `supabase_client.py` — a wrapper that talks to Supabase for the
  global MCAT registry (so `MCAT-59` really is the 59th admin account
  ever created, across every device, not just this one) and basic
  online/offline presence. Every method fails *safely* — if there's no
  internet, or Supabase hasn't been configured yet, the app falls back
  to the same local-only MCAT numbering it already had. This module is
  wired up but genuinely needs testing against a real Supabase project,
  which nobody could do inside the sandbox this was built in — there's
  no internet access there.

## What's built so far (Phase 2 — Chat)

- New **Chat** sidebar item (any account tied to an MCAT — hidden for the
  Creator view, which isn't tied to one). Two thread types:
  - **🌐 Global** — everyone under your Management Code, group-chat style.
  - **💬 Personal** — direct 1:1, pick anyone from the contact list on
    the left (administrator + every officer under the same MCAT).
- **Offline-first sending.** Every message is written to a local
  `chat_outbox` table in SQLite the instant you hit Send, then a
  background timer (every ~4s) tries to deliver it to Supabase. No
  internet yet? It just sits there marked "Waiting for internet..." —
  you can hit "Cancel send" on it any time before it goes out, and once
  cancelled it will never be sent.
- **Photos & videos.** The attach button compresses images (resized +
  re-encoded JPEG via Pillow) and videos (re-encoded via `ffmpeg` if it's
  installed on the machine — otherwise sent as-is, up to a 25MB cap,
  since without `ffmpeg` there's no safe way to shrink video locally)
  before upload, so a slow school connection isn't sending
  full-resolution originals. Received media downloads once and is
  cached in `data/chat_media_cache/`, so it's viewable offline
  afterward. Photos open in the app's own zoomable evidence viewer;
  videos open in your system's default video player (a full in-app
  video player is future scope, not built here).
- **Not real-time push.** Refresh happens by polling Supabase every few
  seconds, not a live WebSocket subscription — simpler to reason about
  and good enough for a chat app at this scale, at the cost of a few
  seconds' delay instead of instant delivery.

Untested against a live project: this sandbox has no internet access, so
`send_message` / `fetch_messages` / `upload_attachment` are correct on
paper (and the offline-outbox logic is tested for real, since that part
is pure SQLite) but the actual round trip to Supabase needs to be
verified on your machine, with two accounts under the same MCAT, once
you've created the `chat-media` bucket above.

## Bug fix — photo/video attachments failed to send (fixed)

If attaching a photo or video always failed (text-only messages worked
fine), **re-run `supabase_schema.sql` again** — the fix is a new storage
policy near the bottom of the file. Root cause: marking the `chat-media`
bucket **Public** in the dashboard only allows *reading* files without
auth — it does not grant permission to *upload*. Supabase Storage keeps
its own separate RLS on `storage.objects`, and without an explicit policy
there, every upload from the anon key was silently rejected. This also
fixes avatar photo uploads (below), which use the same bucket/policy.

## New — profile photos, reply, edit, delete, pin, react, forward

- **Avatars.** If an account has a profile photo set (Officer/Administrator
  photo), it's uploaded once per session to Storage (under an `avatars/`
  path in the same `chat-media` bucket) and shown next to that person's
  messages in Global Chat — this is what makes it visible on *other*
  devices too, not just the one the original photo file lives on.
  Accounts without a photo get a colored initial-letter avatar instead.
- **Reply.** The `⋯` menu on any sent message → Reply. A quoted preview
  of the original appears above your new message; clicking that quote
  jumps back to (and briefly highlights) the original — as long as it's
  still within the currently loaded ~300-message window for that thread.
- **Edit.** Your own messages only, and only within 3 minutes of sending
  — the option disappears from the menu after that. Edited messages show
  a small "· edited" tag.
- **Delete.** Your own messages, any time — replaced with "This message
  was deleted" for everyone (a soft delete, so reply-quotes pointing at
  it don't break).
- **Pin.** Any message can be pinned/unpinned from the `⋯` menu. A
  "📌 Pinned (N)" button appears in the thread header whenever there's
  at least one; it opens a scrollable list (newest first) with a "View"
  button per item that jumps straight to it in the thread.
- **React.** `⋯` → React → pick an emoji. Reactions show as small chips
  under the message with a live count; tapping a chip you've already
  reacted with removes it, same as Messenger/WhatsApp.
- **Forward.** `⋯` → Forward opens a picker (Global Chat + every contact
  under your Management Code, multi-select). The forwarded copy shows a
  small "↪ Forwarded message" tag but never reveals who it originally
  came from, exactly as asked. Already-uploaded photos/videos are
  reused directly (no re-upload needed) — this also works offline, since
  the forward is queued in the same outbox as a normal message.

Honest scope note on reactions specifically: they're implemented as a
read-then-write on the message row (fetch current reactions, toggle,
save), not an atomic database counter. Two people tapping the exact same
emoji on the exact same message in the same instant could rarely clobber
each other — an acceptable trade-off against the much larger complexity
of a proper atomic increment function, for how lightly this gets used.

## Bug fix — Chat send/receive was completely broken (fixed)

If you set this up before today, **re-run the entire `supabase_schema.sql`
file again** in the SQL Editor (it's safe to re-run — every `create
table`/`create policy` is written to not fail on a second run). Three real
bugs were found and fixed:

1. **RLS was silently blocking every send and read.** The original
   policies checked a custom `x-mcat-code` request header
   (`current_setting('request.headers')`), which depended on the
   installed `supabase-py` version actually forwarding that header on
   every request — it wasn't. The result looked exactly like what was
   reported: "Save & Test Connection" says Connected (that's a much
   simpler check), but every actual chat send or fetch got rejected by
   Postgres with no obvious error surfaced in the UI. Fixed by switching
   to permissive policies and enforcing the mcat_code scoping in the
   app's own queries instead (every read/write already filtered by it).
   **Trade-off to know about:** this is no longer hardened against
   someone who has the anon key and hand-crafts raw requests bypassing
   the app — real per-user enforcement needs Supabase Auth, a bigger
   follow-up project. Reasonable for a trusted-device school deployment.
2. **A message queued by one account could display as sent by a
   different account.** The local outbox lookup wasn't filtered by
   sender — on a shared device, if Officer A queued a message while
   offline and then logged out before it sent, Officer B logging in
   afterward would see A's still-pending message rendered as if B had
   sent it (this is what "it thinks I am that account" was). Fixed by
   scoping every outbox lookup to the currently logged-in user's own ID.
3. **The contact list kept snapping back to Global Chat.** A side effect
   of the presence feature below — refreshing the online/offline dots
   every few seconds was accidentally re-selecting "Global Chat" each
   time, even while a Personal thread was open. Fixed to preserve
   whatever thread is currently open across a refresh.

## New — presence & typing indicators

- **Online dot.** Contacts who've been active in the last 30 seconds show
  a 🟢 in the contact list, and a personal thread's header shows "Active
  now" the same way.
- **Typing indicator.** A small italic line above the message box shows
  "Alice is typing…" when the other person (or, in Global, anyone) has
  text in their box — cleared automatically after ~6 seconds of no
  keystrokes.

Both are polling-based (piggybacking on the existing 4-second refresh),
not push/WebSocket-based — consistent with how message delivery already
works here.

## Not built — video calls

Real-time audio/video calling is a fundamentally different, much bigger
project than chat (WebRTC signaling, STUN/TURN servers for devices behind
different networks/routers, audio/video codecs, call UI) — it isn't
attempted here. Flagging this honestly rather than leaving it as a silent
gap: if you want this pursued, it deserves its own dedicated design pass.



- **Phase 3 — Boarding.** Live multiplayer investigation board. Schema
  is in place (`boards`, `board_objects` — one row per object so two
  people can edit different things at once without clobbering each
  other, `board_presence` for live cursors). The client side (an actual
  pannable/zoomable canvas with drag/rotate/draw tools, rendered with
  Qt's `QGraphicsView`) is the single biggest remaining piece of this
  whole project — plan for it to take real, dedicated time.

## Security notes

- The `anon` key is meant to be public-ish (it ships inside every copy
  of the app). Chat/Boarding tables currently use permissive Row Level
  Security policies (`using (true)`), with mcat_code scoping enforced by
  the app's own queries rather than by Postgres — see the "Bug fix"
  section above for why. This is good enough for a trusted-device school
  deployment but is not hardened against someone with the anon key
  hand-crafting raw requests outside the app; layering in real Supabase
  Auth (per-user login tokens) is the right follow-up before this holds
  more sensitive data at larger scale.
- Never commit `credentials.local.json` or share your `service_role` key.
