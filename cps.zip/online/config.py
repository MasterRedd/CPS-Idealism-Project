"""
Loads the two values you get from Supabase (Project Settings -> API):
  SUPABASE_URL       e.g. https://xxxxxxxxxxxx.supabase.co
  SUPABASE_ANON_KEY   the long 'anon public' key

Precedence: environment variables first, then online/credentials.local.json
(a plain JSON file you create — never committed, kept out of the zip/repo).

If neither is present, `is_configured()` returns False and every caller in
this app falls back to offline-only behavior instead of crashing — the app
must keep working with zero internet either way.
"""
import json
import os
from pathlib import Path

_CREDENTIALS_FILE = Path(__file__).resolve().parent / "credentials.local.json"


def _load_local_file() -> dict:
    if _CREDENTIALS_FILE.exists():
        try:
            return json.loads(_CREDENTIALS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def get_credentials():
    """Returns (url, anon_key) or (None, None) if not configured."""
    url = os.environ.get("SUPABASE_URL")
    key = os.environ.get("SUPABASE_ANON_KEY")
    if url and key:
        return _normalize_url(url), key
    local = _load_local_file()
    url = local.get("url")
    return (_normalize_url(url) if url else None), local.get("anon_key")


def _normalize_url(url: str) -> str:
    """Accepts either the plain project URL (https://xxxx.supabase.co) or
    the REST endpoint some dashboard pages show
    (https://xxxx.supabase.co/rest/v1/) and always returns the plain form
    supabase-py's create_client() expects. Pasting the REST endpoint by
    mistake used to silently break every request."""
    url = url.strip().rstrip("/")
    for suffix in ("/rest/v1", "/auth/v1", "/storage/v1"):
        if url.endswith(suffix):
            url = url[: -len(suffix)]
    return url


def save_credentials(url: str, anon_key: str):
    """Called from Settings -> Online (admin only) once you paste in your
    project's URL + anon key. Written to a local, un-synced file."""
    _CREDENTIALS_FILE.write_text(
        json.dumps({"url": _normalize_url(url), "anon_key": anon_key.strip()}, indent=2),
        encoding="utf-8",
    )


def is_configured() -> bool:
    url, key = get_credentials()
    return bool(url and key)
