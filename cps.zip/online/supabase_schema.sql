-- =====================================================================
-- CPS Online Schema — run this ONCE in your Supabase project's
-- SQL Editor (Dashboard -> SQL Editor -> New Query -> paste -> Run).
--
-- This is separate from the local SQLite schema.sql. Only the features
-- that genuinely need multiple devices talking to each other live here:
--   1. Global MCAT registry  (Administrator codes, truly unique worldwide)
--   2. Chat                  (Global per-MCAT + Personal direct messages)
--   3. Boarding               (live multiplayer investigation boards)
--
-- Everything else (students, officers, incidents, patrols, reports...)
-- stays local to each device's SQLite file, exactly as it already works.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Global MCAT Registry
-- ---------------------------------------------------------------------
-- One row per Administrator account that has ever gone online, across
-- EVERY installation of the app anywhere. This is the piece a single
-- offline SQLite file can never provide on its own: a single counter
-- that every device agrees on.
create table if not exists mcat_registry (
    mcat_code      text primary key,        -- e.g. 'MCAT-59'
    full_name      text not null,
    device_id      text not null,           -- which local install "owns" this
    is_deleted     boolean not null default false,
    is_online      boolean not null default false,
    last_seen_at   timestamptz not null default now(),
    deletion_scheduled_at timestamptz,
    created_at     timestamptz not null default now()
);

-- Atomically hands out the next MCAT number. Using a Postgres sequence
-- avoids two administrators, registering at the same instant on two
-- different devices, ever getting the same number.
create sequence if not exists mcat_seq start 1;

-- SECURITY DEFINER is the critical fix here: without it, this function runs
-- AS the calling role (the app's anon key), and while Supabase auto-grants
-- anon/authenticated access to TABLES, it does NOT auto-grant access to
-- SEQUENCES. That means nextval('mcat_seq') below was silently failing
-- with "permission denied for sequence mcat_seq" every single time this
-- was called from the app — which is exactly why every registration fell
-- back to local numbering (always MCAT-1 after a reinstall) even while
-- "Connected". SECURITY DEFINER makes it run with the privileges of
-- whoever created it (you, via the SQL Editor), bypassing that gap.
-- `set search_path = public` is a required safety pin for DEFINER
-- functions so they can't be tricked into resolving objects from a
-- different schema.
create or replace function next_mcat_code(p_full_name text, p_device_id text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
    v_code text;
begin
    v_code := 'MCAT-' || nextval('mcat_seq');
    insert into mcat_registry (mcat_code, full_name, device_id)
    values (v_code, p_full_name, p_device_id);
    return v_code;
end;
$$;

-- Belt-and-suspenders: explicitly grant execute to the roles the app's
-- anon key actually uses, in case a future edit ever drops SECURITY
-- DEFINER back off this function.
grant usage, select on sequence mcat_seq to anon, authenticated;
grant execute on function next_mcat_code(text, text) to anon, authenticated;

-- ---------------------------------------------------------------------
-- 2. Chat
-- ---------------------------------------------------------------------
-- If you ran an earlier version of this file, the table below may
-- already exist WITH a foreign key to mcat_registry(mcat_code) baked in
-- ("create table if not exists" does not modify an existing table's
-- structure). That constraint silently failed every chat insert for any
-- MCAT that was created offline and never separately registered online.
-- These two lines remove it if present; harmless no-ops on a fresh DB.
alter table if exists chat_messages drop constraint if exists chat_messages_mcat_code_fkey;
alter table if exists boards drop constraint if exists boards_mcat_code_fkey;

-- One extra manual step this file can't do for you: create a Storage
-- bucket named exactly  chat-media  (Dashboard -> Storage -> New Bucket),
-- marked PUBLIC. That's where attached photos/videos (and profile
-- avatars, under an  avatars/  prefix) are uploaded to and served from.
-- SQL can't create Storage buckets, so this one click is required once
-- per project. IMPORTANT: marking a bucket "Public" only allows reading
-- files without auth — it does NOT allow uploading. The storage policies
-- near the bottom of this file are what actually let the app upload
-- photos/videos; without them every attachment send fails even though
-- the bucket looks correctly configured in the dashboard.
-- Every account under one MCAT can see Global messages for that MCAT.
-- Personal messages are only visible to the two accounts involved.
create table if not exists chat_messages (
    id            bigint generated always as identity primary key,
    mcat_code     text not null,             -- NOTE: deliberately NOT a foreign
                                              -- key to mcat_registry — an admin
                                              -- account created offline (before
                                              -- Supabase was ever connected) has
                                              -- a perfectly valid MCAT that may
                                              -- never exist in that registry.
                                              -- Requiring it there first silently
                                              -- failed every single chat insert.
    scope         text not null check (scope in ('global', 'personal')),
    sender_id     text not null,            -- local user id, prefixed with mcat
    sender_name   text not null,
    recipient_id  text,                     -- required when scope='personal'
    body          text,                     -- null when it's a pure attachment
    attachment_url  text,                   -- Supabase Storage public URL
    attachment_type text,                   -- 'image' | 'video' | null
    attachment_kb   integer,                -- compressed size, for the UI
    client_msg_id text not null,            -- generated offline, used to
                                             -- de-duplicate once it syncs
    reply_to_client_id text,                -- client_msg_id being replied to
    reply_preview      text,                -- snippet of the original, saved
                                             -- at send-time (denormalized, so
                                             -- a reply still shows something
                                             -- sensible even if the original
                                             -- scrolled out of the fetch window)
    reply_sender_name  text,
    is_forwarded  boolean not null default false,
    is_pinned     boolean not null default false,
    is_deleted    boolean not null default false,
    edited_at     timestamptz,
    reactions     jsonb not null default '{}'::jsonb,  -- {"👍": ["user_id", ...]}
    created_at    timestamptz not null default now(),
    unique (client_msg_id)
);

create index if not exists idx_chat_mcat_scope on chat_messages (mcat_code, scope, created_at);

-- Who's currently online / when they were last seen — powers the green
-- dot and "Active now" label in Chat. avatar_url is the account's profile
-- photo, uploaded once per device to Storage so every device (not just
-- the one the photo file lives on) can display it.
create table if not exists chat_presence (
    user_id      text primary key,
    mcat_code    text not null,
    full_name    text not null,
    avatar_url   text,
    is_online    boolean not null default true,
    last_seen_at timestamptz not null default now()
);

-- Safe to re-run on a database that already has these tables from an
-- earlier version of this file (Postgres supports IF NOT EXISTS here).
alter table chat_messages add column if not exists reply_to_client_id text;
alter table chat_messages add column if not exists reply_preview text;
alter table chat_messages add column if not exists reply_sender_name text;
alter table chat_messages add column if not exists is_forwarded boolean not null default false;
alter table chat_messages add column if not exists is_pinned boolean not null default false;
alter table chat_messages add column if not exists is_deleted boolean not null default false;
alter table chat_messages add column if not exists edited_at timestamptz;
alter table chat_messages add column if not exists reactions jsonb not null default '{}'::jsonb;
alter table chat_presence add column if not exists avatar_url text;

-- This index needs is_pinned to exist first — on a database where
-- chat_messages already existed (so "create table if not exists" above
-- was a no-op), that column is only added by the alter table just above,
-- not by the create table at the top. Creating the index before that
-- alter table ran is exactly what caused: "column is_pinned does not
-- exist". Keeping this here, after the alter table, is what fixes it.
create index if not exists idx_chat_pinned on chat_messages (mcat_code, scope, is_pinned);

-- Typing indicator. One row per (mcat, scope, sender, recipient) combo,
-- constantly overwritten while someone has text in the box. recipient_id
-- is '' (empty string, not null) for Global so the primary key works —
-- Postgres treats NULL as never equal to itself, which would break the
-- upsert's "on conflict" matching.
create table if not exists chat_typing (
    mcat_code    text not null,
    scope        text not null,
    sender_id    text not null,
    sender_name  text not null,
    recipient_id text not null default '',
    updated_at   timestamptz not null default now(),
    primary key (mcat_code, scope, sender_id, recipient_id)
);

-- ---------------------------------------------------------------------
-- 3. Boarding (live multiplayer investigation boards)
-- ---------------------------------------------------------------------
create table if not exists boards (
    id           bigint generated always as identity primary key,
    mcat_code    text not null,              -- see chat_messages above — not
                                              -- a foreign key, same reason
    name         text not null,
    bio          text,
    created_by   text not null,
    created_at   timestamptz not null default now()
);

-- Every object on the board (text box, image, pin, line, shape, or a
-- freehand drawing stroke) is one row. Storing them individually — not
-- as one giant JSON blob — is what lets two people edit different
-- objects on the same board at the same time without overwriting each
-- other's changes.
create table if not exists board_objects (
    id           bigint generated always as identity primary key,
    board_id     bigint not null references boards(id) on delete cascade,
    object_type  text not null check (object_type in
                     ('text', 'image', 'pin', 'line', 'shape', 'stroke')),
    data         jsonb not null,            -- position, size, rotation,
                                             -- color, points, image_url, etc.
    z_index      integer not null default 0,
    updated_by   text not null,
    updated_at   timestamptz not null default now()
);

create index if not exists idx_board_objects_board on board_objects (board_id);

-- Live cursor / presence per person currently viewing a board. Short-lived
-- rows, overwritten constantly — this is how you see teammates moving
-- around the board in real time.
create table if not exists board_presence (
    board_id     bigint not null references boards(id) on delete cascade,
    user_id      text not null,
    user_name    text not null,
    cursor_x     double precision,
    cursor_y     double precision,
    color        text not null default '#1657A8',
    updated_at   timestamptz not null default now(),
    primary key (board_id, user_id)
);

-- ---------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------
-- IMPORTANT — if you ran an earlier version of this file, RE-RUN THIS
-- WHOLE FILE. The previous policies checked a custom 'x-mcat-code'
-- request header via current_setting('request.headers'). That relies on
-- the installed supabase-py client actually forwarding that header on
-- every request, which is not reliable across versions — in practice it
-- silently made every read/write get rejected, which looked exactly like
-- "it says Connected, but nothing sends or arrives."
--
-- Fix: these tables now use permissive policies (`using (true)`), and
-- scoping by mcat_code is enforced by the app's own queries instead
-- (every read/write already filters `.eq("mcat_code", ...)`).
--
-- Honest trade-off: this is NOT hardened against someone who has your
-- anon key and hand-crafts their own requests bypassing the app — there's
-- no real per-user authentication yet (that would mean adding Supabase
-- Auth, a bigger follow-up project). For a trusted-device school
-- deployment where the anon key isn't published anywhere public, this is
-- a reasonable trade-off to get chat actually working reliably today.
-- ---------------------------------------------------------------------
alter table mcat_registry enable row level security;
alter table chat_messages enable row level security;
alter table chat_presence enable row level security;
alter table chat_typing enable row level security;
alter table boards enable row level security;
alter table board_objects enable row level security;
alter table board_presence enable row level security;

-- (Postgres has no "CREATE POLICY IF NOT EXISTS" — drop-then-create
-- instead, so re-running this file is always safe.)
drop policy if exists mcat_self_read on mcat_registry;
create policy mcat_self_read on mcat_registry
    for select using (true);

drop policy if exists mcat_open_write on mcat_registry;
create policy mcat_open_write on mcat_registry
    for all using (true) with check (true);

drop policy if exists chat_scoped on chat_messages;
drop policy if exists chat_open on chat_messages;
create policy chat_open on chat_messages
    for all using (true) with check (true);

drop policy if exists chat_presence_open on chat_presence;
create policy chat_presence_open on chat_presence
    for all using (true) with check (true);

drop policy if exists chat_typing_open on chat_typing;
create policy chat_typing_open on chat_typing
    for all using (true) with check (true);

drop policy if exists boards_scoped on boards;
drop policy if exists boards_open on boards;
create policy boards_open on boards
    for all using (true) with check (true);

drop policy if exists board_objects_scoped on board_objects;
drop policy if exists board_objects_open on board_objects;
create policy board_objects_open on board_objects
    for all using (true) with check (true);

drop policy if exists board_presence_scoped on board_presence;
drop policy if exists board_presence_open on board_presence;
create policy board_presence_open on board_presence
    for all using (true) with check (true);

-- ---------------------------------------------------------------------
-- Storage — THIS is the actual fix for "photo/video attachments fail
-- to send". Marking the chat-media bucket "Public" in the dashboard only
-- allows reading files without auth; it does NOT grant permission to
-- upload. Supabase Storage keeps its own RLS on the storage.objects
-- table, separate from the tables above, so without a policy here every
-- upload attempt is silently rejected by the anon key. Re-run this file
-- AFTER creating the chat-media bucket (see the note near the top).
-- ---------------------------------------------------------------------
drop policy if exists chat_media_all on storage.objects;
create policy chat_media_all on storage.objects
    for all
    using (bucket_id = 'chat-media')
    with check (bucket_id = 'chat-media');

-- ---------------------------------------------------------------------
-- Belt-and-suspenders grants. Supabase normally auto-grants anon/
-- authenticated access to new TABLES in the public schema, but this
-- makes it explicit and safe to re-run, so a project with unusual
-- default-privilege settings doesn't silently break the same way the
-- MCAT sequence did.
-- ---------------------------------------------------------------------
grant select, insert, update, delete on
    mcat_registry, chat_messages, chat_presence, chat_typing,
    boards, board_objects, board_presence
    to anon, authenticated;
