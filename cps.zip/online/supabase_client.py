"""
Thin wrapper around the Supabase Python client.

Design rule for this whole module: NOTHING here may ever crash the app or
block its startup. Every public method catches its own errors and returns
a safe fallback (None / False / []) with `self.last_error` set, so the
calling UI code can just do:

    ok = online.register_admin(name, device_id)
    if not ok:
        # fall back to a locally-generated MCAT, same as fully-offline mode
        ...

This mirrors how the rest of the app treats "no internet" as a normal,
expected state rather than an error condition.
"""
import uuid
from pathlib import Path
from datetime import datetime, timezone

from online.config import get_credentials, is_configured

try:
    from supabase import create_client
except ImportError:
    create_client = None  # supabase package not installed yet — treat as offline

try:
    from supabase.lib.client_options import ClientOptions
except ImportError:
    try:
        from supabase import ClientOptions
    except ImportError:
        ClientOptions = None

CHAT_BUCKET = "chat-media"


class OnlineSync:
    def __init__(self):
        self.client = None
        self.last_error = None
        self.connected = False
        self._device_id = self._get_or_create_device_id()
        self._mcat_clients = {}  # unused now, kept so nothing else needs to change
        self._connect()

    # ------------------------------------------------------------------
    def _connect(self):
        if create_client is None:
            self.last_error = "supabase package not installed (pip install supabase)"
            return
        if not is_configured():
            self.last_error = "No Supabase credentials configured yet"
            return
        url, key = get_credentials()
        try:
            self.client = create_client(url, key)
            self.connected = True
        except Exception as e:
            self.last_error = str(e)
            self.client = None
            self.connected = False

    @staticmethod
    def _get_or_create_device_id() -> str:
        # One stable random id per installation, stored via QSettings so it
        # survives restarts but never leaves this machine unless we choose
        # to send it (it's just a tie-breaker label, not a secret).
        from PySide6.QtCore import QSettings
        settings = QSettings("CPS", "CATProgramSystem")
        device_id = settings.value("device_id", None)
        if not device_id:
            device_id = str(uuid.uuid4())
            settings.setValue("device_id", device_id)
        return device_id

    def check_connection_quality(self):
        """Runs one real, lightweight request and classifies the result so
        the login screen can show something more honest than a flat
        'online/offline'. Returns a dict:
            {"level": "best"|"mid"|"weak"|"offline", "label": str, "ms": int|None}
        Never raises."""
        if create_client is None:
            return {"level": "offline", "label": "Offline — supabase package not installed", "ms": None}
        if not is_configured():
            return {"level": "offline", "label": "Offline — no Supabase credentials set", "ms": None}
        if not self.is_available():
            # Credentials exist but the client itself failed to build.
            return {"level": "offline", "label": "Offline — no internet connection", "ms": None}
        import time
        try:
            start = time.perf_counter()
            self.client.table("mcat_registry").select("mcat_code").limit(1).execute()
            elapsed_ms = int((time.perf_counter() - start) * 1000)
        except Exception as e:
            self.last_error = str(e)
            return {"level": "offline", "label": "Offline — no internet connection", "ms": None}

        if elapsed_ms < 400:
            return {"level": "best", "label": f"Online — Best ({elapsed_ms} ms)", "ms": elapsed_ms}
        elif elapsed_ms < 900:
            return {"level": "mid", "label": f"Online — Mid ({elapsed_ms} ms)", "ms": elapsed_ms}
        elif elapsed_ms < 2500:
            return {"level": "weak", "label": f"Online — Weak ({elapsed_ms} ms)", "ms": elapsed_ms}
        else:
            return {"level": "weak", "label": f"Online — Very Weak ({elapsed_ms} ms)", "ms": elapsed_ms}

    def is_available(self) -> bool:
        """Cheap check before attempting any online call — does NOT
        guarantee the network is actually reachable right now (that's
        only known once a real request is tried), just that credentials
        exist and the client initialized."""
        return self.connected and self.client is not None

    # ------------------------------------------------------------------
    # MCAT registry (Phase 1)
    # ------------------------------------------------------------------
    def register_admin_online(self, full_name: str) -> str | None:
        """Asks Supabase for the next globally-unique MCAT code. Returns
        None on any failure (no internet, project asleep, etc.) — the
        caller should then fall back to the local-only numbering that
        already exists, exactly as before this feature existed."""
        if not self.is_available():
            return None
        try:
            result = self.client.rpc(
                "next_mcat_code",
                {"p_full_name": full_name, "p_device_id": self._device_id},
            ).execute()
            return result.data
        except Exception as e:
            self.last_error = str(e)
            return None

    def ensure_mcat_registered(self, mcat_code: str, full_name: str):
        """An Administrator created before Supabase was connected (or while
        offline) has a perfectly valid MCAT that may not exist in the
        online registry yet. Chat no longer requires this row (the hard
        foreign key that used to force it was removed — see schema notes),
        but keeping the registry populated matters for other features
        (e.g. a future cross-device Creator dashboard), so this call
        quietly backfills it the first time this device successfully
        reaches Supabase. Safe to call every time; it's a no-op update
        if the row already exists."""
        if not self.is_available():
            return
        try:
            existing = (
                self.client.table("mcat_registry")
                .select("mcat_code")
                .eq("mcat_code", mcat_code)
                .execute()
            )
            if existing.data:
                # Already registered (by this device or another) — never
                # overwrite it. Overwriting here is exactly what caused two
                # different accounts to end up sharing one MCAT's chat
                # history after a reinstall generated the same local code.
                return
            self.client.table("mcat_registry").insert({
                "mcat_code": mcat_code,
                "full_name": full_name,
                "device_id": self._device_id,
            }).execute()
        except Exception as e:
            self.last_error = str(e)

    def touch_online(self, mcat_code: str, online: bool):
        """Heartbeat — call this on login/logout and periodically while
        the app is open, so other devices can see accurate status."""
        if not self.is_available():
            return
        try:
            self.client.table("mcat_registry").update({
                "is_online": online,
                "last_seen_at": datetime.now(timezone.utc).isoformat(),
            }).eq("mcat_code", mcat_code).execute()
        except Exception as e:
            self.last_error = str(e)

    def fetch_registry_snapshot(self):
        """Full list of known MCATs — used to detect/resolve numbering
        conflicts if this device made local codes while it was offline."""
        if not self.is_available():
            return []
        try:
            result = self.client.table("mcat_registry").select("*").execute()
            return result.data or []
        except Exception as e:
            self.last_error = str(e)
            return []

    # ------------------------------------------------------------------
    # Chat (Phase 2)
    # ------------------------------------------------------------------
    def _client_for_mcat(self, mcat_code: str):
        # NOTE: this used to build a per-MCAT client with a custom
        # 'x-mcat-code' header, paired with an RLS policy reading that
        # header back via current_setting('request.headers'). That relied
        # on the installed supabase-py version reliably forwarding custom
        # headers on every request, which is not guaranteed — in practice
        # it silently made RLS reject every read/write ("connected, but
        # nothing sends or arrives" — the exact symptom reported). Fixed
        # by using one plain shared client; every query already filters by
        # mcat_code explicitly (.eq("mcat_code", ...)), and the matching
        # schema update makes the policies permissive so a legitimate
        # request is never blocked. See online/README.md for the honest
        # security trade-off this implies (no real per-user auth yet).
        if not self.is_available():
            return None
        return self.client

    def send_message(self, mcat_code, scope, sender_id, sender_name,
                      client_msg_id, body=None, recipient_id=None,
                      attachment_url=None, attachment_type=None,
                      attachment_kb=None, reply_to_client_id=None,
                      reply_preview=None, reply_sender_name=None,
                      is_forwarded=False) -> bool:
        """Delivers one chat message. Returns False on any failure (no
        internet, project asleep, RLS mismatch) — the caller is expected
        to queue it in the local outbox and retry later on False."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            self.last_error = self.last_error or "Not connected"
            return False
        try:
            client.table("chat_messages").insert({
                "mcat_code": mcat_code,
                "scope": scope,
                "sender_id": str(sender_id),
                "sender_name": sender_name,
                "recipient_id": str(recipient_id) if recipient_id is not None else None,
                "body": body,
                "attachment_url": attachment_url,
                "attachment_type": attachment_type,
                "attachment_kb": attachment_kb,
                "client_msg_id": client_msg_id,
                "reply_to_client_id": reply_to_client_id,
                "reply_preview": reply_preview,
                "reply_sender_name": reply_sender_name,
                "is_forwarded": bool(is_forwarded),
            }).execute()
            return True
        except Exception as e:
            # A duplicate client_msg_id (already delivered earlier, e.g. a
            # retry after a flaky connection) is a success, not a failure.
            if "duplicate" in str(e).lower() or "unique" in str(e).lower():
                return True
            self.last_error = str(e)
            return False

    def edit_message(self, mcat_code, client_msg_id, new_body) -> bool:
        """The 3-minute edit window is enforced by the caller (it already
        has created_at locally); this just performs the update."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            return False
        try:
            client.table("chat_messages").update({
                "body": new_body,
                "edited_at": datetime.now(timezone.utc).isoformat(),
            }).eq("client_msg_id", client_msg_id).execute()
            return True
        except Exception as e:
            self.last_error = str(e)
            return False

    def delete_message(self, client_msg_id) -> bool:
        """Soft delete — the row stays (so reply-quotes referencing it
        don't break) but body/attachment are cleared and is_deleted=true,
        which the UI renders as 'This message was deleted'."""
        client = self._client_for_mcat("_")
        if client is None:
            return False
        try:
            client.table("chat_messages").update({
                "is_deleted": True,
                "body": None,
                "attachment_url": None,
                "attachment_type": None,
            }).eq("client_msg_id", client_msg_id).execute()
            return True
        except Exception as e:
            self.last_error = str(e)
            return False

    def set_pinned(self, client_msg_id, pinned: bool) -> bool:
        client = self._client_for_mcat("_")
        if client is None:
            return False
        try:
            client.table("chat_messages").update(
                {"is_pinned": bool(pinned)}
            ).eq("client_msg_id", client_msg_id).execute()
            return True
        except Exception as e:
            self.last_error = str(e)
            return False

    def fetch_pinned(self, mcat_code, scope, recipient_id=None, self_id=None):
        """Pinned messages for one thread, latest first."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            return []
        try:
            query = (
                client.table("chat_messages").select("*")
                .eq("mcat_code", mcat_code).eq("scope", scope)
                .eq("is_pinned", True).order("id", desc=True)
            )
            if scope == "personal":
                a, b = str(self_id), str(recipient_id)
                query = query.or_(
                    f"and(sender_id.eq.{a},recipient_id.eq.{b}),"
                    f"and(sender_id.eq.{b},recipient_id.eq.{a})"
                )
            result = query.execute()
            return result.data or []
        except Exception as e:
            self.last_error = str(e)
            return []

    def toggle_reaction(self, client_msg_id, emoji, user_id):
        """Reactions are stored as {emoji: [user_id, ...]} on the message
        row. This does a read-modify-write, not an atomic increment —
        with normal chat traffic (one person tapping one emoji at a time)
        the odds of two people reacting to the SAME message in the SAME
        instant are low enough that a rare lost reaction is an acceptable
        trade-off against the much bigger complexity of a database-side
        increment function. Returns the new reactions dict, or None on
        failure."""
        client = self._client_for_mcat("_")
        if client is None:
            return None
        try:
            row = (
                client.table("chat_messages").select("reactions")
                .eq("client_msg_id", client_msg_id).single().execute()
            )
            reactions = dict(row.data.get("reactions") or {}) if row.data else {}
            users = list(reactions.get(emoji, []))
            uid = str(user_id)
            if uid in users:
                users.remove(uid)
            else:
                users.append(uid)
            if users:
                reactions[emoji] = users
            elif emoji in reactions:
                del reactions[emoji]
            client.table("chat_messages").update(
                {"reactions": reactions}
            ).eq("client_msg_id", client_msg_id).execute()
            return reactions
        except Exception as e:
            self.last_error = str(e)
            return None

    def fetch_messages(self, mcat_code, scope, recipient_id=None,
                        self_id=None, after_id=0, limit=200):
        """Returns messages newer than after_id for a Global thread or a
        specific Personal thread (both directions between self_id and
        recipient_id). Returns [] (not an error) when offline."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            return []
        try:
            query = (
                client.table("chat_messages").select("*")
                .eq("mcat_code", mcat_code)
                .eq("scope", scope)
                .gt("id", after_id)
                .order("id")
                .limit(limit)
            )
            if scope == "personal":
                a, b = str(self_id), str(recipient_id)
                query = query.or_(
                    f"and(sender_id.eq.{a},recipient_id.eq.{b}),"
                    f"and(sender_id.eq.{b},recipient_id.eq.{a})"
                )
            result = query.execute()
            return result.data or []
        except Exception as e:
            self.last_error = str(e)
            return []

    def upload_attachment(self, mcat_code, local_path, dest_filename) -> str | None:
        """Uploads a (already-compressed) file to the shared 'chat-media'
        Storage bucket and returns its public URL, or None on failure.
        The bucket must be created once, manually, as Public — see
        online/README.md."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            return None
        try:
            storage_path = f"{mcat_code}/{dest_filename}"
            with open(local_path, "rb") as f:
                data = f.read()
            client.storage.from_(CHAT_BUCKET).upload(
                storage_path, data,
                file_options={"upsert": "true"},
            )
            return client.storage.from_(CHAT_BUCKET).get_public_url(storage_path)
        except Exception as e:
            self.last_error = str(e)
            return None

    # ------------------------------------------------------------------
    # Presence & typing indicators
    # ------------------------------------------------------------------
    def set_presence(self, mcat_code, user_id, full_name, online: bool = True,
                      avatar_url: str = None):
        """Upserts a 'last seen' row for this user. Called on login,
        periodically while the app is open, and on logout. Read by
        fetch_presence() to show a green dot / 'Active now' in Chat.
        avatar_url is only included in the write when explicitly passed,
        so routine heartbeat calls (which don't know the avatar URL)
        never accidentally blank out a previously-uploaded one."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            return
        try:
            payload = {
                "user_id": str(user_id),
                "mcat_code": mcat_code,
                "full_name": full_name,
                "is_online": online,
                "last_seen_at": datetime.now(timezone.utc).isoformat(),
            }
            if avatar_url is not None:
                payload["avatar_url"] = avatar_url
            client.table("chat_presence").upsert(
                payload, on_conflict="user_id"
            ).execute()
        except Exception as e:
            self.last_error = str(e)

    def upload_avatar(self, mcat_code, local_path, user_id) -> str | None:
        """Same mechanism as upload_attachment, but filed under an
        avatars/ prefix in the shared chat-media bucket so profile photos
        (which live only on the device that has the original file) become
        visible to every device via a public URL."""
        ext = Path(local_path).suffix or ".jpg"
        return self.upload_attachment(mcat_code, local_path, f"avatars/{user_id}{ext}")

    def fetch_presence(self, mcat_code):
        """Returns {user_id: {is_online, last_seen_at, full_name}} for
        everyone under this MCAT who has ever come online. A user is only
        treated as genuinely online if last_seen_at is recent (a stale
        'online' row just means the app closed without a clean logout)."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            return {}
        try:
            result = client.table("chat_presence").select("*").eq("mcat_code", mcat_code).execute()
            return {row["user_id"]: row for row in (result.data or [])}
        except Exception as e:
            self.last_error = str(e)
            return {}

    def set_typing(self, mcat_code, scope, sender_id, sender_name, recipient_id=None):
        """Called (throttled, not every keystroke) while someone has text
        in the input box. recipient_id is '' for Global so the row has a
        stable primary key regardless of scope."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            return
        try:
            client.table("chat_typing").upsert({
                "mcat_code": mcat_code,
                "scope": scope,
                "sender_id": str(sender_id),
                "sender_name": sender_name,
                "recipient_id": str(recipient_id) if recipient_id is not None else "",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }, on_conflict="mcat_code,scope,sender_id,recipient_id").execute()
        except Exception as e:
            self.last_error = str(e)

    def fetch_typing(self, mcat_code, scope, recipient_id=None, exclude_id=None):
        """Returns names of people currently typing in this exact thread
        (updated within the last 6 seconds — older rows are treated as
        'stopped typing', since there's no explicit 'stopped' event)."""
        client = self._client_for_mcat(mcat_code)
        if client is None:
            return []
        try:
            from datetime import timedelta
            cutoff = (datetime.now(timezone.utc) - timedelta(seconds=6)).isoformat()
            query = (
                client.table("chat_typing").select("*")
                .eq("mcat_code", mcat_code).eq("scope", scope)
                .eq("recipient_id", str(recipient_id) if recipient_id is not None else "")
                .gte("updated_at", cutoff)
            )
            result = query.execute()
            names = [r["sender_name"] for r in (result.data or [])
                     if str(r["sender_id"]) != str(exclude_id)]
            return names
        except Exception as e:
            self.last_error = str(e)
            return []

    def download_attachment(self, url: str, save_to) -> bool:
        """Downloads a chat attachment to a local cache path. Plain HTTP GET
        since Storage public URLs need no auth — kept dependency-free."""
        try:
            import urllib.request
            urllib.request.urlretrieve(url, str(save_to))
            return True
        except Exception as e:
            self.last_error = str(e)
            return False


# Single shared instance the rest of the app imports, e.g.:
#   from online.supabase_client import online
#   mcat = online.register_admin_online(name) or db.create_administrator_account(...)
online = None


def get_online():
    global online
    if online is None:
        online = OnlineSync()
    return online
