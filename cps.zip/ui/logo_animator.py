"""
ui/logo_animator.py
───────────────────
Logo drop-and-shatter intro animation for the CPS login page.

Animation sequence
──────────────────
 1  Fade-In     520 ms   Logo materialises (opacity 0 → 1, held at top)
 2  Drop        740 ms   Logo falls with elastic bounce to rest position
 3  Zoom-In     115 ms   Impact punch-in   (scale 1.0 → 1.42)
 4  Zoom-Out    170 ms   Snap punch-out    (scale 1.42 → 0.80)
 5  Settle      150 ms   Bounce-back       (scale 0.80 → 1.0, OutBack)
 6  CEffect       1 ms   Shatter overlay appears instantly
 7  CEffect↓    800 ms   Shatter fades out (opacity 1 → 0, OutCubic)

Drop is fully contained within the widget so no clipping tricks needed.
The widget's static footprint (height = logo + drop) leaves transparent
dark-blue space above the logo that looks intentional, exactly like the
logo is "anchored" just above the gold accent bar.

Usage in login_window.py
────────────────────────
    from ui.logo_animator import LogoAnimatorWidget
    logo_anim = LogoAnimatorWidget()
    brand_layout.addWidget(logo_anim, 0, Qt.AlignHCenter)
    brand_layout.addWidget(accent_bar, 0, Qt.AlignLeft)
"""

from __future__ import annotations
from pathlib import Path

import numpy as np
from PIL import Image

from PySide6.QtWidgets import QWidget, QSizePolicy
from PySide6.QtCore import (
    Qt,
    Property,
    Signal,
    QPropertyAnimation,
    QSequentialAnimationGroup,
    QEasingCurve,
    QTimer,
)
from PySide6.QtGui import QImage, QPixmap, QPainter

# ── Path resolution ───────────────────────────────────────────────────────────
_HERE     = Path(__file__).resolve().parent          # ui/
_PROJ_DIR = _HERE.parent                             # project root
LOGO_PATH    = _PROJ_DIR / "resources" / "Logo.png"
CEFFECT_PATH = _PROJ_DIR / "resources" / "CEffect.webp"


# ── Image helpers ─────────────────────────────────────────────────────────────

def _pil_to_qpixmap(pil_img: Image.Image) -> QPixmap:
    """Convert a PIL RGBA image → QPixmap without temp files."""
    img  = pil_img.convert("RGBA")
    w, h = img.size
    data = bytes(img.tobytes("raw", "RGBA"))
    qimg = QImage(data, w, h, w * 4, QImage.Format_RGBA8888)
    return QPixmap.fromImage(qimg.copy())   # .copy() detaches from `data`


def _load_logo(path: Path, size: int) -> QPixmap:
    """Load logo, crop to content bounds, resize cleanly."""
    img = Image.open(str(path)).convert("RGBA")

    # Tight-crop around actual content so the 2048×2048 canvas
    # doesn't waste space — the shield sits off-centre in the source.
    alpha = np.array(img)[:, :, 3]
    rows  = np.where(alpha.max(axis=1) > 8)[0]
    cols  = np.where(alpha.max(axis=0) > 8)[0]
    if rows.size and cols.size:
        pad = 30  # tiny border so the glow isn't clipped
        top    = max(0,              rows[0]  - pad)
        bottom = min(img.height,     rows[-1] + pad + 1)
        left   = max(0,              cols[0]  - pad)
        right  = min(img.width,      cols[-1] + pad + 1)
        img = img.crop((left, top, right, bottom))

    img = img.resize((size, size), Image.LANCZOS)
    return _pil_to_qpixmap(img)


def _load_ceffect(path: Path, size: int) -> QPixmap:
    """
    Load crack overlay and tint crack lines to brand gold (#FFD700).
    The source already has proper transparency; we just colour the dark
    crack pixels toward gold based on their darkness.
    """
    ce  = Image.open(str(path)).convert("RGBA")
    arr = np.array(ce, dtype=np.float32)

    rgb        = arr[:, :, :3]
    alpha      = arr[:, :, 3:4]
    brightness = rgb.mean(axis=2, keepdims=True) / 255.0
    darkness   = 1.0 - brightness              # 1 = very dark/crack-y

    gold       = np.array([255.0, 215.0, 0.0])
    tinted     = rgb * (1.0 - darkness) + gold * darkness
    boosted_a  = np.clip(alpha * 1.5, 0, 255)  # punch up visibility slightly

    result = np.concatenate(
        [tinted.clip(0, 255), boosted_a], axis=2
    ).astype(np.uint8)

    out = Image.fromarray(result, "RGBA").resize((size, size), Image.LANCZOS)
    return _pil_to_qpixmap(out)


# ── Animator widget ───────────────────────────────────────────────────────────

class LogoAnimatorWidget(QWidget):
    """
    Self-animating logo widget — drop in above the gold accent bar.

    The widget is taller than the logo itself so the full drop path
    is visible.  After animation the top portion is transparent and
    blends seamlessly with the dark-blue brand panel.
    """

    impactOccurred = Signal()   # fired the instant the CEffect flash appears

    # ── Geometry constants ────────────────────────────────────────────────
    # Tightened up from the original values so the logo sits higher and
    # closer to the title block instead of floating low in the panel.
    _LOGO_SZ  = 96     # final logo size, px (square)
    _DROP_H   = 90     # vertical fall distance, px
    _CE_SZ    = 172    # crack-effect overlay size, px
    _PAD      = 8      # inner padding, px

    def __init__(
        self,
        logo_path:    str | Path = LOGO_PATH,
        ceffect_path: str | Path = CEFFECT_PATH,
        parent=None,
    ):
        super().__init__(parent)

        # ── Load images ───────────────────────────────────────────────────
        self._logo_px    = _load_logo   (Path(logo_path),    self._LOGO_SZ)
        self._ceffect_px = _load_ceffect(Path(ceffect_path), self._CE_SZ  )

        # ── Anchor Y positions (logo centre in widget coords) ─────────────
        self._y_start = float(self._PAD + self._LOGO_SZ // 2)
        self._y_final = float(self._PAD + self._DROP_H + self._LOGO_SZ // 2)

        # ── Backing values for the four animated properties ───────────────
        self._lop = 0.0                # logo opacity
        self._ly  = self._y_start      # logo centre-y
        self._ls  = 1.0                # logo scale
        self._cop = 0.0                # ceffect opacity

        # ── Fixed widget size ─────────────────────────────────────────────
        w = max(self._CE_SZ + 20, self._LOGO_SZ + 60)
        h = self._PAD * 2 + self._DROP_H + self._LOGO_SZ
        self.setFixedSize(w, h)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        # Transparent so the dark brand-panel bg shows through the empty area
        self.setStyleSheet("background: transparent;")

        # ── Start with a brief delay so the window is fully painted first ─
        QTimer.singleShot(250, self._run_animation)

    # ── Qt animatable properties ──────────────────────────────────────────
    # (Property getter/setter pair must be defined before the class-level
    #  Property() call that wires them together.)

    def _get_lop(self) -> float:     return self._lop
    def _set_lop(self, v: float):    self._lop = max(0.0, min(1.0, v)); self.update()
    logoOpacity    = Property(float, _get_lop, _set_lop)

    def _get_ly(self)  -> float:     return self._ly
    def _set_ly(self,  v: float):    self._ly  = v;                      self.update()
    logoY          = Property(float, _get_ly,  _set_ly)

    def _get_ls(self)  -> float:     return self._ls
    def _set_ls(self,  v: float):    self._ls  = max(0.01, v);           self.update()
    logoScale      = Property(float, _get_ls,  _set_ls)

    def _get_cop(self) -> float:     return self._cop
    def _set_cop(self, v: float):    self._cop = max(0.0, min(1.0, v)); self.update()
    ceffectOpacity = Property(float, _get_cop, _set_cop)

    # ── Animation builder ─────────────────────────────────────────────────

    def _mk(
        self,
        prop:  bytes,
        start: float,
        end:   float,
        ms:    int,
        curve: QEasingCurve.Type = QEasingCurve.OutCubic,
    ) -> QPropertyAnimation:
        a = QPropertyAnimation(self, prop)
        a.setStartValue(float(start))
        a.setEndValue(float(end))
        a.setDuration(ms)
        a.setEasingCurve(curve)
        return a

    def _run_animation(self):
        seq = QSequentialAnimationGroup(self)

        # 1 — Fade in (logo held at top of widget)
        seq.addAnimation(self._mk(b"logoOpacity", 0.0, 1.0, 520, QEasingCurve.OutCubic))

        # 2 — Drop with elastic bounce
        seq.addAnimation(self._mk(b"logoY", self._y_start, self._y_final, 740,
                                  QEasingCurve.OutBounce))

        # 3 — Punch-in zoom
        seq.addAnimation(self._mk(b"logoScale", 1.00, 1.42, 115, QEasingCurve.InCubic))

        # 4 — Snap zoom-out (overshoot below 1)
        seq.addAnimation(self._mk(b"logoScale", 1.42, 0.80, 170, QEasingCurve.InCubic))

        # 5 — Settle to resting scale with slight overshoot
        seq.addAnimation(self._mk(b"logoScale", 0.80, 1.00, 150, QEasingCurve.OutBack))

        # 6 — CEffect flash (instant appear) — this is the "impact moment"
        ce_appear = self._mk(b"ceffectOpacity", 0.0, 1.0, 1, QEasingCurve.Linear)
        seq.addAnimation(ce_appear)

        # 7 — CEffect fade out
        seq.addAnimation(self._mk(b"ceffectOpacity", 1.0, 0.0, 800, QEasingCurve.OutCubic))

        # Emit the impact signal at the exact instant the flash animation
        # becomes current, so listeners (e.g. the accent bar) can react
        # in perfect sync with the visual punch.
        def _on_current_changed(current):
            if current is ce_appear:
                self.impactOccurred.emit()

        seq.currentAnimationChanged.connect(_on_current_changed)

        self._seq = seq   # keep reference alive (prevents GC during animation)
        seq.start()

    # ── Paint ──────────────────────────────────────────────────────────────

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)

        cx = self.width() / 2.0
        cy = self._ly

        # ── CEffect drawn FIRST so it sits behind the logo ────────────────
        if self._cop > 0.002:
            p.setOpacity(self._cop)
            p.save()
            p.translate(cx, cy)
            half_ce = self._CE_SZ / 2.0
            p.drawPixmap(int(-half_ce), int(-half_ce), self._ceffect_px)
            p.restore()

        # ── Logo drawn ON TOP of CEffect ──────────────────────────────────
        if self._lop > 0.002:
            p.setOpacity(self._lop)
            p.save()
            p.translate(cx, cy)
            p.scale(self._ls, self._ls)
            half = self._LOGO_SZ / 2.0
            p.drawPixmap(int(-half), int(-half), self._logo_px)
            p.restore()

        p.end()
