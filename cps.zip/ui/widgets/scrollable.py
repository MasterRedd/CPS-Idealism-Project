from PySide6.QtWidgets import QScrollArea, QWidget, QVBoxLayout, QDialogButtonBox, QApplication


def make_scrollable(dialog, max_height_ratio=0.82, margins=(20, 18, 20, 14)):
    """
    Wrap everything already added to `dialog`'s top-level layout inside a
    QScrollArea, so long forms (Add Officer, Record Incident, etc.) stay
    reachable with a scrollbar instead of overflowing past the bottom of
    the screen. The QDialogButtonBox (Save/Cancel/Close), if present, is
    kept pinned below the scroll area so the action buttons are always
    visible without having to scroll down for them.

    Call this at the very end of a dialog's `_build_ui()`, after every
    row/widget has already been added to `self`'s layout.
    """
    old_layout = dialog.layout()
    if old_layout is None:
        return

    button_box = None
    items = []
    while old_layout.count():
        item = old_layout.takeAt(0)
        w = item.widget()
        if isinstance(w, QDialogButtonBox) and button_box is None:
            button_box = w
        else:
            items.append(item)

    content = QWidget()
    content_layout = QVBoxLayout(content)
    content_layout.setContentsMargins(0, 0, 0, 0)
    content_layout.setSpacing(old_layout.spacing() if old_layout.spacing() > 0 else 10)
    for item in items:
        if item.widget():
            content_layout.addWidget(item.widget())
        elif item.layout():
            content_layout.addLayout(item.layout())
        else:
            content_layout.addItem(item)

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QScrollArea.NoFrame)
    scroll.setWidget(content)

    # Detach the (now empty) old layout so a new one can be assigned.
    QWidget().setLayout(old_layout)

    new_layout = QVBoxLayout()
    new_layout.setContentsMargins(*margins)
    new_layout.setSpacing(12)
    new_layout.addWidget(scroll, 1)
    if button_box is not None:
        new_layout.addWidget(button_box)
    dialog.setLayout(new_layout)

    # Cap the dialog height to the available screen so it never grows
    # taller than the user's monitor, and give it a sensible starting size.
    screen = QApplication.primaryScreen()
    if screen:
        avail = screen.availableGeometry()
        max_h = int(avail.height() * max_height_ratio)
        dialog.setMaximumHeight(max_h)
        target_h = min(content.sizeHint().height() + 140, max_h)
        dialog.resize(dialog.width() or dialog.sizeHint().width(), max(target_h, 320))
