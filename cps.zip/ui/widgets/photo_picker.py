from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt

IMAGE_FILE_FILTER = "Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp);;All Files (*)"


class PhotoPicker(QWidget):
    """A small preview box + Browse/Remove buttons for picking a profile
    photo. The originally-selected file path is kept as-is (matching the
    evidence-attachment pattern used elsewhere) rather than copied into
    app storage."""

    def __init__(self, initial_path: str = None, parent=None):
        super().__init__(parent)
        self.photo_path = initial_path or None
        self._build_ui()
        self._refresh_preview()

    def _build_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.preview = QLabel()
        self.preview.setFixedSize(96, 96)
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setStyleSheet(
            "border: 1px solid #D3DAE1; border-radius: 6px; background: #EDF2F9; color: #8ea0b3;"
        )
        layout.addWidget(self.preview)

        btn_col = QVBoxLayout()
        self.browse_btn = QPushButton("Choose Photo…")
        self.browse_btn.clicked.connect(self._choose_photo)
        btn_col.addWidget(self.browse_btn)

        self.remove_btn = QPushButton("Remove")
        self.remove_btn.clicked.connect(self._remove_photo)
        btn_col.addWidget(self.remove_btn)
        btn_col.addStretch()

        layout.addLayout(btn_col)
        layout.addStretch()

    def _choose_photo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose Photo", "", IMAGE_FILE_FILTER)
        if path:
            self.photo_path = path
            self._refresh_preview()

    def _remove_photo(self):
        self.photo_path = None
        self._refresh_preview()

    def _refresh_preview(self):
        if self.photo_path:
            pix = QPixmap(self.photo_path)
            if not pix.isNull():
                pix = pix.scaled(96, 96, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                self.preview.setPixmap(pix)
                return
        self.preview.setPixmap(QPixmap())
        self.preview.setText("No Photo")

    def value(self):
        return self.photo_path
