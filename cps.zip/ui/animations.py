"""
CPS — Animation helpers
------------------------
Small, reusable helpers that add smooth, subtle motion across the app
without touching the layout logic of every screen individually:

- install_global_animations(app): installs a QApplication-wide event
  filter that fades in every dialog/window the moment it's shown, so
  every popup in the whole system (Add Officer, Add Student, message
  boxes, the export picker, etc.) automatically gets a smooth fade-in
  with zero per-dialog code changes.

- fade_in_widget(widget): fades in a *child* widget (e.g. a page inside
  a QStackedWidget) using a QGraphicsOpacityEffect, since windowOpacity
  only works on top-level windows.

- animate_progress(bar, value, duration): smoothly glides a QProgressBar
  to a new value instead of snapping to it.
"""

from PySide6.QtCore import QObject, QEvent, QPropertyAnimation, QEasingCurve, Qt
from PySide6.QtWidgets import QDialog, QGraphicsOpacityEffect


class _FadeInFilter(QObject):
    """Fades in top-level windows (dialogs, message boxes, the login
    window, the main window) the first time each is shown."""

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Show:
            try:
                is_top_level = obj.isWindow()
            except Exception:
                is_top_level = False
            if is_top_level and not obj.property("_cps_faded"):
                obj.setProperty("_cps_faded", True)
                try:
                    start = 0.35 if isinstance(obj, QDialog) else 0.0
                    obj.setWindowOpacity(start)
                    anim = QPropertyAnimation(obj, b"windowOpacity", obj)
                    anim.setDuration(220 if isinstance(obj, QDialog) else 260)
                    anim.setStartValue(start)
                    anim.setEndValue(1.0)
                    anim.setEasingCurve(QEasingCurve.OutCubic)
                    anim.start(QPropertyAnimation.DeleteWhenStopped)
                    obj._cps_fade_anim = anim  # keep a reference alive
                except Exception:
                    pass
        return False


def install_global_animations(app):
    """Call once on the QApplication so every dialog/window in the app
    fades in smoothly with no per-screen wiring required."""
    app._cps_fade_filter = _FadeInFilter(app)
    app.installEventFilter(app._cps_fade_filter)


def fade_in_widget(widget, duration=220, start=0.0, end=1.0):
    """Fade in a non-top-level widget (e.g. a page swapped into a
    QStackedWidget) using an opacity effect + property animation."""
    effect = QGraphicsOpacityEffect(widget)
    effect.setOpacity(start)
    widget.setGraphicsEffect(effect)
    anim = QPropertyAnimation(effect, b"opacity", widget)
    anim.setDuration(duration)
    anim.setStartValue(start)
    anim.setEndValue(end)
    anim.setEasingCurve(QEasingCurve.OutCubic)

    def _cleanup():
        # Drop the effect afterward so it doesn't linger and interfere
        # with child widgets repainting (e.g. tables, combo popups).
        if widget.graphicsEffect() is effect:
            widget.setGraphicsEffect(None)

    anim.finished.connect(_cleanup)
    anim.start(QPropertyAnimation.DeleteWhenStopped)
    widget._cps_fade_anim = anim
    return anim


def animate_progress(bar, value, duration=250):
    """Smoothly animate a QProgressBar to `value` instead of jumping."""
    anim = QPropertyAnimation(bar, b"value", bar)
    anim.setDuration(duration)
    anim.setStartValue(bar.value())
    anim.setEndValue(value)
    anim.setEasingCurve(QEasingCurve.OutCubic)
    anim.start(QPropertyAnimation.DeleteWhenStopped)
    bar._cps_progress_anim = anim
    return anim
