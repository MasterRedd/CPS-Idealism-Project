from PySide6.QtWidgets import QSplashScreen, QProgressBar
from PySide6.QtGui import QPixmap, QColor, QPainter, QFont
from PySide6.QtCore import Qt

from ui.animations import animate_progress


def _build_splash_pixmap(width=520, height=320):
    pixmap = QPixmap(width, height)
    pixmap.fill(QColor("#0A2E5C"))

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)

    # Gold accent bar
    painter.fillRect(0, 0, width, 5, QColor("#D4AF37"))

    # Title
    painter.setPen(QColor("#ffffff"))
    title_font = QFont("Segoe UI", 26, QFont.Bold)
    painter.setFont(title_font)
    painter.drawText(pixmap.rect().adjusted(0, -30, 0, 0), Qt.AlignCenter, "CAT Program System")

    # Subtitle
    painter.setPen(QColor("#D4AF37"))
    sub_font = QFont("Segoe UI", 11)
    painter.setFont(sub_font)
    painter.drawText(pixmap.rect().adjusted(0, 30, 0, 0), Qt.AlignCenter, "Citizenship Advancement Training — Management Platform")

    painter.end()
    return pixmap


class CPSSplashScreen(QSplashScreen):
    def __init__(self):
        super().__init__(_build_splash_pixmap())
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)

        self.progress = QProgressBar(self)
        self.progress.setGeometry(40, 280, 440, 8)
        self.progress.setTextVisible(False)
        self.progress.setStyleSheet(
            "QProgressBar { background-color: #123F82; border-radius: 4px; }"
            "QProgressBar::chunk { background-color: #D4AF37; border-radius: 4px; }"
        )

    def set_progress(self, value: int, message: str = ""):
        animate_progress(self.progress, value, duration=260)
        if message:
            self.showMessage(
                message, Qt.AlignBottom | Qt.AlignHCenter, QColor("#C7D6EC")
            )
