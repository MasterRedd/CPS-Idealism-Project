from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QFrame, QSizePolicy, QMessageBox
)

from ui.pages.report_export import (
    ExportRangeDialog, build_attendance_report, build_irl_report,
    export_workbook_interactive, build_students_report, build_officers_report,
    build_patrols_report, build_incidents_report, build_confiscated_report,
)


class ReportCard(QFrame):
    def __init__(self, icon: str, title: str, description: str, on_export):
        super().__init__()
        self.setProperty("class", "card")
        self.setStyleSheet(
            "QFrame { background-color: white; border-radius: 10px; border: 1px solid #E2E7EE; "
            "border-left: 4px solid #D4AF37; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(8)

        head = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setStyleSheet("font-size: 22px;")
        head.addWidget(icon_label)
        title_label = QLabel(title)
        title_label.setStyleSheet("font-size: 15px; font-weight: 700; color: #0A2E5C;")
        head.addWidget(title_label)
        head.addStretch()
        layout.addLayout(head)

        desc_label = QLabel(description)
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet("font-size: 12px; color: #6f8299;")
        layout.addWidget(desc_label)

        layout.addStretch()

        export_btn = QPushButton("📊 Export to Excel")
        export_btn.setObjectName("primaryButton")
        export_btn.clicked.connect(on_export)
        layout.addWidget(export_btn)

        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumHeight(150)


class ReportsPage(QWidget):
    def __init__(self, db_manager=None, current_user=None):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user or {}
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        title = QLabel("Reports")
        title.setObjectName("stubTitle")
        layout.addWidget(title)

        subtitle = QLabel(
            "Generate polished Excel (.xlsx) reports — themed, ready to review, print, or share."
        )
        subtitle.setObjectName("stubSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        grid = QGridLayout()
        grid.setSpacing(16)

        cards = [
            ("🎓", "Student Reports", "Full student directory: status, grade/section, incident count, community service hours.",
             self._export_students),
            ("🛡️", "Officer Reports", "Officer directory: rank, position, assignment, account role, current duty status.",
             self._export_officers),
            ("🚶", "Patrol Reports", "Every patrol log: officer, campus/building, start/end time, status, remarks.",
             self._export_patrols),
            ("📋", "Incident Reports", "Full case list: student, officer, severity, case stage, description, resolution.",
             self._export_incidents),
            ("📦", "Confiscated Reports", "Confiscated item log: student, officer, item, quantity, reason, return status.",
             self._export_confiscated),
            ("🕒", "Attendance Reports", "Officer login/logout attendance — pick a specific day, month, or year.",
             self._export_attendance),
            ("📖", "IRL Sign Book Reports", "Physical sign-in/out log — pick a specific day, month, or year.",
             self._export_irl),
        ]

        for idx, (icon, title_txt, desc, handler) in enumerate(cards):
            row, col = divmod(idx, 2)
            grid.addWidget(ReportCard(icon, title_txt, desc, handler), row, col)

        layout.addLayout(grid)
        layout.addStretch()

    # ------------------------------------------------------------------
    def _guarded(self, builder):
        if not self.db:
            return
        try:
            title, sheets = builder(self.db, self.current_user.get("mcat_code"))
        except Exception as e:
            QMessageBox.warning(self, "Report error", f"Could not build the report:\n{e}")
            return
        export_workbook_interactive(self, title, sheets)

    def _export_students(self):
        self._guarded(lambda db, mcat: build_students_report(db, mcat_code=mcat))

    def _export_officers(self):
        self._guarded(lambda db, mcat: build_officers_report(db, mcat_code=mcat))

    def _export_patrols(self):
        self._guarded(lambda db, mcat: build_patrols_report(db, mcat_code=mcat))

    def _export_incidents(self):
        self._guarded(lambda db, mcat: build_incidents_report(db, mcat_code=mcat))

    def _export_confiscated(self):
        self._guarded(lambda db, mcat: build_confiscated_report(db, mcat_code=mcat))

    def _export_attendance(self):
        dialog = ExportRangeDialog(
            report_builder=lambda scope, year, month, day: build_attendance_report(self.db, scope, year, month, day, mcat_code=self.current_user.get("mcat_code")),
            default_title="Attendance Report",
            parent=self,
        )
        dialog.exec()

    def _export_irl(self):
        dialog = ExportRangeDialog(
            report_builder=lambda scope, year, month, day: build_irl_report(self.db, scope, year, month, day, mcat_code=self.current_user.get("mcat_code")),
            default_title="IRL Sign Book Report",
            parent=self,
        )
        dialog.exec()
