from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QComboBox, QTextEdit,
    QDateEdit, QDialogButtonBox, QLabel, QHBoxLayout
)
from PySide6.QtCore import QDate, Qt

from ui.widgets.photo_picker import PhotoPicker
from ui.widgets.scrollable import make_scrollable


class StudentFormDialog(QDialog):
    """Add or edit a single student. Pass `student` (a dict) to pre-fill for editing."""

    STATUS_OPTIONS = ["Good Standing", "Suspicious", "Under Investigation", "Suspended"]
    GENDER_OPTIONS = ["Male", "Female", "Other"]

    def __init__(self, db_manager, student: dict = None, parent=None, mcat_code: str = None):
        super().__init__(parent)
        self.db = db_manager
        self.mcat_code = mcat_code
        self.student = student
        self.is_edit = student is not None

        self.setWindowTitle("Edit Student" if self.is_edit else "Add Student")
        self.setMinimumWidth(420)
        self._build_ui()
        if self.is_edit:
            self._populate_fields()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.photo_picker = PhotoPicker()
        form.addRow("Photo", self.photo_picker)

        self.student_number_input = QLineEdit()
        self.student_number_input.setPlaceholderText("e.g. 2026-00123")
        form.addRow("Student Number *", self.student_number_input)

        self.full_name_input = QLineEdit()
        form.addRow("Full Name *", self.full_name_input)

        self.gender_combo = QComboBox()
        self.gender_combo.addItems(self.GENDER_OPTIONS)
        form.addRow("Gender", self.gender_combo)

        self.birthday_input = QDateEdit()
        self.birthday_input.setCalendarPopup(True)
        self.birthday_input.setDisplayFormat("yyyy-MM-dd")
        self.birthday_input.setDate(QDate(2010, 1, 1))
        form.addRow("Birthday", self.birthday_input)

        self.grade_input = QLineEdit()
        self.grade_input.setPlaceholderText("e.g. Grade 10")
        form.addRow("Grade", self.grade_input)

        self.section_input = QLineEdit()
        form.addRow("Section", self.section_input)

        self.adviser_input = QLineEdit()
        form.addRow("Adviser", self.adviser_input)

        self.campus_combo = QComboBox()
        self._load_campuses()
        form.addRow("Campus", self.campus_combo)

        self.status_combo = QComboBox()
        self.status_combo.addItems(self.STATUS_OPTIONS)
        form.addRow("Status", self.status_combo)

        self.notes_input = QTextEdit()
        self.notes_input.setFixedHeight(70)
        form.addRow("Notes", self.notes_input)

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        make_scrollable(self)

    def _load_campuses(self):
        self.campus_combo.addItem("— No Campus —", None)
        try:
            for campus in self.db.get_campuses(mcat_code=self.mcat_code):
                self.campus_combo.addItem(campus["name"], campus["id"])
        except Exception:
            pass

    def _populate_fields(self):
        s = self.student
        self.photo_picker.photo_path = s.get("photo_path") or None
        self.photo_picker._refresh_preview()
        self.student_number_input.setText(s.get("student_number") or "")
        self.full_name_input.setText(s.get("full_name") or "")
        if s.get("gender") in self.GENDER_OPTIONS:
            self.gender_combo.setCurrentText(s["gender"])
        if s.get("birthday"):
            date = QDate.fromString(s["birthday"], "yyyy-MM-dd")
            if date.isValid():
                self.birthday_input.setDate(date)
        self.grade_input.setText(s.get("grade") or "")
        self.section_input.setText(s.get("section") or "")
        self.adviser_input.setText(s.get("adviser") or "")
        if s.get("campus_id"):
            idx = self.campus_combo.findData(s["campus_id"])
            if idx >= 0:
                self.campus_combo.setCurrentIndex(idx)
        if s.get("status") in self.STATUS_OPTIONS:
            self.status_combo.setCurrentText(s["status"])
        self.notes_input.setPlainText(s.get("notes") or "")

    def _on_save(self):
        student_number = self.student_number_input.text().strip()
        full_name = self.full_name_input.text().strip()

        if not student_number or not full_name:
            self.error_label.setText("Student Number and Full Name are required.")
            return

        exclude_id = self.student["id"] if self.is_edit else None
        if self.db.student_number_exists(student_number, exclude_id=exclude_id):
            self.error_label.setText("That Student Number is already in use.")
            return

        self.result_data = {
            "student_number": student_number,
            "full_name": full_name,
            "photo_path": self.photo_picker.value(),
            "gender": self.gender_combo.currentText(),
            "birthday": self.birthday_input.date().toString("yyyy-MM-dd"),
            "grade": self.grade_input.text().strip(),
            "section": self.section_input.text().strip(),
            "adviser": self.adviser_input.text().strip(),
            "campus_id": self.campus_combo.currentData(),
            "status": self.status_combo.currentText(),
            "notes": self.notes_input.toPlainText().strip(),
        }
        self.accept()
