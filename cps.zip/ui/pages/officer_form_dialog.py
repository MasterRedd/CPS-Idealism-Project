from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QComboBox, QDateEdit,
    QDialogButtonBox, QLabel, QCheckBox
)
from PySide6.QtCore import QDate

from ui.widgets.photo_picker import PhotoPicker
from ui.widgets.scrollable import make_scrollable


class OfficerFormDialog(QDialog):
    """
    Add or edit an officer. On ADD, this always creates a linked login
    account too — officers sign in with their own username/password,
    never the admin account, per the spec.

    On EDIT, the password field is optional: leave it blank to keep the
    officer's existing password unchanged.
    """

    GENDER_OPTIONS = ["Male", "Female", "Other"]
    RANK_OPTIONS = ["Cadet", "Corporal", "Sergeant", "Lieutenant", "Captain", "Commander"]
    ROLE_OPTIONS = ["Officer", "Chief Officer", "CAT Commander"]

    def __init__(self, db_manager, officer: dict = None, parent=None, mcat_code: str = None):
        super().__init__(parent)
        self.db = db_manager
        self.officer = officer
        self.is_edit = officer is not None
        self.mcat_code = mcat_code

        self.setWindowTitle("Edit Officer" if self.is_edit else "Add Officer")
        self.setMinimumWidth(440)
        self._build_ui()
        if self.is_edit:
            self._populate_fields()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.photo_picker = PhotoPicker()
        form.addRow("Photo", self.photo_picker)

        self.officer_number_input = QLineEdit()
        self.officer_number_input.setPlaceholderText("Officer / Student ID, e.g. CAT-2026-001")
        form.addRow("Officer ID *", self.officer_number_input)

        self.full_name_input = QLineEdit()
        form.addRow("Full Name *", self.full_name_input)

        self.gender_combo = QComboBox()
        self.gender_combo.addItems(self.GENDER_OPTIONS)
        form.addRow("Gender", self.gender_combo)

        self.birthday_input = QDateEdit()
        self.birthday_input.setCalendarPopup(True)
        self.birthday_input.setDisplayFormat("yyyy-MM-dd")
        self.birthday_input.setDate(QDate(2009, 1, 1))
        form.addRow("Birthday", self.birthday_input)

        self.grade_input = QLineEdit()
        self.grade_input.setPlaceholderText("e.g. Grade 11")
        form.addRow("Grade", self.grade_input)

        self.section_input = QLineEdit()
        form.addRow("Section", self.section_input)

        self.rank_combo = QComboBox()
        self.rank_combo.setEditable(True)
        self.rank_combo.addItems(self.RANK_OPTIONS)
        self.rank_combo.lineEdit().setPlaceholderText("Pick a suggestion or type your own rank")
        form.addRow("Rank", self.rank_combo)

        self.position_input = QLineEdit()
        self.position_input.setPlaceholderText("e.g. Squad Leader")
        form.addRow("Position", self.position_input)

        self.campus_combo = QComboBox()
        self._load_campuses()
        self.campus_combo.currentIndexChanged.connect(self._reload_buildings)
        form.addRow("Campus", self.campus_combo)

        self.building_combo = QComboBox()
        self._reload_buildings()
        form.addRow("Assigned Building", self.building_combo)

        form.addRow(QLabel("—  Login Account  —"))

        self.role_combo = QComboBox()
        self.role_combo.setEditable(True)
        self.role_combo.addItems(self.ROLE_OPTIONS)
        self.role_combo.lineEdit().setPlaceholderText("Pick a suggestion or type a custom role")
        form.addRow("Account Role", self.role_combo)

        role_hint = QLabel(
            "Custom roles get the same base access as \"Officer\". Only the 5 standard "
            "roles above unlock extra menus like Officers, Campuses, or Settings."
        )
        role_hint.setStyleSheet("color: #8ea0b3; font-size: 11px;")
        role_hint.setWordWrap(True)
        form.addRow("", role_hint)

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Used to log in to the app")
        form.addRow("Username *" if not self.is_edit else "Username", self.username_input)
        if self.is_edit:
            self.username_input.setEnabled(False)  # keep usernames stable once created

        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        if self.is_edit:
            self.password_input.setPlaceholderText("Leave blank to keep current password")
        else:
            self.password_input.setPlaceholderText("Set an initial password")
        form.addRow("Password" if self.is_edit else "Password *", self.password_input)

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        make_scrollable(self)

    def _load_campuses(self):
        self.campus_combo.addItem("— No Campus —", None)
        try:
            for campus in self.db.get_campuses(mcat_code=self.mcat_code):
                self.campus_combo.addItem(campus["name"], campus["id"])
        except Exception:
            pass

    def _reload_buildings(self):
        self.building_combo.clear()
        self.building_combo.addItem("— No Building —", None)
        campus_id = self.campus_combo.currentData()
        try:
            for building in self.db.get_buildings(campus_id=campus_id):
                self.building_combo.addItem(building["name"], building["id"])
        except Exception:
            pass

    def _populate_fields(self):
        o = self.officer
        self.photo_picker.photo_path = o.get("photo_path") or None
        self.photo_picker._refresh_preview()
        self.officer_number_input.setText(o.get("officer_number") or "")
        self.full_name_input.setText(o.get("full_name") or "")
        if o.get("gender") in self.GENDER_OPTIONS:
            self.gender_combo.setCurrentText(o["gender"])
        if o.get("birthday"):
            date = QDate.fromString(o["birthday"], "yyyy-MM-dd")
            if date.isValid():
                self.birthday_input.setDate(date)
        self.grade_input.setText(o.get("grade") or "")
        self.section_input.setText(o.get("section") or "")
        if o.get("rank"):
            self.rank_combo.setCurrentText(o["rank"])
        self.position_input.setText(o.get("position") or "")
        if o.get("campus_id"):
            idx = self.campus_combo.findData(o["campus_id"])
            if idx >= 0:
                self.campus_combo.setCurrentIndex(idx)
        self._reload_buildings()
        if o.get("assigned_building_id"):
            idx = self.building_combo.findData(o["assigned_building_id"])
            if idx >= 0:
                self.building_combo.setCurrentIndex(idx)
        if o.get("username"):
            self.username_input.setText(o["username"])
        if o.get("role"):
            self.role_combo.setCurrentText(o["role"])

    def _on_save(self):
        officer_number = self.officer_number_input.text().strip()
        full_name = self.full_name_input.text().strip()
        username = self.username_input.text().strip()
        password = self.password_input.text()

        if not officer_number or not full_name:
            self.error_label.setText("Officer ID and Full Name are required.")
            return

        exclude_id = self.officer["id"] if self.is_edit else None
        if self.db.officer_number_exists(officer_number, exclude_id=exclude_id):
            self.error_label.setText("That Officer ID is already in use.")
            return

        if not self.is_edit:
            if not username or not password:
                self.error_label.setText("Username and initial password are required for a new account.")
                return
            if self.db.username_exists(username, mcat_code=self.mcat_code):
                self.error_label.setText("That username is already taken.")
                return

        self.officer_data = {
            "officer_number": officer_number,
            "full_name": full_name,
            "photo_path": self.photo_picker.value(),
            "gender": self.gender_combo.currentText(),
            "birthday": self.birthday_input.date().toString("yyyy-MM-dd"),
            "grade": self.grade_input.text().strip(),
            "section": self.section_input.text().strip(),
            "rank": self.rank_combo.currentText().strip(),
            "position": self.position_input.text().strip(),
            "campus_id": self.campus_combo.currentData(),
            "assigned_building_id": self.building_combo.currentData(),
        }
        self.account_role = self.role_combo.currentText()
        self.username = username
        self.new_password = password  # may be blank on edit -> means "don't change"
        self.accept()
