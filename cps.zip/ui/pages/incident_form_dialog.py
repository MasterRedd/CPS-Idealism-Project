import os

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QComboBox, QTextEdit,
    QDialogButtonBox, QLabel, QHBoxLayout, QPushButton, QCompleter,
    QFileDialog, QListWidget, QListWidgetItem, QMessageBox
)
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QIcon

from ui.pages.image_viewer_dialog import ImageViewerDialog, is_image_file
from ui.widgets.scrollable import make_scrollable

IMAGE_FILE_FILTER = "Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp);;All Files (*)"


class IncidentFormDialog(QDialog):
    """Add or edit the core details of an incident. Case stage / resolution
    are handled separately in IncidentCaseDialog once a case exists — a
    brand new incident always starts at case_stage 'New'.

    Evidence: supports attaching multiple images. For a brand-new incident
    (no id yet), picked files are buffered in memory and handed back via
    result_data['evidence_paths'] so the page can save them once the
    incident row exists. When editing an existing incident, attach/remove
    is applied immediately against the evidence_locker table.
    """

    CATEGORY_OPTIONS = [
        "Bullying", "Vandalism", "Tardiness", "Fighting", "Cheating",
        "Dress Code Violation", "Trespassing", "Theft", "Other",
    ]
    SEVERITY_OPTIONS = ["Low", "Medium", "High", "Critical"]

    def __init__(self, db_manager, incident: dict = None, current_user: dict = None, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.incident = incident
        self.is_edit = incident is not None
        self.incident_id = incident["id"] if incident else None
        self.current_user = current_user or {}

        # Buffer of newly-picked file paths not yet saved anywhere (new incident only)
        self._pending_new_evidence = []
        # Evidence already persisted (edit mode only) — kept in sync with the DB
        self._existing_evidence = []

        self.setWindowTitle("Edit Incident" if self.is_edit else "Record Incident")
        self.setMinimumWidth(520)
        self._build_ui()
        if self.is_edit:
            self._populate_fields()
        self._refresh_evidence_list()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.student_combo = QComboBox()
        self.student_combo.setEditable(True)
        self._load_students()
        self.student_combo.setInsertPolicy(QComboBox.NoInsert)
        completer = QCompleter([self.student_combo.itemText(i) for i in range(self.student_combo.count())])
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setFilterMode(Qt.MatchContains)
        self.student_combo.setCompleter(completer)
        form.addRow("Student *", self.student_combo)

        self.officer_combo = QComboBox()
        self._load_officers()
        form.addRow("Reporting Officer", self.officer_combo)

        self.campus_combo = QComboBox()
        self._load_campuses()
        self.campus_combo.currentIndexChanged.connect(self._reload_buildings)
        form.addRow("Campus", self.campus_combo)

        self.building_combo = QComboBox()
        self._reload_buildings()
        form.addRow("Building", self.building_combo)

        self.category_combo = QComboBox()
        self.category_combo.setEditable(True)
        self.category_combo.addItems(self.CATEGORY_OPTIONS)
        form.addRow("Category *", self.category_combo)

        self.severity_combo = QComboBox()
        self.severity_combo.addItems(self.SEVERITY_OPTIONS)
        form.addRow("Severity", self.severity_combo)

        self.description_input = QTextEdit()
        self.description_input.setFixedHeight(90)
        form.addRow("Description *", self.description_input)

        layout.addLayout(form)

        # ---- Evidence gallery ----
        evidence_header = QHBoxLayout()
        evidence_title = QLabel("Evidence Photos")
        evidence_title.setStyleSheet("font-weight: 700; color: #10233F;")
        evidence_header.addWidget(evidence_title)
        evidence_header.addStretch()
        attach_btn = QPushButton("+ Attach Photos")
        attach_btn.clicked.connect(self._on_attach_evidence)
        evidence_header.addWidget(attach_btn)
        layout.addLayout(evidence_header)

        self.evidence_list = QListWidget()
        self.evidence_list.setViewMode(QListWidget.IconMode)
        self.evidence_list.setIconSize(QSize(84, 84))
        self.evidence_list.setResizeMode(QListWidget.Adjust)
        self.evidence_list.setMovement(QListWidget.Static)
        self.evidence_list.setFixedHeight(120)
        self.evidence_list.setSpacing(6)
        self.evidence_list.itemDoubleClicked.connect(self._on_preview_evidence)
        layout.addWidget(self.evidence_list)

        evidence_actions = QHBoxLayout()
        self.evidence_hint = QLabel("Double-click a photo to preview. Select and remove to detach.")
        self.evidence_hint.setStyleSheet("color: #7A8CA6; font-size: 11px;")
        evidence_actions.addWidget(self.evidence_hint, 1)
        remove_btn = QPushButton("Remove Selected")
        remove_btn.clicked.connect(self._on_remove_evidence)
        evidence_actions.addWidget(remove_btn)
        layout.addLayout(evidence_actions)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        make_scrollable(self)

    def _load_students(self):
        self.student_combo.addItem("— Select Student —", None)
        try:
            for s in self.db.get_students(mcat_code=self.current_user.get('mcat_code')):
                label = f"{s['full_name']} ({s.get('student_number') or '—'})"
                self.student_combo.addItem(label, s["id"])
        except Exception:
            pass

    def _load_officers(self):
        self.officer_combo.addItem("— No Officer —", None)
        try:
            for o in self.db.get_officers(mcat_code=self.current_user.get('mcat_code')):
                self.officer_combo.addItem(o["full_name"], o["id"])
        except Exception:
            pass

    def _load_campuses(self):
        self.campus_combo.addItem("— No Campus —", None)
        try:
            for c in self.db.get_campuses(mcat_code=self.current_user.get('mcat_code')):
                self.campus_combo.addItem(c["name"], c["id"])
        except Exception:
            pass

    def _reload_buildings(self):
        self.building_combo.clear()
        self.building_combo.addItem("— No Building —", None)
        campus_id = self.campus_combo.currentData()
        try:
            for b in self.db.get_buildings(campus_id=campus_id):
                self.building_combo.addItem(b["name"], b["id"])
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Evidence gallery
    # ------------------------------------------------------------------
    def _current_evidence_paths(self):
        """All evidence file paths currently attached (existing + pending), in display order."""
        paths = [e.get("file_path") for e in self._existing_evidence]
        paths.extend(self._pending_new_evidence)
        return paths

    def _refresh_evidence_list(self):
        legacy = []
        if self.is_edit and self.incident_id:
            all_items = self.db.get_evidence_for_incident(self.incident_id)
            self._existing_evidence = [e for e in all_items if not e.get("legacy")]
            legacy = [e for e in all_items if e.get("legacy")]

        self.evidence_list.clear()
        for entry in legacy:
            self._add_thumbnail(entry.get("file_path"), removable=False)
        for entry in self._existing_evidence:
            self._add_thumbnail(entry.get("file_path"), removable=True, evidence_id=entry.get("id"))
        for path in self._pending_new_evidence:
            self._add_thumbnail(path, removable=True, pending=True)

    def _add_thumbnail(self, path, removable=True, evidence_id=None, pending=False):
        if not path:
            return
        name = os.path.basename(path)
        item = QListWidgetItem(name if len(name) < 16 else name[:13] + "…")
        item.setToolTip(path)
        if is_image_file(path) and os.path.exists(path):
            pix = QPixmap(path).scaled(84, 84, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            item.setIcon(QIcon(pix))
        item.setData(Qt.UserRole, {
            "path": path, "removable": removable, "evidence_id": evidence_id, "pending": pending,
        })
        self.evidence_list.addItem(item)

    def _on_attach_evidence(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Attach Evidence Photos", "", IMAGE_FILE_FILTER)
        if not paths:
            return
        if self.is_edit and self.incident_id:
            actor = self.current_user.get("id")
            for p in paths:
                self.db.add_evidence(self.incident_id, p, added_by=actor)
        else:
            self._pending_new_evidence.extend(paths)
        self._refresh_evidence_list()

    def _on_remove_evidence(self):
        item = self.evidence_list.currentItem()
        if not item:
            QMessageBox.information(self, "No selection", "Select a photo to remove first.")
            return
        data = item.data(Qt.UserRole)
        if not data.get("removable"):
            QMessageBox.information(self, "Can't remove",
                                     "This is a legacy attachment and can't be removed here.")
            return
        if data.get("pending"):
            self._pending_new_evidence.remove(data["path"])
        else:
            self.db.delete_evidence(data["evidence_id"], actor_user_id=self.current_user.get("id"))
        self._refresh_evidence_list()

    def _on_preview_evidence(self, item):
        data = item.data(Qt.UserRole)
        paths = self._current_evidence_paths()
        try:
            start_index = paths.index(data["path"])
        except ValueError:
            start_index = 0
        gallery = [{"file_path": p} for p in paths]
        viewer = ImageViewerDialog(gallery, start_index=start_index, parent=self)
        viewer.exec()

    # ------------------------------------------------------------------
    def _populate_fields(self):
        i = self.incident
        if i.get("student_id"):
            idx = self.student_combo.findData(i["student_id"])
            if idx >= 0:
                self.student_combo.setCurrentIndex(idx)
        if i.get("officer_id"):
            idx = self.officer_combo.findData(i["officer_id"])
            if idx >= 0:
                self.officer_combo.setCurrentIndex(idx)
        if i.get("campus_id"):
            idx = self.campus_combo.findData(i["campus_id"])
            if idx >= 0:
                self.campus_combo.setCurrentIndex(idx)
        self._reload_buildings()
        if i.get("building_id"):
            idx = self.building_combo.findData(i["building_id"])
            if idx >= 0:
                self.building_combo.setCurrentIndex(idx)
        if i.get("category"):
            self.category_combo.setCurrentText(i["category"])
        if i.get("severity") in self.SEVERITY_OPTIONS:
            self.severity_combo.setCurrentText(i["severity"])
        self.description_input.setPlainText(i.get("description") or "")

    def _on_save(self):
        student_id = self.student_combo.currentData()
        category = self.category_combo.currentText().strip()
        description = self.description_input.toPlainText().strip()

        if student_id is None:
            self.error_label.setText("Select the student involved.")
            return
        if not category:
            self.error_label.setText("Category is required.")
            return
        if not description:
            self.error_label.setText("A description is required.")
            return

        self.result_data = {
            "student_id": student_id,
            "officer_id": self.officer_combo.currentData(),
            "campus_id": self.campus_combo.currentData(),
            "building_id": self.building_combo.currentData(),
            "category": category,
            "severity": self.severity_combo.currentText(),
            "description": description,
            # New-incident evidence buffered here; page saves these after create()
            "evidence_paths": list(self._pending_new_evidence),
        }
        self.accept()
