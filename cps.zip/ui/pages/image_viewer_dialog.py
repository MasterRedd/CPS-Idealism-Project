import os

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QGraphicsView,
    QGraphicsScene, QGraphicsPixmapItem, QSizePolicy, QFrame
)
from PySide6.QtGui import QPixmap, QKeySequence, QShortcut, QPainter, QGuiApplication
from PySide6.QtCore import Qt, QTimer

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp"}


def is_image_file(path: str) -> bool:
    if not path:
        return False
    return os.path.splitext(path)[1].lower() in IMAGE_EXTENSIONS


class _ZoomableGraphicsView(QGraphicsView):
    """Graphics view supporting mouse-wheel zoom and click-drag panning,
    tuned for photo-quality rendering (full antialiasing, smooth pixmap
    transform, high-quality full-viewport updates, no bitmap caching)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setRenderHints(
            QPainter.Antialiasing
            | QPainter.SmoothPixmapTransform
            | QPainter.TextAntialiasing
        )
        self.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)
        self.setCacheMode(QGraphicsView.CacheNone)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorUnderMouse)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self._zoom = 1.0
        self.zoom_changed = None  # callback(float), set externally

    def set_zoom_callback(self, cb):
        self.zoom_changed = cb

    def _apply_zoom(self, factor, new_zoom):
        self._zoom = new_zoom
        self.scale(factor, factor)
        if self.zoom_changed:
            self.zoom_changed(self._zoom)

    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        new_zoom = self._zoom * factor
        if 0.05 <= new_zoom <= 20:
            self._apply_zoom(factor, new_zoom)

    def reset_zoom(self):
        self.resetTransform()
        self._zoom = 1.0
        if self.zoom_changed:
            self.zoom_changed(self._zoom)

    def zoom_in(self):
        if self._zoom < 20:
            self._apply_zoom(1.25, self._zoom * 1.25)

    def zoom_out(self):
        if self._zoom > 0.05:
            self._apply_zoom(1 / 1.25, self._zoom / 1.25)

    def mouseDoubleClickEvent(self, event):
        parent = self.parent()
        if parent is not None and hasattr(parent, "_toggle_fit_actual"):
            parent._toggle_fit_actual()
        super().mouseDoubleClickEvent(event)


class ImageViewerDialog(QDialog):
    """Full in-app evidence viewer. Pass a list of evidence dicts
    (each needs at least 'file_path') and the index to open first.
    Supports zoom (mouse wheel / buttons / double-click), click-and-drag
    panning, and Next/Prev navigation between all attached evidence.

    Rendering quality: pixmaps are loaded at native resolution and tagged
    with the screen's device pixel ratio so they render crisply on HiDPI
    displays instead of looking soft; the view uses full-viewport updates
    with antialiasing + smooth pixmap transform and no bitmap caching, and
    the dialog opens large (most of the screen) so photos aren't squeezed
    into a small box before you even start zooming.
    """

    def __init__(self, evidence_items: list, start_index: int = 0, parent=None):
        super().__init__(parent)
        self.items = evidence_items or []
        self.index = max(0, min(start_index, len(self.items) - 1)) if self.items else 0
        self._fitted = True  # tracks whether we're in "fit to window" mode

        self.setWindowTitle("Evidence Viewer")
        self.setMinimumSize(760, 560)
        self._size_to_screen()
        self._build_ui()
        self._load_current()

        QShortcut(QKeySequence(Qt.Key_Right), self, activated=self.show_next)
        QShortcut(QKeySequence(Qt.Key_Left), self, activated=self.show_prev)
        QShortcut(QKeySequence(Qt.Key_Escape), self, activated=self.close)
        QShortcut(QKeySequence(Qt.Key_Plus), self, activated=self._zoom_in)
        QShortcut(QKeySequence(Qt.Key_Equal), self, activated=self._zoom_in)
        QShortcut(QKeySequence(Qt.Key_Minus), self, activated=self._zoom_out)
        QShortcut(QKeySequence(Qt.Key_0), self, activated=self._zoom_fit)

    # ------------------------------------------------------------------
    def _size_to_screen(self):
        """Open large by default — more on-screen pixels means less
        downscaling and a visibly sharper photo right from the start."""
        screen = QGuiApplication.primaryScreen()
        if screen:
            geo = screen.availableGeometry()
            w = min(int(geo.width() * 0.82), 1500)
            h = min(int(geo.height() * 0.85), 1100)
            self.resize(max(w, 900), max(h, 640))
        else:
            self.resize(1100, 760)

    def _build_ui(self):
        self.setStyleSheet(
            "QDialog { background-color: #10233F; }"
            "QLabel { color: #EAF0FA; }"
            "QPushButton { background-color: #16407A; color: #EAF0FA; border: none; "
            "padding: 7px 14px; border-radius: 6px; font-weight: 600; }"
            "QPushButton:hover { background-color: #1D5AA8; }"
            "QPushButton:disabled { background-color: #1a2f4d; color: #6f84a3; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        top_row = QHBoxLayout()
        self.title_label = QLabel("")
        self.title_label.setStyleSheet("font-size: 14px; font-weight: 700; color: #EAF0FA;")
        top_row.addWidget(self.title_label, 1)
        self.zoom_label = QLabel("")
        self.zoom_label.setStyleSheet("color: #9FB4D6; font-weight: 600;")
        top_row.addWidget(self.zoom_label)
        self.counter_label = QLabel("")
        self.counter_label.setStyleSheet("color: #C9A227; font-weight: 700; margin-left: 12px;")
        top_row.addWidget(self.counter_label)
        layout.addLayout(top_row)

        self.scene = QGraphicsScene(self)
        self.view = _ZoomableGraphicsView(self)
        self.view.setScene(self.scene)
        self.view.setFrameShape(QFrame.NoFrame)
        self.view.setStyleSheet("background-color: #0B1B34;")
        self.view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.view.set_zoom_callback(self._on_zoom_changed)
        layout.addWidget(self.view, 1)

        self.unsupported_label = QLabel("")
        self.unsupported_label.setAlignment(Qt.AlignCenter)
        self.unsupported_label.setStyleSheet("color: #C9A227; font-size: 13px; padding: 20px;")
        self.unsupported_label.setVisible(False)
        layout.addWidget(self.unsupported_label)

        controls = QHBoxLayout()
        self.prev_btn = QPushButton("◀ Prev")
        self.prev_btn.clicked.connect(self.show_prev)
        controls.addWidget(self.prev_btn)

        self.zoom_out_btn = QPushButton("－ Zoom Out")
        self.zoom_out_btn.clicked.connect(self._zoom_out)
        controls.addWidget(self.zoom_out_btn)

        self.zoom_fit_btn = QPushButton("Fit to Window")
        self.zoom_fit_btn.clicked.connect(self._zoom_fit)
        controls.addWidget(self.zoom_fit_btn)

        self.zoom_actual_btn = QPushButton("Actual Size (100%)")
        self.zoom_actual_btn.clicked.connect(self._zoom_actual)
        controls.addWidget(self.zoom_actual_btn)

        self.zoom_in_btn = QPushButton("＋ Zoom In")
        self.zoom_in_btn.clicked.connect(self._zoom_in)
        controls.addWidget(self.zoom_in_btn)

        self.open_ext_btn = QPushButton("Open Externally")
        self.open_ext_btn.clicked.connect(self._open_externally)
        controls.addWidget(self.open_ext_btn)

        controls.addStretch()

        self.next_btn = QPushButton("Next ▶")
        self.next_btn.clicked.connect(self.show_next)
        controls.addWidget(self.next_btn)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        controls.addWidget(close_btn)

        layout.addLayout(controls)

        hint = QLabel("Scroll or ＋/－ to zoom · Drag to pan · Double-click to zoom in/out · ← → to switch photos")
        hint.setStyleSheet("color: #7C93B8; font-size: 11px;")
        hint.setAlignment(Qt.AlignCenter)
        layout.addWidget(hint)

    # ------------------------------------------------------------------
    def _current_path(self):
        if not self.items:
            return None
        return self.items[self.index].get("file_path")

    def _screen_dpr(self) -> float:
        screen = self.screen() or QGuiApplication.primaryScreen()
        return screen.devicePixelRatio() if screen else 1.0

    def _load_current(self):
        self.scene.clear()
        self.view.reset_zoom()
        self._fitted = True

        total = len(self.items)
        self.counter_label.setText(f"{self.index + 1} / {total}" if total else "0 / 0")
        self.prev_btn.setEnabled(self.index > 0)
        self.next_btn.setEnabled(self.index < total - 1)

        path = self._current_path()
        if not path:
            self.title_label.setText("No evidence attached")
            self.unsupported_label.setVisible(True)
            self.unsupported_label.setText("Nothing to display.")
            self.view.setVisible(False)
            self._set_zoom_controls_enabled(False)
            self.zoom_label.setText("")
            return

        self.title_label.setText(os.path.basename(path))

        if is_image_file(path) and os.path.exists(path):
            pixmap = QPixmap(path)
            if not pixmap.isNull():
                # Tag with the screen's device pixel ratio so Qt treats the
                # pixmap's native pixels correctly at 100% zoom on HiDPI
                # screens, instead of stretching it and looking soft.
                pixmap.setDevicePixelRatio(self._screen_dpr())
                self.view.setVisible(True)
                self.unsupported_label.setVisible(False)
                item = QGraphicsPixmapItem(pixmap)
                item.setTransformationMode(Qt.SmoothTransformation)
                self.scene.addItem(item)
                self.scene.setSceneRect(item.boundingRect())
                self._set_zoom_controls_enabled(True)
                # Defer fit-to-view until the widget actually has its final
                # on-screen size — fitting immediately in __init__ can
                # compute against a not-yet-laid-out viewport and looks
                # tiny/blurry the first time the dialog opens.
                QTimer.singleShot(0, self._zoom_fit)
                return

        # Fallback: not a viewable image (missing file, or non-image evidence)
        self.view.setVisible(False)
        self._set_zoom_controls_enabled(False)
        self.zoom_label.setText("")
        self.unsupported_label.setVisible(True)
        if not os.path.exists(path):
            self.unsupported_label.setText(
                "This file could not be found at its saved location."
            )
        else:
            self.unsupported_label.setText(
                "This file type can't be previewed in-app.\nUse \"Open Externally\" to view it."
            )

    def _set_zoom_controls_enabled(self, enabled: bool):
        for btn in (self.zoom_out_btn, self.zoom_fit_btn, self.zoom_actual_btn, self.zoom_in_btn):
            btn.setEnabled(enabled)

    def _on_zoom_changed(self, zoom_factor):
        self.zoom_label.setText(f"{round(zoom_factor * 100)}%")

    # ------------------------------------------------------------------
    def show_next(self):
        if self.index < len(self.items) - 1:
            self.index += 1
            self._load_current()

    def show_prev(self):
        if self.index > 0:
            self.index -= 1
            self._load_current()

    def _zoom_in(self):
        if self.view.isVisible():
            self._fitted = False
            self.view.zoom_in()

    def _zoom_out(self):
        if self.view.isVisible():
            self._fitted = False
            self.view.zoom_out()

    def _zoom_fit(self):
        if self.view.isVisible() and self.scene.items():
            self.view.reset_zoom()
            self.view.fitInView(self.scene.items()[0], Qt.KeepAspectRatio)
            effective = self.view.transform().m11()
            self.view._zoom = effective
            self._on_zoom_changed(effective)
            self._fitted = True

    def _zoom_actual(self):
        if self.view.isVisible() and self.scene.items():
            self.view.resetTransform()
            self.view._zoom = 1.0
            self._on_zoom_changed(1.0)
            self._fitted = False

    def _toggle_fit_actual(self):
        if self._fitted:
            self._zoom_actual()
        else:
            self._zoom_fit()

    def _open_externally(self):
        path = self._current_path()
        if path and os.path.exists(path):
            from PySide6.QtGui import QDesktopServices
            from PySide6.QtCore import QUrl
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._fitted and self.view.isVisible() and self.scene.items():
            self.view.fitInView(self.scene.items()[0], Qt.KeepAspectRatio)
            self._on_zoom_changed(self.view.transform().m11())
