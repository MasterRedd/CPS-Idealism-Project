from datetime import date

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView,
    QComboBox
)
from PySide6.QtGui import QColor

from ui.pages.confiscated_form_dialog import ConfiscatedFormDialog
from ui.pages.image_viewer_dialog import ImageViewerDialog

# Per spec: Officer "can confiscate items" but "cannot delete records";
# Viewer is read-only across the board.
CAN_EDIT_ROLES = {"Administrator", "CAT Commander", "Chief Officer", "Officer"}
CAN_DELETE_ROLES = {"Administrator", "CAT Commander"}

COLUMNS = ["ID", "Student", "Item", "Qty", "Officer", "Reason", "Status", "Date"]
STATUS_OPTIONS = ["All", "Returned", "Not Returned"]

STATUS_COLORS = {
    "Returned": QColor("#1e9e5a"),
    "Not Returned": QColor("#c98a1c"),
}


class ConfiscatedPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self.can_edit = current_user.get("effective_role", current_user["role"]) in CAN_EDIT_ROLES
        self.can_delete = current_user.get("effective_role", current_user["role"]) in CAN_DELETE_ROLES

        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        header_row = QHBoxLayout()
        title = QLabel("Confiscated Items")
        title.setObjectName("stubTitle")
        header_row.addWidget(title)
        header_row.addStretch()

        self.add_btn = QPushButton("+ Log Confiscated Item")
        self.add_btn.setObjectName("primaryButton")
        self.add_btn.clicked.connect(self._on_add)
        self.add_btn.setVisible(self.can_edit)
        header_row.addWidget(self.add_btn)
        layout.addLayout(header_row)

        subtitle = QLabel(
            "Track items confiscated from students, with photo evidence and return status."
        )
        subtitle.setObjectName("stubSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        filter_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by student, officer, item, or reason...")
        self.search_input.textChanged.connect(self.refresh)
        filter_row.addWidget(self.search_input, 1)

        self.status_filter = QComboBox()
        self.status_filter.addItems(STATUS_OPTIONS)
        self.status_filter.currentTextChanged.connect(self.refresh)
        filter_row.addWidget(self.status_filter)
        layout.addLayout(filter_row)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnHidden(0, True)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        self.table.setStyleSheet(
            "QTableWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; }"
            "QHeaderView::section { background-color: #0A2E5C; color: #ffffff; padding: 7px; border: none; font-weight: 600; }"
        )
        self.table.doubleClicked.connect(self._on_view_evidence)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        action_row.addStretch()

        self.evidence_btn = QPushButton("View Evidence")
        self.evidence_btn.clicked.connect(self._on_view_evidence)
        action_row.addWidget(self.evidence_btn)

        self.edit_btn = QPushButton("Edit")
        self.edit_btn.clicked.connect(self._on_edit)
        self.edit_btn.setVisible(self.can_edit)
        action_row.addWidget(self.edit_btn)

        self.return_btn = QPushButton("Toggle Returned")
        self.return_btn.clicked.connect(self._on_toggle_returned)
        self.return_btn.setVisible(self.can_edit)
        action_row.addWidget(self.return_btn)

        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setStyleSheet("color: #d9453d;")
        self.delete_btn.clicked.connect(self._on_delete)
        self.delete_btn.setVisible(self.can_delete)
        action_row.addWidget(self.delete_btn)

        layout.addLayout(action_row)

        self.count_label = QLabel("")
        self.count_label.setStyleSheet("color: #8ea0b3; font-size: 12px;")
        layout.addWidget(self.count_label)

    # ------------------------------------------------------------------
    def refresh(self):
        search = self.search_input.text().strip()
        status_filter = self.status_filter.currentText()
        items = self.db.get_confiscated_items(search=search, status_filter=status_filter, mcat_code=self.current_user.get("mcat_code"))

        self.table.setRowCount(0)
        for it in items:
            row = self.table.rowCount()
            self.table.insertRow(row)
            status = "Returned" if it.get("returned") else "Not Returned"
            values = [
                str(it["id"]),
                it.get("student_name") or "—",
                it.get("item_name") or "—",
                str(it.get("quantity") or 1),
                it.get("officer_name") or "—",
                it.get("reason") or "—",
                status,
                (it.get("date_confiscated") or "")[:16],
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 6:
                    item.setForeground(STATUS_COLORS.get(value, QColor("#10233F")))
                self.table.setItem(row, col, item)

        self.count_label.setText(f"{len(items)} item(s)")

    # ------------------------------------------------------------------
    def _selected_item_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return int(self.table.item(row, 0).text())

    def _on_add(self):
        dialog = ConfiscatedFormDialog(self.db, current_user=self.current_user, parent=self)
        if dialog.exec():
            data = dialog.result_data
            evidence_paths = data.pop("evidence_paths", [])
            item_id = self.db.create_confiscated_item(data, actor_user_id=self.current_user["id"])
            for path in evidence_paths:
                self.db.add_confiscated_evidence(item_id, path, added_by=self.current_user["id"])
            self.refresh()

    def _on_edit(self):
        item_id = self._selected_item_id()
        if item_id is None:
            QMessageBox.information(self, "No selection", "Select an item to edit first.")
            return
        item = self.db.get_confiscated_item(item_id)
        dialog = ConfiscatedFormDialog(self.db, item=item, current_user=self.current_user, parent=self)
        if dialog.exec():
            data = dialog.result_data
            data.pop("evidence_paths", None)  # already saved live during edit
            self.db.update_confiscated_item(item_id, data, actor_user_id=self.current_user["id"])
            self.refresh()

    def _on_toggle_returned(self):
        item_id = self._selected_item_id()
        if item_id is None:
            QMessageBox.information(self, "No selection", "Select an item first.")
            return
        item = self.db.get_confiscated_item(item_id)
        new_state = not bool(item.get("returned"))
        return_date = date.today().isoformat() if new_state else None
        self.db.set_confiscated_item_returned(
            item_id, new_state, return_date, actor_user_id=self.current_user["id"]
        )
        self.refresh()

    def _on_view_evidence(self):
        item_id = self._selected_item_id()
        if item_id is None:
            QMessageBox.information(self, "No selection", "Select an item to view evidence first.")
            return
        evidence = self.db.get_evidence_for_confiscated_item(item_id)
        if not evidence:
            QMessageBox.information(self, "No evidence", "No evidence photos attached to this item.")
            return
        viewer = ImageViewerDialog(evidence, start_index=0, parent=self)
        viewer.exec()

    def _on_delete(self):
        item_id = self._selected_item_id()
        if item_id is None:
            QMessageBox.information(self, "No selection", "Select an item to delete first.")
            return
        confirm = QMessageBox.question(
            self, "Confirm delete",
            "Remove this confiscated item from active records?\n\n"
            "This is a soft delete — the record is archived, not permanently erased.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_confiscated_item(item_id, actor_user_id=self.current_user["id"])
            self.refresh()
