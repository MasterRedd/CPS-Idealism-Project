"""
Scan IRL Log In / Scan IRL Log Out — lets an administrator run an officer's
IRL Sign Book entry through a QR-code scan instead of the officer needing
their own phone/account. Point the camera at the officer's ID card QR (or
pick a photo of it from disk), and this dialog:

  1. Decodes the QR and looks up the officer.
  2. Shows a brief "match found" confirmation (their name/photo) for a few
     seconds, functioning like a verification pause.
  3. Performs the actual IRL sign-in / sign-out against the database,
     applying the exact same one-session-per-day rules as the officer's own
     "IRL Sign Book" page.
  4. Reports the outcome back to the caller so it can be shown as a
     follow-up message (success, or a business-rule reason it didn't go
     through — already logged in, already completed today, etc.)
"""
import json
import time
from datetime import datetime

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog
)
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtCore import Qt, QTimer

from ui.pages.qr_utils import cv2, open_camera, decode_qr_from_frame, decode_qr_from_image_path

CONFIRM_SECONDS = 3.0


class QRAttendanceDialog(QDialog):
    """mode is either 'login' or 'logout'."""

    def __init__(self, db_manager, mode: str, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.mode = mode
        self.cap = None
        self._no_match_until = 0
        self._matched_officer_id = None

        # Set by _finish() so the caller (Officers page) can show a follow-up
        # QMessageBox once this dialog closes. Tuple of (title, message, is_error).
        self.result = None

        action_word = "Log In" if mode == "login" else "Log Out"
        self.setWindowTitle(f"Scan IRL {action_word}")
        self.setMinimumSize(540, 540)
        self._build_ui(action_word)

        if cv2 is None:
            self._show_no_camera("Camera support (OpenCV) isn't installed on this system.")
            return

        self.cap = open_camera()
        if not self.cap or not self.cap.isOpened():
            self._show_no_camera(
                "Could not access a camera on this device. Make sure no other "
                "app is using it and that camera access is allowed."
            )
            self.cap = None
            return

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(120)

    # ------------------------------------------------------------------
    def _build_ui(self, action_word):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel(f"Scan Officer QR — IRL {action_word}")
        title.setObjectName("stubTitle")
        layout.addWidget(title)

        hint = QLabel(
            f"Face the officer's ID card QR code toward the camera to record their IRL {action_word}."
        )
        hint.setWordWrap(True)
        hint.setObjectName("stubSubtitle")
        layout.addWidget(hint)

        self.video_label = QLabel()
        self.video_label.setFixedSize(480, 320)
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet("background: #101826; border-radius: 8px; color: #ffffff;")
        layout.addWidget(self.video_label, alignment=Qt.AlignCenter)

        self.status_label = QLabel("Scanning…")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("color: #5A6B7D; font-weight: 700; font-size: 14px;")
        layout.addWidget(self.status_label)

        self.detail_label = QLabel("")
        self.detail_label.setAlignment(Qt.AlignCenter)
        self.detail_label.setWordWrap(True)
        self.detail_label.setObjectName("stubSubtitle")
        layout.addWidget(self.detail_label)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.image_btn = QPushButton("📁 Use Image Instead")
        self.image_btn.clicked.connect(self._pick_image)
        btn_row.addWidget(self.image_btn)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

    def _show_no_camera(self, message):
        self.video_label.setText("📷\nNo live camera")
        self.status_label.setText("Camera unavailable")
        self.status_label.setStyleSheet("color: #d9453d; font-weight: 700;")
        self.detail_label.setText(message)

    # ------------------------------------------------------------------
    def _tick(self):
        if not self.cap:
            return
        ok, frame = self.cap.read()
        if not ok:
            return

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        pix = QPixmap.fromImage(qimg).scaled(
            self.video_label.width(), self.video_label.height(), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        self.video_label.setPixmap(pix)

        if time.time() < self._no_match_until:
            return

        data = decode_qr_from_frame(frame)
        if not data:
            return
        self._handle_decoded(data)

    def _pick_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select an image with a QR code", "", "Images (*.png *.jpg *.jpeg *.bmp *.webp)"
        )
        if not path:
            return
        data = decode_qr_from_image_path(path)
        if not data:
            self._flash_no_match("No QR code detected in that image.")
            return
        self._handle_decoded(data)

    # ------------------------------------------------------------------
    def _handle_decoded(self, data):
        officer_number = None
        try:
            payload = json.loads(data)
            if payload.get("type") == "CPS-OFFICER-ID":
                officer_number = payload.get("officer_number")
        except Exception:
            officer_number = None

        if not officer_number:
            self._flash_no_match("QR code not recognized.")
            return

        profile = self.db.get_officer_profile_by_number(officer_number)
        if not profile:
            self._flash_no_match("No match found for this officer.")
            return

        self._pause_scanning()
        self._show_match_confirmation(profile)
        QTimer.singleShot(int(CONFIRM_SECONDS * 1000), lambda: self._finish(profile))

    def _show_match_confirmation(self, profile):
        self.status_label.setText(f"✔ Match found: {profile.get('full_name', 'Unknown')}")
        self.status_label.setStyleSheet("color: #1e9e5a; font-weight: 700; font-size: 14px;")
        self.detail_label.setText(
            f"Officer No. {profile.get('officer_number', '—')}  ·  Verifying…"
        )
        self.image_btn.setEnabled(False)

    def _pause_scanning(self):
        if getattr(self, "timer", None):
            self.timer.stop()

    def _flash_no_match(self, message):
        self.status_label.setText(message)
        self.status_label.setStyleSheet("color: #d9453d; font-weight: 700;")
        self.detail_label.setText("")
        self._no_match_until = time.time() + 2.0
        QTimer.singleShot(2000, self._reset_status)

    def _reset_status(self):
        self.status_label.setText("Scanning…")
        self.status_label.setStyleSheet("color: #5A6B7D; font-weight: 700; font-size: 14px;")

    # ------------------------------------------------------------------
    def _finish(self, profile):
        """Runs the actual sign-in/out business logic, stores the outcome in
        self.result, then closes the dialog. The caller shows the message."""
        officer_id = profile["id"]
        name = profile.get("full_name", "Officer")
        number = profile.get("officer_number", "—")
        who = f"{name} ({number})"

        if self.mode == "login":
            existing = self.db.get_irl_today(officer_id)
            if existing and existing.get("logout_time"):
                self.result = (
                    "Duty Already Completed",
                    f"{who} has already completed IRL duty for today.\n"
                    f"Duty is already done — please wait until tomorrow to log in again.",
                    True,
                )
            elif existing and not existing.get("logout_time"):
                self.result = (
                    "Already Logged In",
                    f"{who} is logged in already. Duty is already in progress.",
                    True,
                )
            else:
                self.db.irl_sign_in(officer_id)
                now_str = datetime.now().strftime("%I:%M %p")
                self.result = (
                    "IRL Log In Recorded",
                    f"{who} is now IRL Logged In.\nDuty started at {now_str}. Timer is running.",
                    False,
                )
        else:  # logout
            existing = self.db.get_irl_today(officer_id)
            if not existing:
                self.result = (
                    "Not Logged In",
                    f"{who} has not logged in for IRL duty today, so there's nothing to log out of.",
                    True,
                )
            elif existing.get("logout_time"):
                self.result = (
                    "Already Logged Out",
                    f"{who} is logged out already. Duty is finished for today.",
                    True,
                )
            else:
                self.db.irl_sign_out(officer_id, existing["id"])
                updated = self.db.get_irl_record_for_date(officer_id, existing["date"])
                hours = updated.get("hours_worked") if updated else None
                hours_txt = f"{hours:.2f} hrs" if hours is not None else "—"
                self.result = (
                    "IRL Log Out Recorded",
                    f"{who} is now IRL Logged Out.\nDuty finished. Time recorded: {hours_txt}.",
                    False,
                )

        self._stop_camera()
        self.accept()

    def _stop_camera(self):
        if getattr(self, "timer", None):
            self.timer.stop()
        if self.cap:
            self.cap.release()
            self.cap = None

    def reject(self):
        self._stop_camera()
        super().reject()

    def closeEvent(self, event):
        self._stop_camera()
        super().closeEvent(event)
