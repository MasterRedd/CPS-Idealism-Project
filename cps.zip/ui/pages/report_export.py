"""
Excel export support for Monthly Attendance and the IRL Sign Book.

Lets an admin pick a single Day, a Month, or a whole Year, builds one or more
themed worksheets for that range with openpyxl, and either saves the workbook
as a real .xlsx file or opens it straight in the system's default spreadsheet
app (Excel / LibreOffice Calc) so it can be reviewed and printed from there —
letting the spreadsheet app handle pagination, page setup, etc. properly
instead of us faking a print layout ourselves.
"""

import calendar
import os
import subprocess
import sys
import tempfile
from datetime import date as date_cls

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QDateEdit, QFileDialog, QMessageBox, QRadioButton, QButtonGroup
)
from PySide6.QtCore import QDate

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ----------------------------------------------------------------------
# Brand palette (matches the app's Blue / Gold / White theme)
# ----------------------------------------------------------------------
NAVY = "0A2E5C"
NAVY_DARK = "10233F"
GOLD = "D4AF37"
WHITE = "FFFFFF"
LIGHT_BLUE = "EAF1FB"
GREEN = "E3F6E8"
GREEN_TEXT = "1E9E5A"
RED = "FBE9E7"
RED_TEXT = "D9453D"
WARNING = "FFF6DA"
WARNING_TEXT = "9A7B0A"
GREY = "F2F2F2"
GREY_TEXT = "6F8299"

THIN = Side(style="thin", color="CFD6DD")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


# ----------------------------------------------------------------------
# Generic themed sheet writer
# ----------------------------------------------------------------------
def write_sheet(wb, spec):
    """
    spec = {
        "name": str (<=31 chars),
        "title": str,
        "subtitle": str or None,
        "columns": [str, ...],
        "rows": [[val, ...], ...],
        "style_fn": optional callable(row_values, col_index) -> one of
                    "present" / "absent" / "blank" / "total" / None,
        "freeze_cols": how many leading columns to freeze (default 1),
        "landscape": bool,
        "col_widths": optional [int, ...] matching columns,
    }
    """
    name = spec["name"][:31]
    ws = wb.create_sheet(title=name)
    columns = spec["columns"]
    rows = spec["rows"]
    style_fn = spec.get("style_fn")
    n_cols = len(columns)

    # Title row
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(n_cols, 1))
    title_cell = ws.cell(row=1, column=1, value=spec["title"])
    title_cell.font = Font(name="Arial", size=16, bold=True, color=NAVY)
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 26

    subtitle = spec.get("subtitle")
    header_row = 2
    if subtitle:
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=max(n_cols, 1))
        sub_cell = ws.cell(row=2, column=1, value=subtitle)
        sub_cell.font = Font(name="Arial", size=10, italic=True, color=GREY_TEXT)
        header_row = 3

    # Gold accent underline just above the header
    accent_row = header_row
    for c in range(1, n_cols + 1):
        ws.cell(row=accent_row, column=c).fill = PatternFill("solid", fgColor=GOLD)
    ws.row_dimensions[accent_row].height = 4
    header_row += 1

    # Column headers
    for c, col_name in enumerate(columns, start=1):
        cell = ws.cell(row=header_row, column=c, value=col_name)
        cell.font = Font(name="Arial", size=10, bold=True, color=WHITE)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER

    fills = {
        "present": PatternFill("solid", fgColor=GREEN),
        "absent": PatternFill("solid", fgColor=RED),
        "warning": PatternFill("solid", fgColor=WARNING),
        "blank": PatternFill("solid", fgColor=WHITE),
        "total": PatternFill("solid", fgColor=LIGHT_BLUE),
    }
    font_colors = {
        "present": GREEN_TEXT,
        "absent": RED_TEXT,
        "warning": WARNING_TEXT,
    }

    data_start = header_row + 1
    for r, row_values in enumerate(rows):
        excel_row = data_start + r
        stripe = GREY if r % 2 == 1 else WHITE
        for c, value in enumerate(row_values):
            cell = ws.cell(row=excel_row, column=c + 1, value=value)
            cell.border = BORDER
            cell.alignment = Alignment(
                horizontal="left" if c == 0 else "center", vertical="center"
            )
            style_key = style_fn(row_values, c) if style_fn else None
            if style_key and style_key in fills:
                cell.fill = fills[style_key]
                if style_key in font_colors:
                    cell.font = Font(name="Arial", size=10, color=font_colors[style_key], bold=(c == 0))
                elif c == 0:
                    cell.font = Font(name="Arial", size=10, bold=True, color=NAVY_DARK)
            else:
                cell.fill = PatternFill("solid", fgColor=stripe)
                cell.font = Font(name="Arial", size=10, bold=(c == 0), color=NAVY_DARK)

    # Column widths
    widths = spec.get("col_widths")
    for c in range(1, n_cols + 1):
        letter = get_column_letter(c)
        if widths and c - 1 < len(widths):
            ws.column_dimensions[letter].width = widths[c - 1]
        else:
            longest = len(str(columns[c - 1]))
            for row_values in rows:
                if c - 1 < len(row_values):
                    longest = max(longest, len(str(row_values[c - 1])))
            ws.column_dimensions[letter].width = min(max(longest + 2, 8), 28)

    freeze_cols = spec.get("freeze_cols", 1)
    ws.freeze_panes = ws.cell(row=data_start, column=freeze_cols + 1)

    ws.page_setup.orientation = "landscape" if spec.get("landscape") else "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = f"1:{header_row}"
    return ws


def build_workbook(sheet_specs):
    wb = Workbook()
    wb.remove(wb.active)
    for spec in sheet_specs:
        write_sheet(wb, spec)
    return wb


# ----------------------------------------------------------------------
# Range-picker dialog (Day / Month / Year) + Save / Print-via-Excel actions
# ----------------------------------------------------------------------
class ExportRangeDialog(QDialog):
    """
    report_builder: callable(scope, year, month, day) -> (title, sheet_specs)
        scope is one of "day", "month", "year".
        month/day are None when not applicable to the chosen scope.
        sheet_specs is a list of dicts as described in write_sheet().
    """

    def __init__(self, report_builder, default_title="Report", parent=None):
        super().__init__(parent)
        self.report_builder = report_builder
        self.setWindowTitle(f"Export — {default_title}")
        self.setMinimumWidth(380)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Choose what to include:"))

        scope_row = QHBoxLayout()
        self.day_radio = QRadioButton("Specific Day")
        self.month_radio = QRadioButton("Month")
        self.year_radio = QRadioButton("Year")
        self.month_radio.setChecked(True)
        group = QButtonGroup(self)
        for b in (self.day_radio, self.month_radio, self.year_radio):
            group.addButton(b)
            scope_row.addWidget(b)
        layout.addLayout(scope_row)

        today = QDate.currentDate()

        self.day_edit = QDateEdit()
        self.day_edit.setCalendarPopup(True)
        self.day_edit.setDisplayFormat("yyyy-MM-dd")
        self.day_edit.setDate(today)
        layout.addWidget(self.day_edit)

        self.month_edit = QDateEdit()
        self.month_edit.setCalendarPopup(True)
        self.month_edit.setDisplayFormat("MMMM yyyy")
        self.month_edit.setDate(today)
        layout.addWidget(self.month_edit)

        self.year_combo = QComboBox()
        current_year = today.year()
        for y in range(current_year - 6, current_year + 2):
            self.year_combo.addItem(str(y), y)
        self.year_combo.setCurrentText(str(current_year))
        layout.addWidget(self.year_combo)

        self.day_radio.toggled.connect(self._update_visibility)
        self.month_radio.toggled.connect(self._update_visibility)
        self.year_radio.toggled.connect(self._update_visibility)
        self._update_visibility()

        layout.addWidget(QLabel(
            "Saved as a real Excel (.xlsx) file — open it in Excel or LibreOffice\n"
            "Calc to print, using the spreadsheet app's own page setup."
        ))

        btn_row = QHBoxLayout()
        open_btn = QPushButton("Open in Excel")
        open_btn.setObjectName("primaryButton")
        open_btn.clicked.connect(self._on_open_in_excel)
        save_btn = QPushButton("Save as Excel (.xlsx)")
        save_btn.clicked.connect(self._on_save_excel)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.reject)
        btn_row.addWidget(open_btn)
        btn_row.addWidget(save_btn)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

    # ------------------------------------------------------------------
    def _update_visibility(self):
        self.day_edit.setVisible(self.day_radio.isChecked())
        self.month_edit.setVisible(self.month_radio.isChecked())
        self.year_combo.setVisible(self.year_radio.isChecked())

    def _current_scope(self):
        if self.day_radio.isChecked():
            d = self.day_edit.date()
            return "day", d.year(), d.month(), d.day()
        elif self.month_radio.isChecked():
            d = self.month_edit.date()
            return "month", d.year(), d.month(), None
        else:
            y = self.year_combo.currentData()
            return "year", y, None, None

    def _build_workbook(self):
        scope, year, month, day = self._current_scope()
        try:
            title, sheet_specs = self.report_builder(scope, year, month, day)
        except Exception as e:
            QMessageBox.warning(self, "Report error", f"Could not build the report:\n{e}")
            return None, None
        wb = build_workbook(sheet_specs)
        return title, wb

    def _default_filename(self, title):
        return (title or "report").replace(" ", "_").replace("—", "-").replace("/", "-") + ".xlsx"

    def _on_save_excel(self):
        title, wb = self._build_workbook()
        if wb is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Report as Excel", self._default_filename(title), "Excel Files (*.xlsx)"
        )
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        wb.save(path)
        QMessageBox.information(self, "Saved", f"Report saved to:\n{path}")

    def _on_open_in_excel(self):
        title, wb = self._build_workbook()
        if wb is None:
            return
        tmp_dir = tempfile.gettempdir()
        path = os.path.join(tmp_dir, self._default_filename(title))
        wb.save(path)
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)  # noqa: this branch only runs on Windows
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as e:
            QMessageBox.warning(
                self, "Could not open automatically",
                f"The file was saved to:\n{path}\n\nbut it could not be opened automatically ({e}). "
                "Open it manually in Excel or LibreOffice Calc."
            )


def _officers_sorted(db, mcat_code=None):
    return db.get_officers(mcat_code=mcat_code)


# ----------------------------------------------------------------------
# One-click export helper for simple, single-table reports (Students,
# Officers, Patrols, Incidents, Confiscated Items) — no date-range picker.
# ----------------------------------------------------------------------
def _open_path(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # noqa: only reached on Windows
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


def export_workbook_interactive(parent, title, sheet_specs):
    """Builds the workbook from sheet_specs, asks where to save it, then offers to open it."""
    wb = build_workbook(sheet_specs)
    export_wb_interactive(parent, title, wb)


def export_wb_interactive(parent, title, wb):
    """Same as export_workbook_interactive, but takes an already-built Workbook
    (used by Analytics, whose sheets include native Excel charts)."""
    default_name = title.replace(" ", "_").replace("—", "-").replace("/", "-") + ".xlsx"
    path, _ = QFileDialog.getSaveFileName(parent, "Save Report as Excel", default_name, "Excel Files (*.xlsx)")
    if not path:
        return
    if not path.lower().endswith(".xlsx"):
        path += ".xlsx"
    wb.save(path)
    reply = QMessageBox.question(
        parent, "Saved", f"Report saved to:\n{path}\n\nOpen it now?",
        QMessageBox.Yes | QMessageBox.No,
    )
    if reply == QMessageBox.Yes:
        _open_path(path)


# ----------------------------------------------------------------------
# Students report
# ----------------------------------------------------------------------
def build_students_report(db, mcat_code=None):
    title = "Student Directory"
    students = db.get_students(mcat_code=mcat_code)
    columns = ["Student #", "Full Name", "Gender", "Grade", "Section", "Adviser",
               "Campus", "Status", "Incidents", "Community Service (hrs)"]
    rows = [[
        s.get("student_number") or "", s.get("full_name") or "", s.get("gender") or "",
        s.get("grade") or "", s.get("section") or "", s.get("adviser") or "",
        s.get("campus_name") or "", s.get("status") or "", s.get("incident_count") or 0,
        s.get("community_service_hours") or 0,
    ] for s in students]

    def style_fn(row, c):
        status = row[7]
        if status == "Suspended":
            return "absent"
        if status == "Suspicious":
            return "warning"
        if status == "Good Standing":
            return "present"
        return None

    spec = {
        "name": "Students", "title": "Student Directory",
        "subtitle": f"{len(students)} student(s) on record",
        "columns": columns, "rows": rows, "style_fn": style_fn,
        "freeze_cols": 2, "landscape": True,
    }
    return title, [spec]


# ----------------------------------------------------------------------
# Officers report
# ----------------------------------------------------------------------
def build_officers_report(db, mcat_code=None):
    title = "Officer Directory"
    officers = db.get_officers(mcat_code=mcat_code)
    columns = ["Officer #", "Full Name", "Rank", "Position", "Campus", "Building",
               "Account Role", "Username", "On Duty", "Active"]
    rows = [[
        o.get("officer_number") or "", o.get("full_name") or "", o.get("rank") or "",
        o.get("position") or "", o.get("campus_name") or "", o.get("building_name") or "",
        o.get("account_role") or "", o.get("username") or "",
        "Yes" if o.get("on_duty") else "No", "Yes" if o.get("is_active") else "No",
    ] for o in officers]

    def style_fn(row, c):
        if c == 8:
            return "present" if row[8] == "Yes" else "blank"
        return None

    spec = {
        "name": "Officers", "title": "Officer Directory",
        "subtitle": f"{len(officers)} officer(s) on record",
        "columns": columns, "rows": rows, "style_fn": style_fn,
        "freeze_cols": 2, "landscape": True,
    }
    return title, [spec]


# ----------------------------------------------------------------------
# Patrol Logs report
# ----------------------------------------------------------------------
def build_patrols_report(db, mcat_code=None):
    title = "Patrol Logs Report"
    patrols = db.get_patrols(mcat_code=mcat_code)
    columns = ["Officer", "Campus", "Building", "Started", "Ended", "Status", "Remarks"]
    rows = [[
        p.get("officer_name") or "", p.get("campus_name") or "", p.get("building_name") or "",
        (p.get("time_started") or "").replace("T", " ")[:16],
        (p.get("time_ended") or "").replace("T", " ")[:16] if p.get("time_ended") else "—",
        p.get("status") or "", p.get("remarks") or "",
    ] for p in patrols]

    def style_fn(row, c):
        if c == 5:
            return "present" if row[5] == "Completed" else "warning"
        return None

    spec = {
        "name": "Patrol Logs", "title": "Patrol Logs Report",
        "subtitle": f"{len(patrols)} patrol log(s) on record",
        "columns": columns, "rows": rows, "style_fn": style_fn,
        "freeze_cols": 1, "landscape": True,
    }
    return title, [spec]


# ----------------------------------------------------------------------
# Incidents report (case management)
# ----------------------------------------------------------------------
def build_incidents_report(db, mcat_code=None):
    title = "Incident Reports"
    incidents = db.get_incidents(mcat_code=mcat_code)
    columns = ["Date", "Student", "Officer", "Campus", "Building", "Category",
               "Severity", "Case Stage", "Description", "Resolution"]
    rows = [[
        (i.get("date") or "").replace("T", " ")[:16], i.get("student_name") or "",
        i.get("officer_name") or "", i.get("campus_name") or "", i.get("building_name") or "",
        i.get("category") or "", i.get("severity") or "", i.get("case_stage") or "",
        i.get("description") or "", i.get("resolution") or "",
    ] for i in incidents]

    def style_fn(row, c):
        if c == 6:
            sev = row[6]
            if sev in ("Critical", "High"):
                return "absent"
            if sev == "Medium":
                return "warning"
            return "present"
        if c == 7:
            return "total" if row[7] in ("Resolved", "Closed") else "warning"
        return None

    spec = {
        "name": "Incidents", "title": "Incident Reports",
        "subtitle": f"{len(incidents)} incident(s) on record",
        "columns": columns, "rows": rows, "style_fn": style_fn,
        "freeze_cols": 2, "landscape": True,
    }
    return title, [spec]


# ----------------------------------------------------------------------
# Confiscated Items report
# ----------------------------------------------------------------------
def build_confiscated_report(db, mcat_code=None):
    title = "Confiscated Items Report"
    items = db.get_confiscated_items(mcat_code=mcat_code)
    columns = ["Date", "Student", "Officer", "Item", "Qty", "Reason", "Returned", "Return Date"]
    rows = [[
        (ci.get("date_confiscated") or "").replace("T", " ")[:16], ci.get("student_name") or "",
        ci.get("officer_name") or "", ci.get("item_name") or "", ci.get("quantity") or 0,
        ci.get("reason") or "", "Yes" if ci.get("returned") else "No", ci.get("return_date") or "—",
    ] for ci in items]

    def style_fn(row, c):
        if c == 6:
            return "present" if row[6] == "Yes" else "absent"
        return None

    spec = {
        "name": "Confiscated Items", "title": "Confiscated Items Report",
        "subtitle": f"{len(items)} item(s) on record",
        "columns": columns, "rows": rows, "style_fn": style_fn,
        "freeze_cols": 2, "landscape": True,
    }
    return title, [spec]


# ----------------------------------------------------------------------
# Attendance report builder
# ----------------------------------------------------------------------
def build_attendance_report(db, scope, year, month, day, mcat_code=None):
    if scope == "day":
        return _attendance_day_sheets(db, year, month, day, mcat_code)
    elif scope == "month":
        return _attendance_month_sheets(db, year, month, mcat_code)
    else:
        return _attendance_year_sheets(db, year, mcat_code)


def _attendance_day_sheets(db, year, month, day, mcat_code=None):
    date_str = date_cls(year, month, day).isoformat()
    title = f"Attendance — {date_str}"
    officers = _officers_sorted(db, mcat_code)
    records = {r["officer_id"]: r for r in db.get_attendance_for_day(date_str)}
    is_weekend = date_cls(year, month, day).weekday() >= 5

    rows = []
    for o in officers:
        r = records.get(o["id"])
        if r and r.get("login_time"):
            login = r["login_time"].split("T")[-1][:5]
            logout = r["logout_time"].split("T")[-1][:5] if r.get("logout_time") else "—"
            hours = f"{r['hours_worked']:.1f}h" if r.get("hours_worked") is not None else "—"
            note = "Manual" if r.get("is_manual_edit") else ""
            rows.append([o["full_name"], o.get("rank") or "", login, logout, hours, note])
        elif is_weekend:
            rows.append([o["full_name"], o.get("rank") or "", "—", "—", "—", "Weekend"])
        else:
            rows.append([o["full_name"], o.get("rank") or "", "—", "—", "—", "Absent"])

    def style_fn(row, c):
        note = row[5]
        if note == "Absent":
            return "absent"
        if note == "Weekend":
            return "blank"
        return "present" if row[2] != "—" else "blank"

    spec = {
        "name": "Attendance",
        "title": "Attendance — Daily Report",
        "subtitle": date_str,
        "columns": ["Officer", "Rank", "Signed In", "Signed Out", "Hours", "Notes"],
        "rows": rows,
        "style_fn": style_fn,
        "freeze_cols": 1,
        "landscape": False,
    }
    return title, [spec]


def _attendance_month_sheets(db, year, month, mcat_code=None):
    title = f"Attendance — {calendar.month_name[month]} {year}"
    officers = _officers_sorted(db, mcat_code)
    records = db.get_attendance_for_month(year, month)
    by_officer_day = {(r["officer_id"], r["date"]): r for r in records}
    days_in_month = calendar.monthrange(year, month)[1]
    today = date_cls.today()

    columns = ["Officer", "Rank"] + [str(d) for d in range(1, days_in_month + 1)]
    rows = []
    for o in officers:
        row = [o["full_name"], o.get("rank") or ""]
        for d in range(1, days_in_month + 1):
            day_date = date_cls(year, month, d)
            r = by_officer_day.get((o["id"], day_date.isoformat()))
            if r and r.get("login_time"):
                hours = r.get("hours_worked")
                label = f"{hours:.1f}" if hours is not None else "—"
                if r.get("is_manual_edit"):
                    label += "*"
                row.append(label)
            elif day_date.weekday() >= 5 or day_date > today:
                row.append("")
            else:
                row.append("A")
        rows.append(row)

    def style_fn(row, c):
        if c < 2:
            return None
        v = row[c]
        if v == "A":
            return "absent"
        if v == "":
            return "blank"
        return "present"

    spec = {
        "name": "Monthly Attendance",
        "title": "Monthly Attendance",
        "subtitle": f'{calendar.month_name[month]} {year}  ·  hours per day, "A" = absent, * = manually corrected',
        "columns": columns,
        "rows": rows,
        "style_fn": style_fn,
        "freeze_cols": 2,
        "landscape": True,
        "col_widths": [22, 12] + [5] * days_in_month,
    }
    return title, [spec]


def _attendance_year_sheets(db, year, mcat_code=None):
    title = f"Attendance — {year}"
    officers = _officers_sorted(db, mcat_code)
    records = db.get_attendance_for_year(year)

    agg = {}
    for r in records:
        m = int(r["date"][5:7])
        key = (r["officer_id"], m)
        present, hours = agg.get(key, (0, 0.0))
        if r.get("login_time"):
            present += 1
            hours += r.get("hours_worked") or 0
        agg[key] = (present, hours)

    columns = ["Officer", "Rank"] + [calendar.month_abbr[m] for m in range(1, 13)] + ["Total"]
    rows = []
    for o in officers:
        row = [o["full_name"], o.get("rank") or ""]
        total_hours = 0.0
        total_days = 0
        for m in range(1, 13):
            present, hours = agg.get((o["id"], m), (0, 0.0))
            total_hours += hours
            total_days += present
            row.append(f"{present}d / {hours:.0f}h" if present else "—")
        row.append(f"{total_days}d / {total_hours:.0f}h")
        rows.append(row)

    def style_fn(row, c):
        return "total" if c == len(row) - 1 else None

    spec = {
        "name": "Annual Attendance",
        "title": "Annual Attendance Summary",
        "subtitle": f"{year}  ·  days present / total hours, per month",
        "columns": columns,
        "rows": rows,
        "style_fn": style_fn,
        "freeze_cols": 2,
        "landscape": True,
    }
    return title, [spec]


# ----------------------------------------------------------------------
# IRL Sign Book report builder
# ----------------------------------------------------------------------
def build_irl_report(db, scope, year, month, day, mcat_code=None):
    if scope == "day":
        return _irl_day_sheets(db, year, month, day, mcat_code)
    elif scope == "month":
        return _irl_month_sheets(db, year, month, mcat_code)
    else:
        return _irl_year_sheets(db, year, mcat_code)


def _irl_day_sheets(db, year, month, day, mcat_code=None):
    date_str = date_cls(year, month, day).isoformat()
    title = f"IRL Sign Book — {date_str}"
    officers = _officers_sorted(db, mcat_code)
    records = {r["officer_id"]: r for r in db.get_irl_for_day(date_str)}

    rows = []
    for o in officers:
        r = records.get(o["id"])
        if r and r.get("login_time"):
            login = r["login_time"].split("T")[-1][:5]
            logout = r["logout_time"].split("T")[-1][:5] if r.get("logout_time") else "Still signed in"
            hours = f"{r['hours_worked']:.1f}h" if r.get("hours_worked") is not None else "—"
            note = "Manual" if r.get("is_manual_edit") else ""
            rows.append([o["full_name"], o.get("rank") or "", login, logout, hours, note])
        else:
            rows.append([o["full_name"], o.get("rank") or "", "—", "—", "—", "No record"])

    def style_fn(row, c):
        return "present" if row[2] != "—" else "blank"

    spec = {
        "name": "IRL Sign Book",
        "title": "IRL Sign Book — Daily Report",
        "subtitle": date_str,
        "columns": ["Officer", "Rank", "Signed In", "Signed Out", "Hours", "Notes"],
        "rows": rows,
        "style_fn": style_fn,
        "freeze_cols": 1,
        "landscape": False,
    }
    return title, [spec]


def _irl_month_sheets(db, year, month, mcat_code=None):
    title = f"IRL Sign Book — {calendar.month_name[month]} {year}"
    officers = _officers_sorted(db, mcat_code)
    records = db.get_irl_for_month(year, month)
    by_officer_day = {(r["officer_id"], r["date"]): r for r in records}
    days_in_month = calendar.monthrange(year, month)[1]

    columns = ["Officer", "Rank"] + [str(d) for d in range(1, days_in_month + 1)]
    rows = []
    for o in officers:
        row = [o["full_name"], o.get("rank") or ""]
        for d in range(1, days_in_month + 1):
            day_date = date_cls(year, month, d)
            r = by_officer_day.get((o["id"], day_date.isoformat()))
            if r and r.get("login_time"):
                hours = r.get("hours_worked")
                label = f"{hours:.1f}" if hours is not None else "…"
                if r.get("is_manual_edit"):
                    label += "*"
                row.append(label)
            else:
                row.append("")
        rows.append(row)

    def style_fn(row, c):
        if c < 2:
            return None
        return "blank" if row[c] == "" else "present"

    spec = {
        "name": "IRL Sign Book",
        "title": "IRL Sign Book",
        "subtitle": f"{calendar.month_name[month]} {year}  ·  hours per day, * = manually corrected",
        "columns": columns,
        "rows": rows,
        "style_fn": style_fn,
        "freeze_cols": 2,
        "landscape": True,
        "col_widths": [22, 12] + [5] * days_in_month,
    }
    return title, [spec]


def _irl_year_sheets(db, year, mcat_code=None):
    title = f"IRL Sign Book — {year}"
    officers = _officers_sorted(db, mcat_code)
    records = db.get_irl_for_year(year)

    agg = {}
    for r in records:
        m = int(r["date"][5:7])
        key = (r["officer_id"], m)
        signed, hours = agg.get(key, (0, 0.0))
        if r.get("login_time"):
            signed += 1
            hours += r.get("hours_worked") or 0
        agg[key] = (signed, hours)

    columns = ["Officer", "Rank"] + [calendar.month_abbr[m] for m in range(1, 13)] + ["Total"]
    rows = []
    for o in officers:
        row = [o["full_name"], o.get("rank") or ""]
        total_hours = 0.0
        total_days = 0
        for m in range(1, 13):
            signed, hours = agg.get((o["id"], m), (0, 0.0))
            total_hours += hours
            total_days += signed
            row.append(f"{signed}d / {hours:.0f}h" if signed else "—")
        row.append(f"{total_days}d / {total_hours:.0f}h")
        rows.append(row)

    def style_fn(row, c):
        return "total" if c == len(row) - 1 else None

    spec = {
        "name": "Annual IRL Summary",
        "title": "Annual IRL Sign Book Summary",
        "subtitle": f"{year}  ·  days signed / total hours, per month",
        "columns": columns,
        "rows": rows,
        "style_fn": style_fn,
        "freeze_cols": 2,
        "landscape": True,
    }
    return title, [spec]


# ----------------------------------------------------------------------
# Full Analytics workbook — data sheets + native Excel charts
# ----------------------------------------------------------------------
def build_analytics_workbook(db, mcat_code=None):
    import calendar as _cal
    from collections import Counter
    from datetime import datetime as _dt
    from openpyxl.chart import BarChart, PieChart, Reference

    year = _dt.now().year
    students = db.get_students(mcat_code=mcat_code)
    officers = db.get_officers(mcat_code=mcat_code)
    patrols = db.get_patrols(mcat_code=mcat_code)
    incidents = db.get_incidents(mcat_code=mcat_code)
    confiscated = db.get_confiscated_items()

    wb = Workbook()
    wb.remove(wb.active)

    open_incidents = sum(1 for i in incidents if i.get("case_stage") in ("New", "Under Review"))
    summary_rows = [
        ["Total Students", len(students)],
        ["Total Officers", len(officers)],
        ["Officers On Duty", sum(1 for o in officers if o.get("on_duty"))],
        ["Total Patrol Logs", len(patrols)],
        ["Total Incidents", len(incidents)],
        ["Open / In-Progress Cases", open_incidents],
        ["Total Confiscated Items", len(confiscated)],
        ["Items Not Yet Returned", sum(1 for c in confiscated if not c.get("returned"))],
    ]
    write_sheet(wb, {
        "name": "Summary", "title": "CAT Program System — Analytics Summary",
        "subtitle": f"Generated {_dt.now().strftime('%Y-%m-%d')}",
        "columns": ["Metric", "Value"], "rows": summary_rows,
        "freeze_cols": 1, "landscape": False, "col_widths": [32, 14],
    })

    month_counts = Counter()
    for i in incidents:
        d = (i.get("date") or "")[:10]
        try:
            dt = _dt.fromisoformat(d)
            if dt.year == year:
                month_counts[dt.month] += 1
        except ValueError:
            continue
    mi_rows = [[_cal.month_abbr[m], month_counts.get(m, 0)] for m in range(1, 13)]
    ws = write_sheet(wb, {
        "name": "Monthly Incidents", "title": "Monthly Incidents",
        "subtitle": f"{year} · number of incidents recorded per month",
        "columns": ["Month", "Incidents"], "rows": mi_rows,
        "freeze_cols": 1, "landscape": False, "col_widths": [14, 12],
    })
    chart = BarChart()
    chart.title = "Monthly Incidents"
    chart.y_axis.title = "Incidents"
    chart.x_axis.title = "Month"
    chart.style = 10
    data = Reference(ws, min_col=2, min_row=4, max_row=4 + len(mi_rows))
    cats = Reference(ws, min_col=1, min_row=5, max_row=4 + len(mi_rows))
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.width, chart.height = 18, 9
    ws.add_chart(chart, "D4")

    top_students = sorted(students, key=lambda s: s.get("incident_count") or 0, reverse=True)[:15]
    st_rows = [[
        s.get("full_name") or "", s.get("grade") or "", s.get("section") or "",
        s.get("incident_count") or 0, s.get("status") or "",
    ] for s in top_students]

    def st_style(row, c):
        if c == 3:
            v = row[3]
            if v >= 3:
                return "absent"
            if v >= 1:
                return "warning"
        return None

    avg_incidents = (sum(s.get("incident_count") or 0 for s in students) / len(students)) if students else 0
    write_sheet(wb, {
        "name": "Student Stats", "title": "Student Statistics — Top by Incident Count",
        "subtitle": f"{len(students)} students total · average {avg_incidents:.2f} incidents/student",
        "columns": ["Student", "Grade", "Section", "Incidents", "Status"], "rows": st_rows,
        "style_fn": st_style, "freeze_cols": 1, "landscape": False,
    })

    patrol_counts = Counter(p.get("officer_id") for p in patrols)
    incident_counts = Counter(i.get("officer_id") for i in incidents)
    off_rows = [[
        o.get("full_name") or "", o.get("rank") or "",
        patrol_counts.get(o.get("id"), 0), incident_counts.get(o.get("id"), 0),
        "Yes" if o.get("on_duty") else "No",
    ] for o in officers]
    off_rows.sort(key=lambda r: r[2], reverse=True)
    write_sheet(wb, {
        "name": "Officer Stats", "title": "Officer Statistics",
        "subtitle": "Patrols logged and incidents recorded, per officer",
        "columns": ["Officer", "Rank", "Patrols Logged", "Incidents Recorded", "On Duty"],
        "rows": off_rows, "freeze_cols": 1, "landscape": False,
    })

    status_counts = Counter(p.get("status") for p in patrols)
    building_names = {}
    for p in patrols:
        key = p.get("building_name") or "Unassigned"
        building_names[key] = building_names.get(key, 0) + 1
    ps_rows = [[k, v] for k, v in status_counts.items()]
    ws1 = write_sheet(wb, {
        "name": "Patrol Stats", "title": "Patrol Statistics — By Status",
        "subtitle": f"{len(patrols)} total patrol logs",
        "columns": ["Status", "Count"], "rows": ps_rows,
        "freeze_cols": 1, "landscape": False, "col_widths": [18, 10],
    })
    if ps_rows:
        pie = PieChart()
        pie.title = "Patrols by Status"
        data = Reference(ws1, min_col=2, min_row=4, max_row=4 + len(ps_rows))
        cats = Reference(ws1, min_col=1, min_row=5, max_row=4 + len(ps_rows))
        pie.add_data(data, titles_from_data=True)
        pie.set_categories(cats)
        pie.width, pie.height = 12, 9
        ws1.add_chart(pie, "D4")

    building_incident_counts = Counter(i.get("building_name") or "Unassigned" for i in incidents)
    all_buildings = sorted(set(list(building_incident_counts.keys()) + list(building_names.keys())))
    bs_rows = [[b, building_incident_counts.get(b, 0), building_names.get(b, 0)] for b in all_buildings]
    ws2 = write_sheet(wb, {
        "name": "Building Stats", "title": "Building Statistics",
        "subtitle": "Incidents and patrols recorded, per building",
        "columns": ["Building", "Incidents", "Patrols"], "rows": bs_rows,
        "freeze_cols": 1, "landscape": False,
    })
    if bs_rows:
        chart2 = BarChart()
        chart2.title = "Incidents & Patrols by Building"
        chart2.style = 10
        data = Reference(ws2, min_col=2, max_col=3, min_row=4, max_row=4 + len(bs_rows))
        cats = Reference(ws2, min_col=1, min_row=5, max_row=4 + len(bs_rows))
        chart2.add_data(data, titles_from_data=True)
        chart2.set_categories(cats)
        chart2.width, chart2.height = 18, 9
        ws2.add_chart(chart2, "E4")

    return "Analytics Report", wb
