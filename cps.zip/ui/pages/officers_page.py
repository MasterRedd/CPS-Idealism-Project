from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView
)
from PySide6.QtGui import QColor

from ui.pages.officer_form_dialog import OfficerFormDialog
from ui.pages.attendance_dialog import AttendanceDialog
from ui.pages.irl_admin_dialog import IRLAdminDialog
from ui.pages.id_card_dialog import IDCardDialog
from ui.pages.qr_scanner_dialog import QRScannerDialog
from ui.pages.qr_attendance_dialog import QRAttendanceDialog

CAN_EDIT_ROLES = {"Administrator", "CAT Commander"}
CAN_DELETE_ROLES = {"Administrator"}

COLUMNS = ["ID", "Officer No.", "Full Name", "Rank", "Campus", "Username", "On Duty"]


class OfficersPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self.can_edit = current_user.get("effective_role", current_user["role"]) in CAN_EDIT_ROLES
        self.can_delete = current_user.get("effective_role", current_user["role"]) in CAN_DELETE_ROLES

        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        header_row = QHBoxLayout()
        title = QLabel("Officers")
        title.setObjectName("stubTitle")
        header_row.addWidget(title)
        header_row.addStretch()

        attendance_btn = QPushButton("📅 Monthly Attendance")
        attendance_btn.clicked.connect(self._open_attendance)
        header_row.addWidget(attendance_btn)

        irl_btn = QPushButton("🕒 IRL Sign Book")
        irl_btn.clicked.connect(self._open_irl_sign_book)
        header_row.addWidget(irl_btn)

        scan_btn = QPushButton("📷 Scan QR")
        scan_btn.clicked.connect(self._open_qr_scanner)
        header_row.addWidget(scan_btn)

        self.scan_login_btn = QPushButton("🟢 Scan IRL Log In")
        self.scan_login_btn.clicked.connect(lambda: self._open_qr_attendance("login"))
        self.scan_login_btn.setVisible(self.can_edit)
        header_row.addWidget(self.scan_login_btn)

        self.scan_logout_btn = QPushButton("🔴 Scan IRL Log Out")
        self.scan_logout_btn.clicked.connect(lambda: self._open_qr_attendance("logout"))
        self.scan_logout_btn.setVisible(self.can_edit)
        header_row.addWidget(self.scan_logout_btn)

        self.add_btn = QPushButton("+ Add Officer")
        self.add_btn.setObjectName("primaryButton")
        self.add_btn.clicked.connect(self._on_add)
        self.add_btn.setVisible(self.can_edit)
        header_row.addWidget(self.add_btn)
        layout.addLayout(header_row)

        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by name or officer ID...")
        self.search_input.textChanged.connect(self.refresh)
        search_row.addWidget(self.search_input)
        layout.addLayout(search_row)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnHidden(0, True)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setStyleSheet(
            "QTableWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; }"
            "QHeaderView::section { background-color: #0A2E5C; color: #ffffff; padding: 7px; border: none; font-weight: 600; }"
        )
        self.table.doubleClicked.connect(self._on_edit)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        action_row.addStretch()

        self.edit_btn = QPushButton("Edit Selected")
        self.edit_btn.clicked.connect(self._on_edit)
        self.edit_btn.setVisible(self.can_edit)
        action_row.addWidget(self.edit_btn)

        self.id_card_btn = QPushButton("🪪 View ID Card")
        self.id_card_btn.clicked.connect(self._open_id_card)
        action_row.addWidget(self.id_card_btn)

        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setStyleSheet("color: #d9453d;")
        self.delete_btn.clicked.connect(self._on_delete)
        self.delete_btn.setVisible(self.can_delete)
        action_row.addWidget(self.delete_btn)

        layout.addLayout(action_row)

        self.count_label = QLabel("")
        self.count_label.setStyleSheet("color: #8ea0b3; font-size: 12px;")
        layout.addWidget(self.count_label)

    # ------------------------------------------------------------------
    def refresh(self):
        search = self.search_input.text().strip()
        officers = self.db.get_officers(search=search, mcat_code=self.current_user.get("mcat_code"))

        self.table.setRowCount(0)
        for officer in officers:
            row = self.table.rowCount()
            self.table.insertRow(row)
            on_duty = "Yes" if officer.get("on_duty") else "No"
            values = [
                str(officer["id"]),
                officer.get("officer_number") or "",
                officer.get("full_name") or "",
                officer.get("rank") or "",
                officer.get("campus_name") or "—",
                officer.get("username") or "—",
                on_duty,
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 6:
                    item.setForeground(QColor("#1e9e5a") if value == "Yes" else QColor("#8ea0b3"))
                self.table.setItem(row, col, item)

        self.count_label.setText(f"{len(officers)} officer(s)")

    # ------------------------------------------------------------------
    def _selected_officer_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return int(self.table.item(row, 0).text())

    def _on_add(self):
        dialog = OfficerFormDialog(self.db, parent=self, mcat_code=self.current_user.get("mcat_code"))
        if dialog.exec():
            self.db.create_officer_account(
                dialog.officer_data,
                username=dialog.username,
                password=dialog.new_password,
                role=dialog.account_role,
                actor_user_id=self.current_user["id"],
                mcat_code=self.current_user.get("mcat_code"),
            )
            self.refresh()

    def _on_edit(self):
        officer_id = self._selected_officer_id()
        if officer_id is None:
            QMessageBox.information(self, "No selection", "Select an officer to edit first.")
            return
        officer = self.db.get_officer(officer_id)
        # get_officers() joins username/role in; get_officer() doesn't, so patch them in for the dialog
        officers_list = self.db.get_officers(mcat_code=self.current_user.get("mcat_code"))
        joined = next((o for o in officers_list if o["id"] == officer_id), {})
        officer["username"] = joined.get("username")
        officer["role"] = joined.get("account_role")

        dialog = OfficerFormDialog(self.db, officer=officer, parent=self, mcat_code=self.current_user.get("mcat_code"))
        if dialog.exec():
            self.db.update_officer(
                officer_id,
                dialog.officer_data,
                actor_user_id=self.current_user["id"],
                new_password=dialog.new_password or None,
            )
            self.db.update_officer_role(
                officer_id, dialog.account_role, actor_user_id=self.current_user["id"]
            )
            self.refresh()

    def _on_delete(self):
        officer_id = self._selected_officer_id()
        if officer_id is None:
            QMessageBox.information(self, "No selection", "Select an officer to delete first.")
            return
        officer = self.db.get_officer(officer_id)
        confirm = QMessageBox.question(
            self,
            "Confirm delete",
            f"Remove {officer['full_name']} from active records?\n\n"
            "This is a soft delete and also deactivates their login account — "
            "attendance history is kept, not erased.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_officer(officer_id, actor_user_id=self.current_user["id"])
            self.refresh()

    def _open_attendance(self):
        dialog = AttendanceDialog(self.db, self.current_user, parent=self)
        dialog.exec()

    def _open_irl_sign_book(self):
        dialog = IRLAdminDialog(self.db, self.current_user, parent=self)
        dialog.exec()

    def _open_id_card(self):
        officer_id = self._selected_officer_id()
        if officer_id is None:
            QMessageBox.information(self, "No selection", "Select an officer to view their ID card first.")
            return
        profile = self.db.get_officer_profile(officer_id)
        school_name = self.db.get_setting("school_name", "CAT Program System")
        dialog = IDCardDialog(profile, school_name=school_name, parent=self)
        dialog.exec()

    def _open_qr_scanner(self):
        dialog = QRScannerDialog(self.db, parent=self)
        if dialog.exec() and dialog.matched_profile:
            school_name = self.db.get_setting("school_name", "CAT Program System")
            id_dialog = IDCardDialog(dialog.matched_profile, school_name=school_name, parent=self)
            id_dialog.exec()

    def _open_qr_attendance(self, mode):
        dialog = QRAttendanceDialog(self.db, mode=mode, parent=self)
        dialog.exec()
        if dialog.result:
            title, message, is_error = dialog.result
            if is_error:
                QMessageBox.warning(self, title, message)
            else:
                QMessageBox.information(self, title, message)
        self.refresh()
