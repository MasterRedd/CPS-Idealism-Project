import json
import time

from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtCore import Qt, QTimer

from ui.pages.qr_utils import cv2, open_camera, decode_qr_from_frame, decode_qr_from_image_path


class QRScannerDialog(QDialog):
    """Opens the webcam, looks for a CPS officer-ID QR code, and returns the
    matched officer's full profile via `matched_profile` once accepted.
    If the code doesn't match any officer, it shows a message and keeps
    scanning rather than closing or crashing. If no camera is available,
    the person can instead pick an image file from their computer."""

    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.matched_profile = None
        self.cap = None

        self.setWindowTitle("Scan Officer QR Code")
        self.setMinimumSize(520, 500)
        self._build_ui()

        if cv2 is None:
            self._show_no_camera("Camera support (OpenCV) isn't installed on this system.")
            return

        self.cap = open_camera()
        if not self.cap or not self.cap.isOpened():
            self._show_no_camera(
                "Could not access a camera on this device. Make sure no other "
                "app is using it and that camera access is allowed."
            )
            self.cap = None
            return

        self._no_match_until = 0

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(120)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("Scan Officer QR Code")
        title.setObjectName("stubTitle")
        layout.addWidget(title)

        hint = QLabel("Make the QR code from the officer's ID card and face it toward the camera.")
        hint.setWordWrap(True)
        hint.setObjectName("stubSubtitle")
        layout.addWidget(hint)

        self.video_label = QLabel()
        self.video_label.setFixedSize(480, 320)
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet("background: #101826; border-radius: 8px; color: #ffffff;")
        layout.addWidget(self.video_label, alignment=Qt.AlignCenter)

        self.status_label = QLabel("Scanning…")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("color: #5A6B7D; font-weight: 600;")
        layout.addWidget(self.status_label)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        image_btn = QPushButton("📁 Use Image Instead")
        image_btn.clicked.connect(self._pick_image)
        btn_row.addWidget(image_btn)
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

    def _show_no_camera(self, message):
        self.video_label.setText("📷\nNo live camera")
        self.status_label.setText(message)
        self.status_label.setStyleSheet("color: #d9453d; font-weight: 600;")

    def _tick(self):
        if not self.cap:
            return
        ok, frame = self.cap.read()
        if not ok:
            return

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        pix = QPixmap.fromImage(qimg).scaled(
            self.video_label.width(), self.video_label.height(), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        self.video_label.setPixmap(pix)

        if time.time() < self._no_match_until:
            return

        data = decode_qr_from_frame(frame)
        if not data:
            return
        self._handle_decoded(data)

    def _pick_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select an image with a QR code", "", "Images (*.png *.jpg *.jpeg *.bmp *.webp)"
        )
        if not path:
            return
        data = decode_qr_from_image_path(path)
        if not data:
            self._flash_no_match("No QR code detected in that image.")
            return
        self._handle_decoded(data)

    def _handle_decoded(self, data):
        officer_number = None
        try:
            payload = json.loads(data)
            if payload.get("type") == "CPS-OFFICER-ID":
                officer_number = payload.get("officer_number")
        except Exception:
            officer_number = None

        if not officer_number:
            self._flash_no_match("That QR code isn't a recognized CAT officer ID.")
            return

        profile = self.db.get_officer_profile_by_number(officer_number)
        if not profile:
            self._flash_no_match("No match found for this officer.")
            return

        self.matched_profile = profile
        self._stop_camera()
        self.accept()

    def _flash_no_match(self, message):
        self.status_label.setText(message)
        self.status_label.setStyleSheet("color: #d9453d; font-weight: 600;")
        self._no_match_until = time.time() + 2.0
        QTimer.singleShot(2000, self._reset_status)

    def _reset_status(self):
        self.status_label.setText("Scanning…")
        self.status_label.setStyleSheet("color: #5A6B7D; font-weight: 600;")

    def _stop_camera(self):
        if getattr(self, "timer", None):
            self.timer.stop()
        if self.cap:
            self.cap.release()
            self.cap = None

    def reject(self):
        self._stop_camera()
        super().reject()

    def closeEvent(self, event):
        self._stop_camera()
        super().closeEvent(event)
