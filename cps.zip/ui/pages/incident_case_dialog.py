import os

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QComboBox,
    QTextEdit, QPushButton, QDialogButtonBox, QListWidget, QListWidgetItem,
    QMessageBox, QFileDialog
)
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QIcon

from ui.pages.image_viewer_dialog import ImageViewerDialog, is_image_file
from ui.widgets.scrollable import make_scrollable

IMAGE_FILE_FILTER = "Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp);;All Files (*)"

STAGE_ORDER = ["New", "Under Review", "Resolved", "Closed"]
STAGE_COLORS = {
    "New": "#c98a1c",
    "Under Review": "#2F7FD6",
    "Resolved": "#1e9e5a",
    "Closed": "#5a6b7d",
}


class IncidentCaseDialog(QDialog):
    """Full case view: details, evidence, stage progression, and a timeline
    of every update made to the case (per the Case Management System)."""

    def __init__(self, db_manager, incident_id: int, current_user: dict,
                 can_manage: bool, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.incident_id = incident_id
        self.current_user = current_user
        self.can_manage = can_manage
        self.changed = False

        self.setWindowTitle("Case Details")
        self.setMinimumSize(560, 420)
        self._build_ui()
        self._load()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        self.header_label = QLabel("")
        self.header_label.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(self.header_label)

        self.stage_badge = QLabel("")
        self.stage_badge.setStyleSheet("font-weight: 600; padding: 2px 0;")
        layout.addWidget(self.stage_badge)

        form = QFormLayout()
        self.details_label = QLabel("")
        self.details_label.setWordWrap(True)
        form.addRow("Details", self.details_label)

        self.description_label = QLabel("")
        self.description_label.setWordWrap(True)
        form.addRow("Description", self.description_label)

        layout.addLayout(form)

        evidence_header = QHBoxLayout()
        evidence_title = QLabel("Evidence")
        evidence_title.setStyleSheet("font-weight: 700; color: #10233F;")
        evidence_header.addWidget(evidence_title)
        evidence_header.addStretch()
        if self.can_manage:
            add_evidence_btn = QPushButton("+ Attach")
            add_evidence_btn.clicked.connect(self._on_add_evidence)
            evidence_header.addWidget(add_evidence_btn)
        layout.addLayout(evidence_header)

        self.evidence_list = QListWidget()
        self.evidence_list.setViewMode(QListWidget.IconMode)
        self.evidence_list.setIconSize(QSize(76, 76))
        self.evidence_list.setResizeMode(QListWidget.Adjust)
        self.evidence_list.setMovement(QListWidget.Static)
        self.evidence_list.setFixedHeight(110)
        self.evidence_list.setSpacing(6)
        self.evidence_list.itemDoubleClicked.connect(self._on_preview_evidence)
        layout.addWidget(self.evidence_list)

        evidence_hint_row = QHBoxLayout()
        evidence_hint = QLabel("Double-click a photo to view, zoom, and pan.")
        evidence_hint.setStyleSheet("color: #7A8CA6; font-size: 11px;")
        evidence_hint_row.addWidget(evidence_hint, 1)
        if self.can_manage:
            remove_evidence_btn = QPushButton("Remove Selected")
            remove_evidence_btn.clicked.connect(self._on_remove_evidence)
            evidence_hint_row.addWidget(remove_evidence_btn)
        layout.addLayout(evidence_hint_row)

        layout.addWidget(QLabel("Timeline"))
        self.timeline_list = QListWidget()
        self.timeline_list.setMinimumHeight(160)
        layout.addWidget(self.timeline_list, 1)

        if self.can_manage:
            action_box = QFormLayout()
            self.stage_combo = QComboBox()
            self.stage_combo.addItems(STAGE_ORDER)
            action_box.addRow("Change Stage To", self.stage_combo)

            self.resolution_input = QTextEdit()
            self.resolution_input.setFixedHeight(60)
            self.resolution_input.setPlaceholderText(
                "Resolution notes (recommended when moving to Resolved/Closed)"
            )
            action_box.addRow("Resolution", self.resolution_input)

            self.note_input = QTextEdit()
            self.note_input.setFixedHeight(50)
            self.note_input.setPlaceholderText("Add a note to the case timeline (optional)")
            action_box.addRow("Update Note", self.note_input)

            layout.addLayout(action_box)

            apply_row = QHBoxLayout()
            apply_row.addStretch()
            apply_btn = QPushButton("Apply Update")
            apply_btn.setObjectName("primaryButton")
            apply_btn.clicked.connect(self._on_apply_update)
            apply_row.addWidget(apply_btn)
            layout.addLayout(apply_row)

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(self.accept)
        buttons.accepted.connect(self.accept)
        layout.addWidget(buttons)

        make_scrollable(self, max_height_ratio=0.85)

    def _load(self):
        incident = self.db.get_incident(self.incident_id)
        if not incident:
            self.reject()
            return
        self.incident = incident

        self.header_label.setText(
            f"Case #{incident['id']} — {incident.get('student_name') or 'Unknown Student'}"
        )
        stage = incident.get("case_stage") or "New"
        color = STAGE_COLORS.get(stage, "#5a6b7d")
        self.stage_badge.setText(f"● {stage}")
        self.stage_badge.setStyleSheet(f"font-weight: 700; color: {color};")

        details = (
            f"Category: {incident.get('category') or '—'}   |   "
            f"Severity: {incident.get('severity') or '—'}\n"
            f"Officer: {incident.get('officer_name') or '—'}   |   "
            f"Campus: {incident.get('campus_name') or '—'}   |   "
            f"Building: {incident.get('building_name') or '—'}\n"
            f"Date: {incident.get('date') or '—'}"
        )
        self.details_label.setText(details)
        self.description_label.setText(incident.get("description") or "—")

        self._load_evidence_gallery()

        if self.can_manage:
            idx = self.stage_combo.findText(stage)
            if idx >= 0:
                self.stage_combo.setCurrentIndex(idx)
            if incident.get("resolution"):
                self.resolution_input.setPlainText(incident["resolution"])

        self._load_timeline()

    def _load_timeline(self):
        self.timeline_list.clear()
        for update in self.db.get_case_updates(self.incident_id):
            who = update.get("user_name") or "System"
            when = update.get("timestamp") or ""
            stage_tag = f"  [{update['new_stage']}]" if update.get("new_stage") else ""
            text = update.get("update_text") or ""
            item = QListWidgetItem(f"{when} — {who}{stage_tag}\n{text}")
            self.timeline_list.addItem(item)
        self.timeline_list.scrollToBottom()

    def _load_evidence_gallery(self):
        self.evidence_list.clear()
        self._evidence_items = self.db.get_evidence_for_incident(self.incident_id)
        for entry in self._evidence_items:
            path = entry.get("file_path")
            if not path:
                continue
            name = os.path.basename(path)
            item = QListWidgetItem(name if len(name) < 16 else name[:13] + "…")
            item.setToolTip(path)
            if is_image_file(path) and os.path.exists(path):
                pix = QPixmap(path).scaled(76, 76, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                item.setIcon(QIcon(pix))
            item.setData(Qt.UserRole, entry)
            self.evidence_list.addItem(item)

    def _on_preview_evidence(self, item):
        entry = item.data(Qt.UserRole)
        try:
            start_index = self._evidence_items.index(entry)
        except ValueError:
            start_index = 0
        viewer = ImageViewerDialog(self._evidence_items, start_index=start_index, parent=self)
        viewer.exec()

    def _on_add_evidence(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Attach Evidence Photos", "", IMAGE_FILE_FILTER)
        if not paths:
            return
        for p in paths:
            self.db.add_evidence(self.incident_id, p, added_by=self.current_user["id"])
        self.changed = True
        self._load_evidence_gallery()
        self._load_timeline()

    def _on_remove_evidence(self):
        item = self.evidence_list.currentItem()
        if not item:
            QMessageBox.information(self, "No selection", "Select a photo to remove first.")
            return
        entry = item.data(Qt.UserRole)
        if entry.get("legacy"):
            QMessageBox.information(self, "Can't remove",
                                     "This is a legacy attachment and can't be removed here.")
            return
        confirm = QMessageBox.question(
            self, "Remove evidence", "Remove this photo from the case?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_evidence(entry["id"], actor_user_id=self.current_user["id"])
            self.changed = True
            self._load_evidence_gallery()
            self._load_timeline()

    def _on_apply_update(self):
        new_stage = self.stage_combo.currentText()
        note = self.note_input.toPlainText().strip()
        resolution = self.resolution_input.toPlainText().strip()
        current_stage = self.incident.get("case_stage") or "New"

        if new_stage == current_stage and not note:
            QMessageBox.information(self, "Nothing to update",
                                     "Change the stage or add a note before applying.")
            return

        self.db.change_case_stage(
            self.incident_id,
            new_stage,
            note=note,
            resolution=resolution if resolution else None,
            actor_user_id=self.current_user["id"],
        )
        self.changed = True
        self.note_input.clear()
        self._load()
