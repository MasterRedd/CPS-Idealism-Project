import calendar
from collections import Counter
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QSizePolicy, QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QPainter, QColor, QFont

from ui.pages.report_export import export_wb_interactive, build_analytics_workbook

NAVY = QColor("#0A2E5C")
GOLD = QColor("#D4AF37")
BLUE = QColor("#1657A8")
GREY_TEXT = QColor("#6f8299")


class StatCard(QFrame):
    def __init__(self, label: str, value):
        super().__init__()
        self.setProperty("class", "card")
        self.setStyleSheet(
            "QFrame { background-color: white; border-radius: 10px; border: 1px solid #E2E7EE; "
            "border-left: 4px solid #D4AF37; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        value_label = QLabel(str(value))
        value_label.setStyleSheet("font-size: 26px; font-weight: 800; color: #10233F;")
        label_label = QLabel(label)
        label_label.setStyleSheet("font-size: 12px; color: #6f8299;")
        layout.addWidget(value_label)
        layout.addWidget(label_label)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)


class BarChartWidget(QWidget):
    """Lightweight custom-painted bar chart — no extra dependency needed."""

    def __init__(self, data, bar_color=None, parent=None):
        super().__init__(parent)
        self.data = data or []  # list of (label, value)
        self.bar_color = bar_color or BLUE
        self.setMinimumHeight(220)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        painter.fillRect(0, 0, w, h, QColor("#ffffff"))

        if not self.data:
            painter.setPen(GREY_TEXT)
            painter.drawText(self.rect(), Qt.AlignCenter, "No data yet")
            painter.end()
            return

        margin_left, margin_bottom, margin_top = 36, 34, 12
        chart_w = w - margin_left - 16
        chart_h = h - margin_bottom - margin_top
        max_val = max((v for _, v in self.data), default=0) or 1

        n = len(self.data)
        gap = 10
        bar_w = max((chart_w - gap * (n - 1)) / n, 6) if n else 0

        # Axis line
        painter.setPen(QColor("#D3DAE1"))
        painter.drawLine(margin_left, margin_top, margin_left, margin_top + chart_h)
        painter.drawLine(margin_left, margin_top + chart_h, w - 8, margin_top + chart_h)

        font_small = QFont("Arial", 8)
        painter.setFont(font_small)
        for idx, (label, value) in enumerate(self.data):
            bar_h = (value / max_val) * (chart_h - 10)
            x = margin_left + idx * (bar_w + gap)
            y = margin_top + chart_h - bar_h
            painter.setPen(Qt.NoPen)
            painter.setBrush(self.bar_color)
            painter.drawRoundedRect(int(x), int(y), int(bar_w), int(bar_h), 3, 3)

            painter.setPen(NAVY)
            painter.drawText(int(x), int(y) - 4, int(bar_w), 14, Qt.AlignCenter, str(value))

            painter.setPen(GREY_TEXT)
            label_rect_y = margin_top + chart_h + 4
            painter.drawText(int(x - 4), label_rect_y, int(bar_w + 8), margin_bottom - 4,
                              Qt.AlignHCenter | Qt.AlignTop, str(label))
        painter.end()


class SectionCard(QFrame):
    def __init__(self, title, subtitle=None):
        super().__init__()
        self.setProperty("class", "card")
        self.setStyleSheet(
            "QFrame { background-color: white; border-radius: 10px; border: 1px solid #E2E7EE; }"
        )
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(18, 16, 18, 16)
        self.layout.setSpacing(6)
        title_label = QLabel(title)
        title_label.setStyleSheet("font-size: 14px; font-weight: 700; color: #0A2E5C;")
        self.layout.addWidget(title_label)
        if subtitle:
            sub = QLabel(subtitle)
            sub.setStyleSheet("font-size: 11px; color: #6f8299;")
            sub.setWordWrap(True)
            self.layout.addWidget(sub)

    def add(self, widget):
        self.layout.addWidget(widget)


def _make_table(columns, rows):
    table = QTableWidget(len(rows), len(columns))
    table.setHorizontalHeaderLabels(columns)
    table.verticalHeader().setVisible(False)
    table.setEditTriggers(QTableWidget.NoEditTriggers)
    table.setSelectionMode(QTableWidget.NoSelection)
    table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    table.setStyleSheet("QTableWidget { border: none; gridline-color: #EEF1F5; }")
    for r, row in enumerate(rows):
        for c, val in enumerate(row):
            item = QTableWidgetItem(str(val))
            item.setTextAlignment(Qt.AlignCenter if c > 0 else Qt.AlignLeft | Qt.AlignVCenter)
            table.setItem(r, c, item)
    table.setFixedHeight(min(34 * (len(rows) + 1) + 10, 320))
    return table


class AnalyticsPage(QWidget):
    def __init__(self, db_manager=None, current_user=None):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user or {}
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        outer.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(28, 24, 28, 28)
        layout.setSpacing(18)

        header_row = QHBoxLayout()
        title = QLabel("Analytics")
        title.setObjectName("stubTitle")
        header_row.addWidget(title)
        header_row.addStretch()
        export_btn = QPushButton("📊 Export Full Report (Excel)")
        export_btn.setObjectName("primaryButton")
        export_btn.clicked.connect(self._export_full)
        header_row.addWidget(export_btn)
        layout.addLayout(header_row)

        subtitle = QLabel("Visual breakdowns of incidents, students, officers, patrols, and buildings.")
        subtitle.setObjectName("stubSubtitle")
        layout.addWidget(subtitle)

        if not self.db:
            layout.addStretch()
            return

        mcat = self.current_user.get("mcat_code")
        students = self.db.get_students(mcat_code=mcat)
        officers = self.db.get_officers(mcat_code=mcat)
        patrols = self.db.get_patrols(mcat_code=mcat)
        incidents = self.db.get_incidents(mcat_code=mcat)
        confiscated = self.db.get_confiscated_items(mcat_code=mcat)

        # Stat cards
        cards_row = QHBoxLayout()
        cards_row.setSpacing(14)
        open_cases = sum(1 for i in incidents if i.get("case_stage") in ("New", "Under Review"))
        for label, value in [
            ("Total Students", len(students)),
            ("Officers On Duty", f"{sum(1 for o in officers if o.get('on_duty'))} / {len(officers)}"),
            ("Open Cases", open_cases),
            ("Items Not Returned", sum(1 for c in confiscated if not c.get("returned"))),
        ]:
            cards_row.addWidget(StatCard(label, value))
        layout.addLayout(cards_row)

        # Monthly incidents chart
        year = datetime.now().year
        month_counts = Counter()
        for i in incidents:
            d = (i.get("date") or "")[:10]
            try:
                dt = datetime.fromisoformat(d)
                if dt.year == year:
                    month_counts[dt.month] += 1
            except ValueError:
                continue
        mi_data = [(calendar.month_abbr[m], month_counts.get(m, 0)) for m in range(1, 13)]
        mi_card = SectionCard("Monthly Incidents", f"{year} · incidents recorded per month")
        mi_card.add(BarChartWidget(mi_data, bar_color=NAVY))
        layout.addWidget(mi_card)

        # Two-column row: Student stats + Officer stats
        row2 = QHBoxLayout()
        row2.setSpacing(16)

        top_students = sorted(students, key=lambda s: s.get("incident_count") or 0, reverse=True)[:6]
        student_card = SectionCard("Student Statistics", "Top students by incident count")
        student_card.add(_make_table(
            ["Student", "Grade/Section", "Incidents"],
            [[s.get("full_name") or "", f"{s.get('grade') or ''} {s.get('section') or ''}".strip(),
              s.get("incident_count") or 0] for s in top_students] or [["—", "—", "—"]],
        ))
        row2.addWidget(student_card)

        patrol_counts = Counter(p.get("officer_id") for p in patrols)
        top_officers = sorted(officers, key=lambda o: patrol_counts.get(o.get("id"), 0), reverse=True)[:6]
        officer_card = SectionCard("Officer Statistics", "Top officers by patrols logged")
        officer_card.add(_make_table(
            ["Officer", "Rank", "Patrols"],
            [[o.get("full_name") or "", o.get("rank") or "",
              patrol_counts.get(o.get("id"), 0)] for o in top_officers] or [["—", "—", "—"]],
        ))
        row2.addWidget(officer_card)
        layout.addLayout(row2)

        # Two-column row: Patrol stats + Building stats
        row3 = QHBoxLayout()
        row3.setSpacing(16)

        status_counts = Counter(p.get("status") for p in patrols)
        patrol_card = SectionCard("Patrol Statistics", f"{len(patrols)} total patrol logs, by status")
        patrol_card.add(BarChartWidget(list(status_counts.items()), bar_color=GOLD.darker(110)))
        row3.addWidget(patrol_card)

        building_counts = Counter(i.get("building_name") or "Unassigned" for i in incidents)
        top_buildings = building_counts.most_common(6)
        building_card = SectionCard("Building Statistics", "Incidents recorded per building")
        building_card.add(BarChartWidget(top_buildings, bar_color=BLUE))
        row3.addWidget(building_card)

        layout.addLayout(row3)
        layout.addStretch()

    def _export_full(self):
        if not self.db:
            return
        try:
            title, wb = build_analytics_workbook(self.db, mcat_code=self.current_user.get("mcat_code"))
        except Exception as e:
            QMessageBox.warning(self, "Report error", f"Could not build the analytics report:\n{e}")
            return
        export_wb_interactive(self, title, wb)
