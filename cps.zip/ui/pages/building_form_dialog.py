from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QComboBox, QDialogButtonBox, QLabel
)


class BuildingFormDialog(QDialog):
    """Add or edit a single building. Pass `building` (a dict) to pre-fill for editing."""

    TYPE_OPTIONS = ["Academic", "Library", "Gym", "Cafeteria", "Clinic", "Administration", "Other"]

    def __init__(self, db_manager, building: dict = None, parent=None, mcat_code: str = None):
        super().__init__(parent)
        self.db = db_manager
        self.mcat_code = mcat_code
        self.building = building
        self.is_edit = building is not None

        self.setWindowTitle("Edit Building" if self.is_edit else "Add Building")
        self.setMinimumWidth(380)
        self._build_ui()
        if self.is_edit:
            self._populate_fields()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g. Building A")
        form.addRow("Building Name *", self.name_input)

        self.campus_combo = QComboBox()
        self._load_campuses()
        form.addRow("Campus *", self.campus_combo)

        self.type_combo = QComboBox()
        self.type_combo.setEditable(True)
        self.type_combo.addItems(self.TYPE_OPTIONS)
        form.addRow("Type", self.type_combo)

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _load_campuses(self):
        self.campuses = self.db.get_campuses(mcat_code=self.mcat_code)
        for campus in self.campuses:
            self.campus_combo.addItem(campus["name"], campus["id"])

    def _populate_fields(self):
        b = self.building
        self.name_input.setText(b.get("name") or "")
        if b.get("campus_id"):
            idx = self.campus_combo.findData(b["campus_id"])
            if idx >= 0:
                self.campus_combo.setCurrentIndex(idx)
        if b.get("building_type"):
            self.type_combo.setCurrentText(b["building_type"])

    def _on_save(self):
        name = self.name_input.text().strip()
        if not name:
            self.error_label.setText("Building Name is required.")
            return
        if self.campus_combo.count() == 0:
            self.error_label.setText("Create a campus first before adding buildings.")
            return

        self.result_data = {
            "name": name,
            "campus_id": self.campus_combo.currentData(),
            "building_type": self.type_combo.currentText().strip(),
        }
        self.accept()
