from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt


class StubPage(QWidget):
    """
    A placeholder page for a module that hasn't been built out yet.

    Each real module (Students, Officers, Incidents, etc.) will eventually
    replace this with its own widget containing a table, filters, and forms
    wired to the DatabaseManager. Keeping a consistent stub means the
    navigation and layout for the whole app already work end-to-end.
    """

    def __init__(self, title: str, description: str, planned_fields=None, db_manager=None):
        super().__init__()
        self.db = db_manager
        self._build_ui(title, description, planned_fields or [])

    def _build_ui(self, title, description, planned_fields):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        header_row = QHBoxLayout()
        title_label = QLabel(title)
        title_label.setObjectName("stubTitle")
        header_row.addWidget(title_label)
        header_row.addStretch()

        add_btn = QPushButton(f"+ Add {title.rstrip('s')}" if title.endswith("s") else f"+ Add {title}")
        add_btn.setObjectName("primaryButton")
        add_btn.setEnabled(False)
        add_btn.setToolTip("Wire this up to the Database Manager once the module is implemented.")
        header_row.addWidget(add_btn)

        layout.addLayout(header_row)

        subtitle_label = QLabel(description)
        subtitle_label.setObjectName("stubSubtitle")
        subtitle_label.setWordWrap(True)
        layout.addWidget(subtitle_label)

        card = QFrame()
        card.setProperty("class", "card")
        card.setStyleSheet(
            "QFrame { background-color: white; border: 1px dashed #cfd8e3; border-radius: 10px; }"
        )
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(24, 24, 24, 24)
        card_layout.setSpacing(6)

        placeholder = QLabel("🚧  Module not yet implemented")
        placeholder.setStyleSheet("font-size: 15px; font-weight: 600; color: #5a6b7d;")
        card_layout.addWidget(placeholder)

        if planned_fields:
            fields_label = QLabel("Planned fields:  " + "  ·  ".join(planned_fields))
            fields_label.setStyleSheet("font-size: 12px; color: #8ea0b3;")
            fields_label.setWordWrap(True)
            card_layout.addWidget(fields_label)

        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout.addWidget(card)
