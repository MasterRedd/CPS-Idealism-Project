import calendar
from datetime import datetime, date as date_cls

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView,
    QDialogButtonBox, QTimeEdit, QFormLayout
)
from PySide6.QtCore import Qt, QTime
from PySide6.QtGui import QColor

from ui.pages.report_export import ExportRangeDialog, build_irl_report


class IRLEditDialog(QDialog):
    """Lets an admin set/correct the IRL sign-in and sign-out time for one officer, one day."""

    def __init__(self, officer_name: str, date_str: str, record: dict = None, parent=None):
        super().__init__(parent)
        self.record = record
        self.setWindowTitle(f"IRL Sign Book — {officer_name} — {date_str}")
        self.setMinimumWidth(340)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.login_time_edit = QTimeEdit()
        self.login_time_edit.setDisplayFormat("hh:mm AP")
        self.logout_time_edit = QTimeEdit()
        self.logout_time_edit.setDisplayFormat("hh:mm AP")

        if record and record.get("login_time"):
            t = datetime.fromisoformat(record["login_time"])
            self.login_time_edit.setTime(QTime(t.hour, t.minute))
        else:
            self.login_time_edit.setTime(QTime(7, 30))

        if record and record.get("logout_time"):
            t = datetime.fromisoformat(record["logout_time"])
            self.logout_time_edit.setTime(QTime(t.hour, t.minute))
        else:
            self.logout_time_edit.setTime(QTime(16, 30))

        form.addRow("Signed In", self.login_time_edit)
        form.addRow("Signed Out", self.logout_time_edit)
        layout.addLayout(form)

        note = QLabel("This will be marked as a manual correction in the activity log.")
        note.setStyleSheet("color: #8ea0b3; font-size: 11px;")
        note.setWordWrap(True)
        layout.addWidget(note)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.date_str = date_str

    def get_iso_times(self):
        login_t = self.login_time_edit.time()
        logout_t = self.logout_time_edit.time()
        login_iso = f"{self.date_str}T{login_t.toString('HH:mm:ss')}"
        logout_iso = f"{self.date_str}T{logout_t.toString('HH:mm:ss')}"
        return login_iso, logout_iso


class IRLAdminDialog(QDialog):
    """
    Monthly IRL Sign Book overview across all officers, for admin oversight.

    Mirrors the Monthly Attendance dialog, but reads/writes the separate
    irl_sign_book table (the manual, physical "log in the moment you arrive"
    duty log, as opposed to the automatic app-login attendance).
    """

    def __init__(self, db_manager, current_user, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.current_user = current_user

        today = date_cls.today()
        self.year = today.year
        self.month = today.month

        self.setWindowTitle("IRL Sign Book — Monthly Overview")
        self.setMinimumSize(900, 560)
        self._build_ui()
        self._reload()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)

        header = QHBoxLayout()
        prev_btn = QPushButton("◀")
        prev_btn.setFixedWidth(36)
        prev_btn.clicked.connect(self._prev_month)
        header.addWidget(prev_btn)

        self.month_label = QLabel()
        self.month_label.setStyleSheet("font-size: 16px; font-weight: 700;")
        header.addWidget(self.month_label)

        next_btn = QPushButton("▶")
        next_btn.setFixedWidth(36)
        next_btn.clicked.connect(self._next_month)
        header.addWidget(next_btn)

        header.addStretch()
        legend = QLabel("🟢 Signed  ⚪ No record  ✏️ Manually corrected")
        legend.setStyleSheet("color: #6f8299; font-size: 11px;")
        header.addWidget(legend)

        export_btn = QPushButton("🖨️ Print / Export")
        export_btn.clicked.connect(self._open_export)
        header.addWidget(export_btn)

        layout.addLayout(header)

        self.table = QTableWidget()
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.table.cellDoubleClicked.connect(self._on_cell_double_clicked)
        layout.addWidget(self.table)

        summary_row = QHBoxLayout()
        self.summary_label = QLabel("")
        self.summary_label.setStyleSheet("color: #6f8299; font-size: 12px;")
        summary_row.addWidget(self.summary_label)
        summary_row.addStretch()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        summary_row.addWidget(close_btn)
        layout.addLayout(summary_row)

    # ------------------------------------------------------------------
    def _open_export(self):
        dialog = ExportRangeDialog(
            report_builder=lambda scope, year, month, day: build_irl_report(self.db, scope, year, month, day, mcat_code=self.current_user.get("mcat_code")),
            default_title="IRL Sign Book",
            parent=self,
        )
        dialog.exec()

    # ------------------------------------------------------------------
    def _prev_month(self):
        self.month -= 1
        if self.month == 0:
            self.month = 12
            self.year -= 1
        self._reload()

    def _next_month(self):
        self.month += 1
        if self.month == 13:
            self.month = 1
            self.year += 1
        self._reload()

    # ------------------------------------------------------------------
    def _reload(self):
        self.month_label.setText(calendar.month_name[self.month] + f" {self.year}")

        officers = self.db.get_officers(mcat_code=self.current_user.get("mcat_code"))
        records = self.db.get_irl_for_month(self.year, self.month)

        by_officer_day = {}
        for r in records:
            by_officer_day[(r["officer_id"], r["date"])] = r

        days_in_month = calendar.monthrange(self.year, self.month)[1]
        today = date_cls.today()

        self.table.setColumnCount(days_in_month + 2)
        headers = ["Officer", "Rank"] + [str(d) for d in range(1, days_in_month + 1)]
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(officers))
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)

        signed_count = 0

        for row, officer in enumerate(officers):
            self.table.setItem(row, 0, QTableWidgetItem(officer["full_name"]))
            self.table.setItem(row, 1, QTableWidgetItem(officer.get("rank") or ""))

            for day in range(1, days_in_month + 1):
                day_date = date_cls(self.year, self.month, day)
                date_str = day_date.isoformat()
                col = day + 1

                record = by_officer_day.get((officer["id"], date_str))
                item = QTableWidgetItem()
                item.setTextAlignment(Qt.AlignCenter)
                item.setData(Qt.UserRole, {"officer_id": officer["id"], "officer_name": officer["full_name"], "date": date_str})

                is_future = day_date > today

                if record and record.get("login_time"):
                    hours = record.get("hours_worked")
                    label = f"{hours:.1f}h" if hours is not None else "…"
                    if record.get("is_manual_edit"):
                        label += " ✏️"
                    item.setText(label)
                    item.setBackground(QColor("#e3f6e8"))
                    item.setForeground(QColor("#1e9e5a"))
                    signed_count += 1
                elif is_future:
                    item.setText("")
                    item.setBackground(QColor("#F5F8FC"))
                else:
                    item.setText("")
                    item.setBackground(QColor("#ffffff"))

                self.table.setItem(row, col, item)

        self.table.resizeColumnsToContents()
        self.summary_label.setText(
            f"{len(officers)} officer(s)  ·  {signed_count} signed day(s) this month  ·  "
            "double-click any past/today cell to add or correct an entry"
        )

    # ------------------------------------------------------------------
    def _on_cell_double_clicked(self, row, col):
        if col < 2:
            return
        item = self.table.item(row, col)
        if item is None:
            return
        meta = item.data(Qt.UserRole)
        if not meta:
            return

        day_date = date_cls.fromisoformat(meta["date"])
        if day_date > date_cls.today():
            QMessageBox.information(self, "Future date", "You can't set an IRL sign book entry for a day that hasn't happened yet.")
            return

        records = self.db.get_irl_for_month(self.year, self.month)
        existing = next(
            (r for r in records if r["officer_id"] == meta["officer_id"] and r["date"] == meta["date"]),
            None,
        )

        editor = IRLEditDialog(meta["officer_name"], meta["date"], record=existing, parent=self)
        if editor.exec():
            login_iso, logout_iso = editor.get_iso_times()
            if existing:
                self.db.update_irl_manual(
                    existing["id"], login_iso, logout_iso, actor_user_id=self.current_user["id"]
                )
            else:
                self.db.create_manual_irl(
                    meta["officer_id"], meta["date"], login_iso, logout_iso,
                    actor_user_id=self.current_user["id"],
                )
            self._reload()
