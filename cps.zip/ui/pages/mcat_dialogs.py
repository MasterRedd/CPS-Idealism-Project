from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QDialogButtonBox, QAbstractItemView
)
from PySide6.QtCore import Qt


class DeletionCountdownDialog(QDialog):
    """Shown right after login if this Administrator's account is inside
    the 30-day-inactive -> 24-hour countdown window."""

    def __init__(self, db_manager, mcat_code: str, hours_left: float, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.mcat_code = mcat_code
        self.cancelled_deletion = False
        self.deleted_now = False
        self.setWindowTitle("Account Scheduled for Deletion")
        self.setMinimumWidth(420)
        self._build_ui(hours_left)

    def _build_ui(self, hours_left):
        layout = QVBoxLayout(self)
        warn = QLabel("⚠ Your account was inactive for 30 days.")
        warn.setStyleSheet("font-size: 15px; font-weight: 700; color: #d9453d;")

        msg = QLabel(
            f"This Administrator account ({self.mcat_code}) is scheduled to be "
            f"permanently deleted in about {hours_left} hour(s), along with every "
            f"Officer account created under it. Since you just logged in, you can "
            f"cancel this now."
        )
        msg.setWordWrap(True)

        btn_row = QHBoxLayout()
        online_btn = QPushButton("I'm Now Online — Cancel Deletion")
        online_btn.setObjectName("primaryButton")
        online_btn.clicked.connect(self._cancel_deletion)

        delete_btn = QPushButton("Delete My Account Now")
        delete_btn.setStyleSheet("background: #d9453d; color: white;")
        delete_btn.clicked.connect(self._delete_now)

        btn_row.addWidget(online_btn)
        btn_row.addWidget(delete_btn)

        layout.addWidget(warn)
        layout.addWidget(msg)
        layout.addSpacing(8)
        layout.addLayout(btn_row)

    def _cancel_deletion(self):
        self.db.cancel_administrator_deletion_countdown(self.mcat_code)
        self.cancelled_deletion = True
        self.accept()

    def _delete_now(self):
        confirm = QMessageBox.question(
            self, "Confirm Deletion",
            "This will permanently delete your Administrator account and every "
            "Officer account under it. This cannot be undone. Continue?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_administrator(self.mcat_code)
            self.deleted_now = True
            self.accept()


class CreatorDashboard(QDialog):
    """View-only, for the Creator login. Lists every Administrator account
    (with officer counts, online/last-seen status, deletion countdowns).
    The Creator can view details and delete an Administrator — nothing else."""

    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.setWindowTitle("Creator — All Administrators")
        self.resize(820, 520)
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        heading = QLabel("Administrator Accounts")
        heading.setStyleSheet("font-size: 18px; font-weight: 800; color: #0A2E5C;")
        sub = QLabel("View-only. The Creator cannot edit an Administrator's data — only view or delete.")
        sub.setStyleSheet("color: #6b7c93; font-size: 11px;")
        layout.addWidget(heading)
        layout.addWidget(sub)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["MCAT", "Administrator", "Officers", "Status", "Last Seen", "Deletion Countdown"]
        )
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(self.table)

        btn_row = QHBoxLayout()
        view_btn = QPushButton("View Details")
        view_btn.clicked.connect(self._view_details)
        reset_btn = QPushButton("Force Reset Password")
        reset_btn.setStyleSheet("background: #D4AF37; color: #10233F; font-weight: 700;")
        reset_btn.clicked.connect(self._reset_password_selected)
        delete_btn = QPushButton("Delete Administrator")
        delete_btn.setStyleSheet("background: #d9453d; color: white;")
        delete_btn.clicked.connect(self._delete_selected)
        btn_row.addWidget(view_btn)
        btn_row.addWidget(reset_btn)
        btn_row.addWidget(delete_btn)
        btn_row.addStretch()
        close_btn = QDialogButtonBox(QDialogButtonBox.Close)
        close_btn.rejected.connect(self.reject)
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

    def refresh(self):
        admins = self.db.list_administrators()
        self.table.setRowCount(len(admins))
        for row, a in enumerate(admins):
            deleted = bool(a["is_deleted"])
            status = "Deleted" if deleted else ("Online" if a["is_online"] else "Offline")
            countdown = ""
            if not deleted and a["deletion_scheduled_at"]:
                status_info = self.db.get_deletion_status(a["mcat_code"])
                if status_info:
                    countdown = f"{status_info['hours_left']}h left"
            values = [
                a["mcat_code"], a["full_name"], str(a["officer_count"]),
                status, a["last_seen_at"] or "—", countdown or "—",
            ]
            for col, val in enumerate(values):
                item = QTableWidgetItem(val)
                if deleted:
                    item.setForeground(Qt.gray)
                self.table.setItem(row, col, item)

    def _selected_mcat(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return self.table.item(row, 0).text()

    def _view_details(self):
        mcat = self._selected_mcat()
        if not mcat:
            QMessageBox.information(self, "No selection", "Select an Administrator first.")
            return
        admin = self.db.get_administrator(mcat)
        officers = self.db.get_officers_under_mcat(mcat)
        lines = [
            f"Management Code: {admin['mcat_code']}",
            f"Administrator: {admin['full_name']}",
            f"Username shown at login: {admin['username']}",
            f"Last seen: {admin['last_seen_at']}",
            "",
            f"Officers under this account ({len(officers)}):",
        ]
        for o in officers:
            active = "active" if o["is_active"] else "inactive"
            lines.append(f"  • {o['full_name']} ({o['username']}) — {o.get('rank') or ''} — {active}")
        QMessageBox.information(self, f"Administrator {mcat}", "\n".join(lines))

    def _reset_password_selected(self):
        mcat = self._selected_mcat()
        if not mcat:
            QMessageBox.information(self, "No selection", "Select an Administrator first.")
            return
        admin = self.db.get_administrator(mcat)
        confirm = QMessageBox.question(
            self, "Force Reset Password",
            f"Generate a new temporary password for {admin['full_name']} ({mcat})?\n\n"
            "Their old password and any 'stay logged in' session on their device "
            "will stop working immediately. You'll need to relay the new password "
            "to them yourself — it is shown only once and is not saved anywhere.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm != QMessageBox.Yes:
            return
        new_password = self.db.reset_administrator_password(mcat)
        if not new_password:
            QMessageBox.warning(self, "Error", "Could not reset that account's password.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("New Temporary Password")
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(10)
        title = QLabel(f"New password for {admin['full_name']} ({mcat})")
        title.setStyleSheet("font-size: 14px; font-weight: 700; color: #0A2E5C;")
        title.setWordWrap(True)
        code = QLabel(new_password)
        code.setStyleSheet(
            "font-size: 20px; font-weight: 800; color: #10233F; background: #FFF6DD;"
            " border: 2px dashed #D4AF37; border-radius: 6px; padding: 12px;"
        )
        code.setAlignment(Qt.AlignCenter)
        code.setTextInteractionFlags(Qt.TextSelectableByMouse)
        warn = QLabel(
            "Shown once. Write it down or relay it to the Administrator now — it "
            "cannot be viewed again after you close this window."
        )
        warn.setStyleSheet("color: #6b7c93; font-size: 11px;")
        warn.setWordWrap(True)
        ok = QDialogButtonBox(QDialogButtonBox.Ok)
        ok.accepted.connect(dlg.accept)
        lay.addWidget(title)
        lay.addWidget(code)
        lay.addWidget(warn)
        lay.addWidget(ok)
        dlg.exec()
        self.refresh()

    def _delete_selected(self):
        mcat = self._selected_mcat()
        if not mcat:
            QMessageBox.information(self, "No selection", "Select an Administrator first.")
            return
        confirm = QMessageBox.question(
            self, "Confirm Deletion",
            f"Delete Administrator {mcat}? Every Officer account created under "
            f"it will stop working too. This cannot be undone.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_administrator(mcat)
            self.refresh()
