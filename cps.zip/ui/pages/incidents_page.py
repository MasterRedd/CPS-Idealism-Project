from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView,
    QComboBox
)
from PySide6.QtGui import QColor

from ui.pages.incident_form_dialog import IncidentFormDialog
from ui.pages.incident_case_dialog import IncidentCaseDialog

# Per spec: Officer "can record incidents" but "cannot delete records";
# Viewer is read-only across the board.
CAN_EDIT_ROLES = {"Administrator", "CAT Commander", "Chief Officer", "Officer"}
CAN_DELETE_ROLES = {"Administrator", "CAT Commander"}

COLUMNS = ["ID", "Student", "Category", "Severity", "Officer", "Campus", "Date", "Stage"]
STAGE_OPTIONS = ["All", "New", "Under Review", "Resolved", "Closed"]

SEVERITY_COLORS = {
    "Low": QColor("#1e9e5a"),
    "Medium": QColor("#c98a1c"),
    "High": QColor("#d97706"),
    "Critical": QColor("#d9453d"),
}
STAGE_COLORS = {
    "New": QColor("#c98a1c"),
    "Under Review": QColor("#2F7FD6"),
    "Resolved": QColor("#1e9e5a"),
    "Closed": QColor("#5a6b7d"),
}


class IncidentsPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self.can_edit = current_user.get("effective_role", current_user["role"]) in CAN_EDIT_ROLES
        self.can_delete = current_user.get("effective_role", current_user["role"]) in CAN_DELETE_ROLES

        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        header_row = QHBoxLayout()
        title = QLabel("Incidents")
        title.setObjectName("stubTitle")
        header_row.addWidget(title)
        header_row.addStretch()

        self.add_btn = QPushButton("+ Record Incident")
        self.add_btn.setObjectName("primaryButton")
        self.add_btn.clicked.connect(self._on_add)
        self.add_btn.setVisible(self.can_edit)
        header_row.addWidget(self.add_btn)
        layout.addLayout(header_row)

        subtitle = QLabel(
            "Each incident is a case that moves through stages: New → Under Review → Resolved → Closed."
        )
        subtitle.setObjectName("stubSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        filter_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by student, officer, category, or description...")
        self.search_input.textChanged.connect(self.refresh)
        filter_row.addWidget(self.search_input, 1)

        self.stage_filter = QComboBox()
        self.stage_filter.addItems(STAGE_OPTIONS)
        self.stage_filter.currentTextChanged.connect(self.refresh)
        filter_row.addWidget(self.stage_filter)
        layout.addLayout(filter_row)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnHidden(0, True)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setStyleSheet(
            "QTableWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; }"
            "QHeaderView::section { background-color: #0A2E5C; color: #ffffff; padding: 7px; border: none; font-weight: 600; }"
        )
        self.table.doubleClicked.connect(self._on_view_case)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        action_row.addStretch()

        self.view_btn = QPushButton("View Case")
        self.view_btn.clicked.connect(self._on_view_case)
        action_row.addWidget(self.view_btn)

        self.edit_btn = QPushButton("Edit Details")
        self.edit_btn.clicked.connect(self._on_edit)
        self.edit_btn.setVisible(self.can_edit)
        action_row.addWidget(self.edit_btn)

        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setStyleSheet("color: #d9453d;")
        self.delete_btn.clicked.connect(self._on_delete)
        self.delete_btn.setVisible(self.can_delete)
        action_row.addWidget(self.delete_btn)

        layout.addLayout(action_row)

        self.count_label = QLabel("")
        self.count_label.setStyleSheet("color: #8ea0b3; font-size: 12px;")
        layout.addWidget(self.count_label)

    # ------------------------------------------------------------------
    def refresh(self):
        search = self.search_input.text().strip()
        stage_filter = self.stage_filter.currentText()
        incidents = self.db.get_incidents(search=search, stage_filter=stage_filter, mcat_code=self.current_user.get("mcat_code"))

        self.table.setRowCount(0)
        for inc in incidents:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                str(inc["id"]),
                inc.get("student_name") or "—",
                inc.get("category") or "—",
                inc.get("severity") or "—",
                inc.get("officer_name") or "—",
                inc.get("campus_name") or "—",
                (inc.get("date") or "")[:16],
                inc.get("case_stage") or "New",
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 3:
                    item.setForeground(SEVERITY_COLORS.get(value, QColor("#10233F")))
                if col == 7:
                    item.setForeground(STAGE_COLORS.get(value, QColor("#10233F")))
                self.table.setItem(row, col, item)

        self.count_label.setText(f"{len(incidents)} incident(s)")

    # ------------------------------------------------------------------
    def _selected_incident_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return int(self.table.item(row, 0).text())

    def _on_add(self):
        dialog = IncidentFormDialog(self.db, current_user=self.current_user, parent=self)
        if dialog.exec():
            data = dialog.result_data
            evidence_paths = data.pop("evidence_paths", [])
            incident_id = self.db.create_incident(data, actor_user_id=self.current_user["id"])
            for path in evidence_paths:
                self.db.add_evidence(incident_id, path, added_by=self.current_user["id"])
            self.refresh()

    def _on_edit(self):
        incident_id = self._selected_incident_id()
        if incident_id is None:
            QMessageBox.information(self, "No selection", "Select an incident to edit first.")
            return
        incident = self.db.get_incident(incident_id)
        dialog = IncidentFormDialog(self.db, incident=incident, current_user=self.current_user, parent=self)
        if dialog.exec():
            data = dialog.result_data
            data.pop("evidence_paths", None)  # already saved live during edit
            self.db.update_incident(incident_id, data, actor_user_id=self.current_user["id"])
            self.refresh()

    def _on_view_case(self):
        incident_id = self._selected_incident_id()
        if incident_id is None:
            QMessageBox.information(self, "No selection", "Select an incident to view first.")
            return
        dialog = IncidentCaseDialog(
            self.db, incident_id, self.current_user, can_manage=self.can_edit, parent=self
        )
        dialog.exec()
        if dialog.changed:
            self.refresh()

    def _on_delete(self):
        incident_id = self._selected_incident_id()
        if incident_id is None:
            QMessageBox.information(self, "No selection", "Select an incident to delete first.")
            return
        confirm = QMessageBox.question(
            self, "Confirm delete",
            "Remove this incident from active records?\n\n"
            "This is a soft delete — the record is archived, not permanently erased.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_incident(incident_id, actor_user_id=self.current_user["id"])
            self.refresh()
