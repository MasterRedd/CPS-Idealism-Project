import os
from datetime import date

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QComboBox, QTextEdit, QLineEdit,
    QDialogButtonBox, QLabel, QHBoxLayout, QPushButton, QCompleter,
    QFileDialog, QListWidget, QListWidgetItem, QMessageBox, QSpinBox,
    QCheckBox, QDateEdit
)
from PySide6.QtCore import Qt, QSize, QDate
from PySide6.QtGui import QPixmap, QIcon

from ui.pages.image_viewer_dialog import ImageViewerDialog, is_image_file
from ui.widgets.scrollable import make_scrollable

IMAGE_FILE_FILTER = "Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp);;All Files (*)"


class ConfiscatedFormDialog(QDialog):
    """Add or edit a confiscated item. Evidence works exactly like the
    Incidents evidence gallery: for a brand-new item (no id yet), picked
    files are buffered and handed back via result_data['evidence_paths']
    for the page to save once the row exists. When editing, attach/remove
    is applied immediately against evidence_locker."""

    def __init__(self, db_manager, item: dict = None, current_user: dict = None, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.item = item
        self.is_edit = item is not None
        self.item_id = item["id"] if item else None
        self.current_user = current_user or {}

        self._pending_new_evidence = []
        self._existing_evidence = []

        self.setWindowTitle("Edit Confiscated Item" if self.is_edit else "Log Confiscated Item")
        self.setMinimumWidth(520)
        self._build_ui()
        if self.is_edit:
            self._populate_fields()
        self._refresh_evidence_list()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.student_combo = QComboBox()
        self.student_combo.setEditable(True)
        self._load_students()
        self.student_combo.setInsertPolicy(QComboBox.NoInsert)
        completer = QCompleter([self.student_combo.itemText(i) for i in range(self.student_combo.count())])
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setFilterMode(Qt.MatchContains)
        self.student_combo.setCompleter(completer)
        form.addRow("Student *", self.student_combo)

        self.officer_combo = QComboBox()
        self._load_officers()
        form.addRow("Confiscating Officer", self.officer_combo)

        self.item_input = QLineEdit()
        self.item_input.setPlaceholderText("e.g. Vape Device, Playing Cards, Cellphone")
        form.addRow("Item *", self.item_input)

        self.quantity_input = QSpinBox()
        self.quantity_input.setRange(1, 999)
        self.quantity_input.setValue(1)
        form.addRow("Quantity", self.quantity_input)

        self.reason_input = QTextEdit()
        self.reason_input.setFixedHeight(80)
        form.addRow("Reason", self.reason_input)

        returned_row = QHBoxLayout()
        self.returned_check = QCheckBox("Item has been returned")
        self.returned_check.toggled.connect(self._on_returned_toggled)
        returned_row.addWidget(self.returned_check)
        self.return_date_input = QDateEdit()
        self.return_date_input.setCalendarPopup(True)
        self.return_date_input.setDate(QDate.currentDate())
        self.return_date_input.setEnabled(False)
        returned_row.addWidget(self.return_date_input)
        form.addRow("Return Status", returned_row)

        layout.addLayout(form)

        # ---- Evidence gallery ----
        evidence_header = QHBoxLayout()
        evidence_title = QLabel("Evidence Photos")
        evidence_title.setStyleSheet("font-weight: 700; color: #10233F;")
        evidence_header.addWidget(evidence_title)
        evidence_header.addStretch()
        attach_btn = QPushButton("+ Attach Photos")
        attach_btn.clicked.connect(self._on_attach_evidence)
        evidence_header.addWidget(attach_btn)
        layout.addLayout(evidence_header)

        self.evidence_list = QListWidget()
        self.evidence_list.setViewMode(QListWidget.IconMode)
        self.evidence_list.setIconSize(QSize(84, 84))
        self.evidence_list.setResizeMode(QListWidget.Adjust)
        self.evidence_list.setMovement(QListWidget.Static)
        self.evidence_list.setFixedHeight(120)
        self.evidence_list.setSpacing(6)
        self.evidence_list.itemDoubleClicked.connect(self._on_preview_evidence)
        layout.addWidget(self.evidence_list)

        evidence_actions = QHBoxLayout()
        self.evidence_hint = QLabel("Double-click a photo to preview. Select and remove to detach.")
        self.evidence_hint.setStyleSheet("color: #7A8CA6; font-size: 11px;")
        evidence_actions.addWidget(self.evidence_hint, 1)
        remove_btn = QPushButton("Remove Selected")
        remove_btn.clicked.connect(self._on_remove_evidence)
        evidence_actions.addWidget(remove_btn)
        layout.addLayout(evidence_actions)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        make_scrollable(self)

    def _load_students(self):
        self.student_combo.addItem("— Select Student —", None)
        try:
            for s in self.db.get_students(mcat_code=self.current_user.get('mcat_code')):
                label = f"{s['full_name']} ({s.get('student_number') or '—'})"
                self.student_combo.addItem(label, s["id"])
        except Exception:
            pass

    def _load_officers(self):
        self.officer_combo.addItem("— No Officer —", None)
        try:
            for o in self.db.get_officers(mcat_code=self.current_user.get('mcat_code')):
                self.officer_combo.addItem(o["full_name"], o["id"])
        except Exception:
            pass

    def _on_returned_toggled(self, checked):
        self.return_date_input.setEnabled(checked)

    # ------------------------------------------------------------------
    # Evidence gallery (identical pattern to IncidentFormDialog)
    # ------------------------------------------------------------------
    def _current_evidence_paths(self):
        paths = [e.get("file_path") for e in self._existing_evidence]
        paths.extend(self._pending_new_evidence)
        return paths

    def _refresh_evidence_list(self):
        legacy = []
        if self.is_edit and self.item_id:
            all_items = self.db.get_evidence_for_confiscated_item(self.item_id)
            self._existing_evidence = [e for e in all_items if not e.get("legacy")]
            legacy = [e for e in all_items if e.get("legacy")]

        self.evidence_list.clear()
        for entry in legacy:
            self._add_thumbnail(entry.get("file_path"), removable=False)
        for entry in self._existing_evidence:
            self._add_thumbnail(entry.get("file_path"), removable=True, evidence_id=entry.get("id"))
        for path in self._pending_new_evidence:
            self._add_thumbnail(path, removable=True, pending=True)

    def _add_thumbnail(self, path, removable=True, evidence_id=None, pending=False):
        if not path:
            return
        name = os.path.basename(path)
        item = QListWidgetItem(name if len(name) < 16 else name[:13] + "…")
        item.setToolTip(path)
        if is_image_file(path) and os.path.exists(path):
            pix = QPixmap(path).scaled(84, 84, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            item.setIcon(QIcon(pix))
        item.setData(Qt.UserRole, {
            "path": path, "removable": removable, "evidence_id": evidence_id, "pending": pending,
        })
        self.evidence_list.addItem(item)

    def _on_attach_evidence(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Attach Evidence Photos", "", IMAGE_FILE_FILTER)
        if not paths:
            return
        if self.is_edit and self.item_id:
            actor = self.current_user.get("id")
            for p in paths:
                self.db.add_confiscated_evidence(self.item_id, p, added_by=actor)
        else:
            self._pending_new_evidence.extend(paths)
        self._refresh_evidence_list()

    def _on_remove_evidence(self):
        item = self.evidence_list.currentItem()
        if not item:
            QMessageBox.information(self, "No selection", "Select a photo to remove first.")
            return
        data = item.data(Qt.UserRole)
        if not data.get("removable"):
            QMessageBox.information(self, "Can't remove",
                                     "This is a legacy attachment and can't be removed here.")
            return
        if data.get("pending"):
            self._pending_new_evidence.remove(data["path"])
        else:
            self.db.delete_confiscated_evidence(data["evidence_id"], actor_user_id=self.current_user.get("id"))
        self._refresh_evidence_list()

    def _on_preview_evidence(self, item):
        data = item.data(Qt.UserRole)
        paths = self._current_evidence_paths()
        try:
            start_index = paths.index(data["path"])
        except ValueError:
            start_index = 0
        gallery = [{"file_path": p} for p in paths]
        viewer = ImageViewerDialog(gallery, start_index=start_index, parent=self)
        viewer.exec()

    # ------------------------------------------------------------------
    def _populate_fields(self):
        i = self.item
        if i.get("student_id"):
            idx = self.student_combo.findData(i["student_id"])
            if idx >= 0:
                self.student_combo.setCurrentIndex(idx)
        if i.get("officer_id"):
            idx = self.officer_combo.findData(i["officer_id"])
            if idx >= 0:
                self.officer_combo.setCurrentIndex(idx)
        self.item_input.setText(i.get("item_name") or "")
        self.quantity_input.setValue(i.get("quantity") or 1)
        self.reason_input.setPlainText(i.get("reason") or "")
        returned = bool(i.get("returned"))
        self.returned_check.setChecked(returned)
        if i.get("return_date"):
            qd = QDate.fromString(str(i["return_date"])[:10], "yyyy-MM-dd")
            if qd.isValid():
                self.return_date_input.setDate(qd)

    def _on_save(self):
        student_id = self.student_combo.currentData()
        item_name = self.item_input.text().strip()

        if student_id is None:
            self.error_label.setText("Select the student involved.")
            return
        if not item_name:
            self.error_label.setText("Item name is required.")
            return

        returned = self.returned_check.isChecked()
        return_date = self.return_date_input.date().toString("yyyy-MM-dd") if returned else None

        self.result_data = {
            "student_id": student_id,
            "officer_id": self.officer_combo.currentData(),
            "item_name": item_name,
            "quantity": self.quantity_input.value(),
            "reason": self.reason_input.toPlainText().strip(),
            "returned": returned,
            "return_date": return_date,
            "evidence_paths": list(self._pending_new_evidence),
        }
        self.accept()
