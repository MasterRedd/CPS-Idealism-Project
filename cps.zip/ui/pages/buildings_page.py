from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView
)

from ui.pages.building_form_dialog import BuildingFormDialog

CAN_EDIT_ROLES = {"Administrator", "CAT Commander"}
CAN_DELETE_ROLES = {"Administrator"}

COLUMNS = ["ID", "Building Name", "Campus", "Type"]


class BuildingsPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self.can_edit = current_user.get("effective_role", current_user["role"]) in CAN_EDIT_ROLES
        self.can_delete = current_user.get("effective_role", current_user["role"]) in CAN_DELETE_ROLES

        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        header_row = QHBoxLayout()
        title = QLabel("Buildings")
        title.setObjectName("stubTitle")
        header_row.addWidget(title)
        header_row.addStretch()

        self.add_btn = QPushButton("+ Add Building")
        self.add_btn.setObjectName("primaryButton")
        self.add_btn.clicked.connect(self._on_add)
        self.add_btn.setVisible(self.can_edit)
        header_row.addWidget(self.add_btn)
        layout.addLayout(header_row)

        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by building name, campus, or type...")
        self.search_input.textChanged.connect(self.refresh)
        search_row.addWidget(self.search_input)
        layout.addLayout(search_row)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnHidden(0, True)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setStyleSheet(
            "QTableWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; }"
            "QHeaderView::section { background-color: #0A2E5C; color: #ffffff; padding: 7px; border: none; font-weight: 600; }"
        )
        self.table.doubleClicked.connect(self._on_edit)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        action_row.addStretch()

        self.edit_btn = QPushButton("Edit Selected")
        self.edit_btn.clicked.connect(self._on_edit)
        self.edit_btn.setVisible(self.can_edit)
        action_row.addWidget(self.edit_btn)

        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setStyleSheet("color: #d9453d;")
        self.delete_btn.clicked.connect(self._on_delete)
        self.delete_btn.setVisible(self.can_delete)
        action_row.addWidget(self.delete_btn)

        layout.addLayout(action_row)

        self.count_label = QLabel("")
        self.count_label.setStyleSheet("color: #8ea0b3; font-size: 12px;")
        layout.addWidget(self.count_label)

    # ------------------------------------------------------------------
    def refresh(self):
        search = self.search_input.text().strip()
        buildings = self.db.get_buildings_full(search=search, mcat_code=self.current_user.get("mcat_code"))

        self.table.setRowCount(0)
        for building in buildings:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                str(building["id"]),
                building.get("name") or "",
                building.get("campus_name") or "—",
                building.get("building_type") or "—",
            ]
            for col, value in enumerate(values):
                self.table.setItem(row, col, QTableWidgetItem(value))

        self.count_label.setText(f"{len(buildings)} building(s)")

    # ------------------------------------------------------------------
    def _selected_building_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return int(self.table.item(row, 0).text())

    def _on_add(self):
        if not self.db.get_campuses(mcat_code=self.current_user.get("mcat_code")):
            QMessageBox.information(self, "No campuses yet", "Create a campus first before adding buildings.")
            return
        dialog = BuildingFormDialog(self.db, parent=self, mcat_code=self.current_user.get("mcat_code"))
        if dialog.exec():
            data = dialog.result_data
            self.db.create_building(
                data["name"], data["campus_id"], data["building_type"],
                actor_user_id=self.current_user["id"],
            )
            self.refresh()

    def _on_edit(self):
        building_id = self._selected_building_id()
        if building_id is None:
            QMessageBox.information(self, "No selection", "Select a building to edit first.")
            return
        building = self.db.get_building(building_id)
        dialog = BuildingFormDialog(self.db, building=building, parent=self, mcat_code=self.current_user.get("mcat_code"))
        if dialog.exec():
            data = dialog.result_data
            self.db.update_building(
                building_id, data["name"], data["campus_id"], data["building_type"],
                actor_user_id=self.current_user["id"],
            )
            self.refresh()

    def _on_delete(self):
        building_id = self._selected_building_id()
        if building_id is None:
            QMessageBox.information(self, "No selection", "Select a building to delete first.")
            return
        building = self.db.get_building(building_id)
        if self.db.building_in_use(building_id):
            QMessageBox.warning(
                self, "Building in use",
                f"{building['name']} still has officers assigned to it. Reassign them first.",
            )
            return
        confirm = QMessageBox.question(
            self, "Confirm delete",
            f"Remove {building['name']}? This is a soft delete — records referencing it are kept.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_building(building_id, actor_user_id=self.current_user["id"])
            self.refresh()
