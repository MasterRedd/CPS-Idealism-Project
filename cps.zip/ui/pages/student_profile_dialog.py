from pathlib import Path

from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFormLayout
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt


class StudentProfileDialog(QDialog):
    """Read-only profile view for a student: photo + full record info."""

    def __init__(self, student: dict, parent=None):
        super().__init__(parent)
        self.student = student
        self.setWindowTitle(f"Student Profile — {student.get('full_name', '')}")
        self.setMinimumWidth(460)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        top_row = QHBoxLayout()

        photo_label = QLabel()
        photo_label.setFixedSize(120, 120)
        photo_label.setAlignment(Qt.AlignCenter)
        photo_label.setStyleSheet("border: 1px solid #D3DAE1; border-radius: 8px; background: #EDF2F9; color: #8ea0b3;")
        photo_path = self.student.get("photo_path")
        if photo_path and Path(photo_path).exists():
            pix = QPixmap(photo_path)
            if not pix.isNull():
                photo_label.setPixmap(
                    pix.scaled(120, 120, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                )
        else:
            photo_label.setText("No Photo")
        top_row.addWidget(photo_label)

        name_col = QVBoxLayout()
        name_label = QLabel(self.student.get("full_name", ""))
        name_label.setObjectName("stubTitle")
        name_col.addWidget(name_label)
        sub_label = QLabel(f"Student No. {self.student.get('student_number', '—')}")
        sub_label.setStyleSheet("color: #5A6B7D;")
        name_col.addWidget(sub_label)
        name_col.addStretch()
        top_row.addLayout(name_col)
        top_row.addStretch()

        layout.addLayout(top_row)

        form = QFormLayout()
        form.setSpacing(8)
        fields = [
            ("Gender", self.student.get("gender")),
            ("Birthday", self.student.get("birthday")),
            ("Grade", self.student.get("grade")),
            ("Section", self.student.get("section")),
            ("Adviser", self.student.get("adviser")),
            ("Campus", self.student.get("campus_name")),
            ("Status", self.student.get("status")),
            ("Incident Count", self.student.get("incident_count")),
            ("Community Service Hours", self.student.get("community_service_hours")),
        ]
        for label, value in fields:
            form.addRow(f"{label}:", QLabel(str(value) if value not in (None, "") else "—"))
        layout.addLayout(form)

        if self.student.get("notes"):
            notes_label = QLabel(f"Notes: {self.student['notes']}")
            notes_label.setWordWrap(True)
            notes_label.setStyleSheet("color: #5A6B7D;")
            layout.addWidget(notes_label)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignRight)
