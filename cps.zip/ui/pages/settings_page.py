from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit, QPushButton,
    QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QMessageBox, QFileDialog, QComboBox, QInputDialog, QRadioButton, QButtonGroup
)
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt

from ui.widgets.photo_picker import IMAGE_FILE_FILTER
from ui.pages.id_card_dialog import IDCardDialog

ADMIN_ROLES = {"Administrator"}
BASE_TIERS = ["Administrator", "CAT Commander", "Chief Officer", "Officer", "Viewer"]

BACKUP_DIR = Path(__file__).resolve().parent.parent.parent / "data" / "backups"


class SettingsPage(QWidget):
    def __init__(self, db_manager, current_user=None):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user or {}
        self.is_admin = self.current_user.get("effective_role", self.current_user.get("role")) in ADMIN_ROLES

        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        title = QLabel("Settings")
        title.setObjectName("stubTitle")
        layout.addWidget(title)

        mcat_code = self.current_user.get("mcat_code")
        if mcat_code:
            mcat_banner = QLabel(f"🔑  Your Management Code (MCAT): {mcat_code}")
            mcat_banner.setStyleSheet(
                "background: #0A2E5C; color: #D4AF37; font-weight: 700; font-size: 13px; "
                "padding: 10px 14px; border-radius: 6px;"
            )
            layout.addWidget(mcat_banner)

        tabs = QTabWidget()
        tabs.addTab(self._build_school_info_tab(), "School Info")
        if self.is_admin:
            tabs.addTab(self._build_backup_tab(), "Backup / Restore")
            tabs.addTab(self._build_online_tab(), "Online")
        tabs.addTab(self._build_appearance_tab(), "Appearance")
        if self.current_user.get("officer_id"):
            tabs.addTab(self._build_my_id_tab(), "My ID")
        tabs.addTab(self._build_about_tab(), "About")

        layout.addWidget(tabs)

    # ------------------------------------------------------------------
    # School Info
    # ------------------------------------------------------------------
    def _build_school_info_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(14)
        layout.setContentsMargins(20, 20, 20, 20)

        form = QFormLayout()
        form.setSpacing(10)

        self.school_name_input = QLineEdit(self.db.get_setting("school_name", "CAT Program System"))
        form.addRow("School Name", self.school_name_input)

        self.school_address_input = QLineEdit(self.db.get_setting("school_address", ""))
        form.addRow("Address", self.school_address_input)

        self.school_principal_input = QLineEdit(self.db.get_setting("school_principal", ""))
        form.addRow("Principal", self.school_principal_input)

        self.school_contact_input = QLineEdit(self.db.get_setting("school_contact", ""))
        form.addRow("Contact Number", self.school_contact_input)

        logo_row = QHBoxLayout()
        self.logo_preview = QLabel()
        self.logo_preview.setFixedSize(72, 72)
        self.logo_preview.setAlignment(Qt.AlignCenter)
        self.logo_preview.setStyleSheet("border: 1px solid #D3DAE1; border-radius: 6px; background: #EDF2F9;")
        self._logo_path = self.db.get_setting("school_logo_path", "") or None
        self._refresh_logo_preview()
        logo_row.addWidget(self.logo_preview)

        logo_btn = QPushButton("Choose Logo…")
        logo_btn.clicked.connect(self._choose_logo)
        logo_btn.setVisible(self.is_admin)
        logo_row.addWidget(logo_btn)
        logo_row.addStretch()
        form.addRow("School Logo", logo_row)

        layout.addLayout(form)

        if not self.is_admin:
            for w in [self.school_name_input, self.school_address_input,
                      self.school_principal_input, self.school_contact_input]:
                w.setReadOnly(True)

        save_btn = QPushButton("Save School Info")
        save_btn.setObjectName("primaryButton")
        save_btn.clicked.connect(self._save_school_info)
        save_btn.setVisible(self.is_admin)
        layout.addWidget(save_btn, alignment=Qt.AlignLeft)
        layout.addStretch()
        return tab

    def _choose_logo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose School Logo", "", IMAGE_FILE_FILTER)
        if path:
            self._logo_path = path
            self._refresh_logo_preview()

    def _refresh_logo_preview(self):
        if self._logo_path and Path(self._logo_path).exists():
            pix = QPixmap(self._logo_path).scaled(72, 72, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.logo_preview.setPixmap(pix)
        else:
            self.logo_preview.setPixmap(QPixmap())
            self.logo_preview.setText("No Logo")

    def _save_school_info(self):
        self.db.set_setting("school_name", self.school_name_input.text().strip())
        self.db.set_setting("school_address", self.school_address_input.text().strip())
        self.db.set_setting("school_principal", self.school_principal_input.text().strip())
        self.db.set_setting("school_contact", self.school_contact_input.text().strip())
        self.db.set_setting("school_logo_path", self._logo_path or "")
        QMessageBox.information(self, "Saved", "School information updated.")

    # ------------------------------------------------------------------
    # Users & Permissions
    # ------------------------------------------------------------------
    def _build_users_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        layout.addWidget(QLabel("All Accounts"))
        self.users_table = QTableWidget(0, 6)
        self.users_table.setHorizontalHeaderLabels(
            ["ID", "Name", "Username", "Role", "Active", "Linked Officer"]
        )
        self.users_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.users_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.users_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.users_table.verticalHeader().setVisible(False)
        self.users_table.setColumnHidden(0, True)
        self.users_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        layout.addWidget(self.users_table)

        acct_btn_row = QHBoxLayout()
        toggle_btn = QPushButton("Activate / Deactivate Selected")
        toggle_btn.clicked.connect(self._toggle_account_active)
        acct_btn_row.addWidget(toggle_btn)

        reset_btn = QPushButton("Reset Password")
        reset_btn.clicked.connect(self._reset_password)
        acct_btn_row.addWidget(reset_btn)
        acct_btn_row.addStretch()
        layout.addLayout(acct_btn_row)

        layout.addWidget(QLabel("Custom Role Permissions"))
        hint = QLabel(
            "Custom account roles (typed freely when adding an officer) don't come with built-in "
            "permissions. Map each one to the base tier it should inherit for sidebar access."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #5A6B7D; font-size: 12px;")
        layout.addWidget(hint)

        self.roles_table = QTableWidget(0, 2)
        self.roles_table.setHorizontalHeaderLabels(["Custom Role", "Inherits Permissions Of"])
        self.roles_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.roles_table.verticalHeader().setVisible(False)
        self.roles_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        layout.addWidget(self.roles_table)

        self._refresh_users_tab()
        return tab

    def _refresh_users_tab(self):
        accounts = self.db.get_all_accounts()
        self.users_table.setRowCount(0)
        for acct in accounts:
            row = self.users_table.rowCount()
            self.users_table.insertRow(row)
            values = [
                str(acct["id"]),
                acct.get("full_name") or "",
                acct.get("username") or "",
                acct.get("role") or "",
                "Yes" if acct.get("is_active") else "No",
                acct.get("officer_number") or "—",
            ]
            for col, value in enumerate(values):
                self.users_table.setItem(row, col, QTableWidgetItem(value))

        custom_roles = self.db.get_distinct_custom_roles()
        tier_map = self.db.get_role_tier_map()
        self.roles_table.setRowCount(0)
        for role_name in custom_roles:
            row = self.roles_table.rowCount()
            self.roles_table.insertRow(row)
            self.roles_table.setItem(row, 0, QTableWidgetItem(role_name))

            combo = QComboBox()
            combo.addItems(BASE_TIERS)
            current_tier = tier_map.get(role_name, "Officer")
            if current_tier in BASE_TIERS:
                combo.setCurrentText(current_tier)
            combo.currentTextChanged.connect(
                lambda tier, rn=role_name: self.db.set_role_tier(
                    rn, tier, actor_user_id=self.current_user.get("id")
                )
            )
            self.roles_table.setCellWidget(row, 1, combo)

        if not custom_roles:
            self.roles_table.setRowCount(1)
            self.roles_table.setItem(0, 0, QTableWidgetItem("(no custom roles in use yet)"))
            self.roles_table.setItem(0, 1, QTableWidgetItem(""))

    def _selected_user_id(self):
        row = self.users_table.currentRow()
        if row < 0:
            return None
        return int(self.users_table.item(row, 0).text())

    def _toggle_account_active(self):
        user_id = self._selected_user_id()
        if user_id is None:
            QMessageBox.information(self, "No selection", "Select an account first.")
            return
        row = self.users_table.currentRow()
        currently_active = self.users_table.item(row, 4).text() == "Yes"
        if user_id == self.current_user.get("id") and currently_active:
            QMessageBox.warning(self, "Not allowed", "You can't deactivate your own account while logged in.")
            return
        self.db.set_account_active(user_id, not currently_active, actor_user_id=self.current_user.get("id"))
        self._refresh_users_tab()

    def _reset_password(self):
        user_id = self._selected_user_id()
        if user_id is None:
            QMessageBox.information(self, "No selection", "Select an account first.")
            return
        new_password, ok = QInputDialog.getText(self, "Reset Password", "Enter a new password for this account:")
        if ok and new_password.strip():
            self.db.reset_account_password(user_id, new_password.strip(), actor_user_id=self.current_user.get("id"))
            QMessageBox.information(self, "Password Reset", "The account's password has been updated.")

    # ------------------------------------------------------------------
    # Backup / Restore
    # ------------------------------------------------------------------
    def _build_backup_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        info = QLabel(f"Backups are stored in:\n{BACKUP_DIR}")
        info.setWordWrap(True)
        info.setStyleSheet("color: #5A6B7D;")
        layout.addWidget(info)

        backup_btn = QPushButton("Backup Now")
        backup_btn.setObjectName("primaryButton")
        backup_btn.clicked.connect(self._backup_now)
        layout.addWidget(backup_btn, alignment=Qt.AlignLeft)

        layout.addWidget(QLabel("Previous Backups"))
        self.backups_table = QTableWidget(0, 2)
        self.backups_table.setHorizontalHeaderLabels(["File", "Created"])
        self.backups_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.backups_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.backups_table.verticalHeader().setVisible(False)
        self.backups_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        layout.addWidget(self.backups_table)

        restore_btn = QPushButton("Restore Selected Backup")
        restore_btn.setStyleSheet("color: #d9453d;")
        restore_btn.clicked.connect(self._restore_backup)
        layout.addWidget(restore_btn, alignment=Qt.AlignLeft)

        self._refresh_backups()
        return tab

    def _refresh_backups(self):
        import datetime
        self.backups_table.setRowCount(0)
        for path in self.db.list_backups(BACKUP_DIR):
            row = self.backups_table.rowCount()
            self.backups_table.insertRow(row)
            self.backups_table.setItem(row, 0, QTableWidgetItem(path.name))
            mtime = datetime.datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
            self.backups_table.setItem(row, 1, QTableWidgetItem(mtime))

    def _backup_now(self):
        try:
            dest = self.db.backup_database(BACKUP_DIR, actor_user_id=self.current_user.get("id"))
            QMessageBox.information(self, "Backup Complete", f"Backup saved to:\n{dest}")
            self._refresh_backups()
        except Exception as e:
            QMessageBox.warning(self, "Backup Failed", str(e))

    def _restore_backup(self):
        row = self.backups_table.currentRow()
        if row < 0:
            QMessageBox.information(self, "No selection", "Select a backup to restore first.")
            return
        filename = self.backups_table.item(row, 0).text()
        confirm = QMessageBox.question(
            self, "Confirm Restore",
            f"Restore the database from:\n{filename}\n\n"
            "This replaces all current data with the backup. Restart the app afterwards.\n"
            "This cannot be undone. Continue?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            try:
                self.db.restore_database(BACKUP_DIR / filename, actor_user_id=self.current_user.get("id"))
                QMessageBox.information(
                    self, "Restore Complete", "Database restored. Please restart the application now."
                )
            except Exception as e:
                QMessageBox.warning(self, "Restore Failed", str(e))

    # ------------------------------------------------------------------
    # Online (Supabase connection for Chat / Boarding / global MCAT)
    # ------------------------------------------------------------------
    def _build_online_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(14)
        layout.setContentsMargins(20, 20, 20, 20)

        intro = QLabel(
            "Connects this installation to a free Supabase project — needed "
            "for Chat, Boarding, and truly global Management Codes across "
            "every device. Optional: the app works fully offline without it."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color: #6b7c93; font-size: 12px;")
        layout.addWidget(intro)

        howto = QPushButton("How do I get a Project URL and anon key?")
        howto.setFlat(True)
        howto.setStyleSheet("color: #1657A8; text-decoration: underline; border: none; text-align: left;")
        howto.clicked.connect(lambda: QMessageBox.information(
            self, "Getting Your Supabase Credentials",
            "1. Go to supabase.com and create a free account/project.\n"
            "2. Run online/supabase_schema.sql once in its SQL Editor.\n"
            "3. Project Settings -> API -> copy the Project URL and the\n"
            "   'anon public' key (not the service_role key).\n"
            "4. Paste both below and click Save & Test Connection.\n\n"
            "Full details are in online/README.md."
        ))
        layout.addWidget(howto)

        form = QFormLayout()
        form.setSpacing(10)
        from online.config import get_credentials
        saved_url, saved_key = get_credentials()
        self.supabase_url_input = QLineEdit(saved_url or "")
        self.supabase_url_input.setPlaceholderText("https://xxxxxxxxxxxx.supabase.co")
        form.addRow("Project URL", self.supabase_url_input)

        self.supabase_key_input = QLineEdit(saved_key or "")
        self.supabase_key_input.setPlaceholderText("anon public key")
        self.supabase_key_input.setEchoMode(QLineEdit.Password)
        form.addRow("Anon Key", self.supabase_key_input)
        layout.addLayout(form)

        self.online_status_label = QLabel(
            "🟢 Connected" if saved_url and saved_key else "⚪ Not configured — running fully offline"
        )
        self.online_status_label.setStyleSheet("font-size: 12px; font-weight: 600;")
        layout.addWidget(self.online_status_label)

        save_btn = QPushButton("Save & Test Connection")
        save_btn.setObjectName("primaryButton")
        save_btn.clicked.connect(self._save_online_credentials)
        layout.addWidget(save_btn, alignment=Qt.AlignLeft)
        layout.addStretch()
        return tab

    def _save_online_credentials(self):
        url = self.supabase_url_input.text().strip()
        key = self.supabase_key_input.text().strip()
        if not url or not key:
            QMessageBox.warning(self, "Missing Info", "Both the Project URL and Anon Key are required.")
            return
        from online.config import save_credentials
        save_credentials(url, key)
        try:
            from online.supabase_client import OnlineSync
            test = OnlineSync()
            if not test.is_available():
                self.online_status_label.setText("🔴 Saved, but couldn't connect")
                QMessageBox.warning(
                    self, "Connection Failed",
                    f"Credentials were saved, but connecting failed:\n{test.last_error}\n\n"
                    "Double-check the URL/key, and that you ran supabase_schema.sql."
                )
                return
            # is_available() only proves the client object was built — it
            # does NOT prove the network, the tables, or permissions are
            # actually working. Run one real, harmless query so a broken
            # schema/RLS/network setup is caught here instead of silently
            # showing "Connected" while Chat quietly fails later.
            rows = test.fetch_registry_snapshot()
            if test.last_error:
                self.online_status_label.setText("🟠 Connected, but a test query failed")
                QMessageBox.warning(
                    self, "Query Failed",
                    "The connection itself works, but a real test query against "
                    f"your database failed:\n\n{test.last_error}\n\n"
                    "This usually means supabase_schema.sql hasn't been run (or "
                    "needs re-running) in your Supabase project's SQL Editor."
                )
                return
            self.online_status_label.setText("🟢 Connected — verified with a live query")
            QMessageBox.information(
                self, "Connected",
                f"Saved and verified — found {len(rows)} row(s) in the online registry. "
                "Restart the app for every screen to pick up the new connection."
            )
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not test the connection: {e}")

    # ------------------------------------------------------------------
    # Appearance
    # ------------------------------------------------------------------
    def _build_appearance_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        layout.addWidget(QLabel("Theme stays Blue / Gold / White — choose a light or dark surface."))

        self.theme_group = QButtonGroup(tab)
        light_radio = QRadioButton("Light (default)")
        dark_radio = QRadioButton("Dark")
        self.theme_group.addButton(light_radio, 0)
        self.theme_group.addButton(dark_radio, 1)

        current_theme = self.db.get_setting("theme_mode", "light")
        dark_radio.setChecked(current_theme == "dark")
        light_radio.setChecked(current_theme != "dark")

        layout.addWidget(light_radio)
        layout.addWidget(dark_radio)

        apply_btn = QPushButton("Apply Theme")
        apply_btn.setObjectName("primaryButton")
        apply_btn.clicked.connect(lambda: self._apply_theme(dark_radio.isChecked()))
        layout.addWidget(apply_btn, alignment=Qt.AlignLeft)

        note = QLabel("A restart is needed for the new theme to fully apply everywhere.")
        note.setStyleSheet("color: #8ea0b3; font-size: 12px;")
        layout.addWidget(note)
        layout.addStretch()
        return tab

    def _apply_theme(self, dark: bool):
        self.db.set_setting("theme_mode", "dark" if dark else "light")
        QMessageBox.information(self, "Theme Saved", "Restart the application to see the new theme.")

    # ------------------------------------------------------------------
    # My ID (officer-linked accounts)
    # ------------------------------------------------------------------
    def _build_my_id_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        layout.addWidget(QLabel("Your official CAT Officer ID card."))
        view_btn = QPushButton("🪪 View My ID Card")
        view_btn.setObjectName("primaryButton")
        view_btn.clicked.connect(self._view_my_id)
        layout.addWidget(view_btn, alignment=Qt.AlignLeft)
        layout.addStretch()
        return tab

    def _view_my_id(self):
        profile = self.db.get_officer_profile(self.current_user["officer_id"])
        school_name = self.db.get_setting("school_name", "CAT Program System")
        dialog = IDCardDialog(profile, school_name=school_name, parent=self)
        dialog.exec()

    # ------------------------------------------------------------------
    # About
    # ------------------------------------------------------------------
    def _build_about_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)

        layout.addWidget(QLabel("CAT Program System (CPS)"))
        layout.addWidget(QLabel("Version 0.9 — Development Build"))

        db_path = self.db.db_path
        try:
            size_kb = Path(db_path).stat().st_size / 1024
            size_str = f"{size_kb:,.1f} KB"
        except Exception:
            size_str = "—"

        layout.addWidget(QLabel(f"Database file: {db_path}"))
        layout.addWidget(QLabel(f"Database size: {size_str}"))

        counts = QFormLayout()
        for table, label in [
            ("students", "Students"), ("officers", "Officers"),
            ("campuses", "Campuses"), ("incidents", "Incidents"),
            ("confiscated_items", "Confiscated Items"), ("patrol_logs", "Patrol Logs"),
        ]:
            try:
                counts.addRow(f"{label}:", QLabel(str(self.db.count(table, mcat_code=self.current_user.get("mcat_code")))))
            except Exception:
                pass
        layout.addLayout(counts)
        layout.addStretch()
        return tab
