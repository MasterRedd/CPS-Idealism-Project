from datetime import datetime, date as date_cls

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView, QMessageBox
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor

HISTORY_COLUMNS = ["Date", "Day", "Signed In", "Signed Out", "Hours"]


class IRLSignBookPage(QWidget):
    """
    A manual, physical duty log — separate from the automatic app login/logout
    attendance. The officer presses "Log In IRL" the moment they physically
    arrive on campus and "Log Out IRL" the moment they leave.

    The live stopwatch is driven by a QTimer that just redraws the elapsed
    time every second; the actual source of truth is the login_time stored
    in the database, so closing and reopening the app (or even the whole
    computer restarting) doesn't lose or reset the running session — the
    elapsed time is simply recalculated from "now minus login_time" the
    next time this page loads.
    """

    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self.officer_id = current_user.get("officer_id")

        self.active_record_id = None
        self.active_login_time = None  # datetime, or None if not currently signed in

        self._build_ui()
        self._tick_timer = QTimer(self)
        self._tick_timer.timeout.connect(self._update_stopwatch)
        self._tick_timer.start(1000)

        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        title = QLabel("IRL Sign Book")
        title.setObjectName("stubTitle")
        layout.addWidget(title)

        subtitle = QLabel(
            "Sign in the moment you physically arrive on campus, and sign out the moment you "
            "leave. This runs independently of your app login — the timer keeps counting even "
            "if you close and reopen the app."
        )
        subtitle.setObjectName("stubSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        card = QFrame()
        card.setStyleSheet(
            "QFrame { background-color: white; border: 1px solid #E2E7EE; border-radius: 10px; }"
        )
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(28, 24, 28, 24)
        card_layout.setSpacing(10)
        card_layout.setAlignment(Qt.AlignHCenter)

        self.date_label = QLabel("")
        self.date_label.setAlignment(Qt.AlignHCenter)
        self.date_label.setStyleSheet("font-size: 13px; color: #6f8299; font-weight: 600;")
        card_layout.addWidget(self.date_label)

        self.stopwatch_label = QLabel("00:00:00")
        self.stopwatch_label.setAlignment(Qt.AlignHCenter)
        self.stopwatch_label.setStyleSheet("font-size: 46px; font-weight: 800; color: #1f2d3d;")
        card_layout.addWidget(self.stopwatch_label)

        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignHCenter)
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("font-size: 13px; color: #6f8299;")
        card_layout.addWidget(self.status_label)

        btn_row = QHBoxLayout()
        btn_row.addStretch()

        self.login_btn = QPushButton("▶  Log In IRL")
        self.login_btn.setObjectName("primaryButton")
        self.login_btn.setFixedHeight(42)
        self.login_btn.clicked.connect(self._on_sign_in)
        btn_row.addWidget(self.login_btn)

        self.logout_btn = QPushButton("■  Log Out IRL")
        self.logout_btn.setFixedHeight(42)
        self.logout_btn.setStyleSheet("color: #d9453d; font-weight: 700;")
        self.logout_btn.clicked.connect(self._on_sign_out)
        btn_row.addWidget(self.logout_btn)

        btn_row.addStretch()
        card_layout.addLayout(btn_row)

        layout.addWidget(card)

        history_label = QLabel("Recent History")
        history_label.setStyleSheet("font-size: 14px; font-weight: 700; color: #1f2d3d;")
        layout.addWidget(history_label)

        self.history_table = QTableWidget(0, len(HISTORY_COLUMNS))
        self.history_table.setHorizontalHeaderLabels(HISTORY_COLUMNS)
        self.history_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.history_table.setSelectionMode(QAbstractItemView.NoSelection)
        self.history_table.verticalHeader().setVisible(False)
        self.history_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.history_table.setStyleSheet(
            "QTableWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; }"
            "QHeaderView::section { background-color: #0A2E5C; color: #ffffff; padding: 7px; border: none; font-weight: 600; }"
        )
        layout.addWidget(self.history_table)

    # ------------------------------------------------------------------
    def refresh(self):
        if not self.officer_id:
            self.status_label.setText("This account isn't linked to an officer record.")
            self.login_btn.setEnabled(False)
            self.logout_btn.setEnabled(False)
            return

        today = date_cls.today()
        self.date_label.setText(today.strftime("%A, %B %d, %Y"))

        record = self.db.get_irl_today(self.officer_id)

        if record and record.get("logout_time"):
            # Already completed duty for today — locked out until tomorrow.
            self.active_record_id = None
            self.active_login_time = None
            hours = record.get("hours_worked")
            self.stopwatch_label.setText(self._format_hours(hours))
            self.status_label.setText(
                "✅ Duty completed for today. You can sign in again tomorrow."
            )
            self.login_btn.setEnabled(False)
            self.logout_btn.setEnabled(False)
        elif record and record.get("login_time"):
            # Currently on duty — resume the live stopwatch from the stored start time.
            self.active_record_id = record["id"]
            self.active_login_time = datetime.fromisoformat(record["login_time"])
            self.status_label.setText(
                f"🟢 On duty since {self.active_login_time.strftime('%I:%M %p')}"
            )
            self.login_btn.setEnabled(False)
            self.logout_btn.setEnabled(True)
            self._update_stopwatch()
        else:
            # Nothing recorded yet today.
            self.active_record_id = None
            self.active_login_time = None
            self.stopwatch_label.setText("00:00:00")
            self.status_label.setText("You haven't signed in yet today.")
            self.login_btn.setEnabled(True)
            self.logout_btn.setEnabled(False)

        self._load_history()

    def _update_stopwatch(self):
        if not self.active_login_time:
            return
        elapsed = datetime.now() - self.active_login_time
        total_seconds = max(0, int(elapsed.total_seconds()))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        self.stopwatch_label.setText(f"{h:02d}:{m:02d}:{s:02d}")

    @staticmethod
    def _format_hours(hours):
        if hours is None:
            return "00:00:00"
        total_seconds = int(round(hours * 3600))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"

    # ------------------------------------------------------------------
    def _on_sign_in(self):
        record_id = self.db.irl_sign_in(self.officer_id)
        if record_id is None:
            QMessageBox.information(
                self, "Already completed",
                "You've already completed your IRL duty log for today. You can sign in again tomorrow.",
            )
        self.refresh()

    def _on_sign_out(self):
        if not self.active_record_id:
            return
        confirm = QMessageBox.question(
            self, "Log Out IRL",
            "This will stop your live duty timer and record your hours for today.\n"
            "You won't be able to sign in again until tomorrow. Continue?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm != QMessageBox.Yes:
            return
        self.db.irl_sign_out(self.officer_id, self.active_record_id)
        self.refresh()

    # ------------------------------------------------------------------
    def _load_history(self):
        records = self.db.get_irl_history(self.officer_id, limit=31)
        self.history_table.setRowCount(0)
        for r in records:
            row = self.history_table.rowCount()
            self.history_table.insertRow(row)

            day_date = date_cls.fromisoformat(r["date"])
            login_str = self._format_time(r.get("login_time"))
            logout_str = self._format_time(r.get("logout_time")) if r.get("logout_time") else "—"
            hours = r.get("hours_worked")
            hours_str = f"{hours:.2f} h" if hours is not None else "—"
            if r.get("is_manual_edit"):
                hours_str += " ✏️"

            values = [day_date.strftime("%Y-%m-%d"), day_date.strftime("%A"), login_str, logout_str, hours_str]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 3 and logout_str == "—":
                    item.setForeground(QColor("#1e9e5a"))
                self.history_table.setItem(row, col, item)

    @staticmethod
    def _format_time(iso_str):
        if not iso_str:
            return "—"
        try:
            return datetime.fromisoformat(iso_str).strftime("%I:%M %p")
        except ValueError:
            return iso_str
