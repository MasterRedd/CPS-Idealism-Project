from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QDialogButtonBox, QLabel
)


class CampusFormDialog(QDialog):
    """Add or edit a single campus. Pass `campus` (a dict) to pre-fill for editing."""

    def __init__(self, campus: dict = None, parent=None):
        super().__init__(parent)
        self.campus = campus
        self.is_edit = campus is not None

        self.setWindowTitle("Edit Campus" if self.is_edit else "Add Campus")
        self.setMinimumWidth(380)
        self._build_ui()
        if self.is_edit:
            self._populate_fields()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g. Main Campus")
        form.addRow("Campus Name *", self.name_input)

        self.address_input = QLineEdit()
        form.addRow("Address", self.address_input)

        self.principal_input = QLineEdit()
        form.addRow("Principal", self.principal_input)

        self.contact_input = QLineEdit()
        self.contact_input.setPlaceholderText("e.g. 09171234567")
        form.addRow("Contact Number", self.contact_input)

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _populate_fields(self):
        c = self.campus
        self.name_input.setText(c.get("name") or "")
        self.address_input.setText(c.get("address") or "")
        self.principal_input.setText(c.get("principal") or "")
        self.contact_input.setText(c.get("contact_number") or "")

    def _on_save(self):
        name = self.name_input.text().strip()
        if not name:
            self.error_label.setText("Campus Name is required.")
            return

        self.result_data = {
            "name": name,
            "address": self.address_input.text().strip(),
            "principal": self.principal_input.text().strip(),
            "contact_number": self.contact_input.text().strip(),
        }
        self.accept()
