from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QSizePolicy, QListWidget
)


class StatCard(QFrame):
    def __init__(self, label: str, value):
        super().__init__()
        self.setProperty("class", "card")
        self.setStyleSheet(
            "QFrame { background-color: white; border-radius: 10px; border: 1px solid #E2E7EE; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)

        value_label = QLabel(str(value))
        value_label.setStyleSheet("font-size: 26px; font-weight: 800; color: #10233F;")
        label_label = QLabel(label)
        label_label.setStyleSheet("font-size: 12px; color: #6f8299;")

        layout.addWidget(value_label)
        layout.addWidget(label_label)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)


class DashboardPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(18)

        welcome = QLabel(f"Welcome back, {self.current_user['full_name']}")
        welcome.setObjectName("stubTitle")
        layout.addWidget(welcome)

        # Stat cards
        cards_row = QHBoxLayout()
        cards_row.setSpacing(14)
        stats = [
            ("Students", self._safe_count("students")),
            ("Officers", self._safe_count("officers")),
            ("Open Incidents", self._safe_count("incidents")),
            ("Confiscated Items", self._safe_count("confiscated_items")),
        ]
        for label, value in stats:
            cards_row.addWidget(StatCard(label, value))
        layout.addLayout(cards_row)

        # Recent activity
        activity_label = QLabel("Recent Activity")
        activity_label.setStyleSheet("font-size: 15px; font-weight: 700; color: #10233F; margin-top: 8px;")
        layout.addWidget(activity_label)

        self.activity_list = QListWidget()
        self.activity_list.setStyleSheet(
            "QListWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; padding: 6px; }"
        )
        self._populate_activity()
        layout.addWidget(self.activity_list)

    def _safe_count(self, table):
        try:
            return self.db.count(table, mcat_code=self.current_user.get("mcat_code"))
        except Exception:
            return 0

    def _populate_activity(self):
        try:
            logs = self.db.fetch_all("activity_logs", mcat_code=self.current_user.get("mcat_code"))
            logs = sorted(logs, key=lambda r: r["id"], reverse=True)[:15]
            if not logs:
                self.activity_list.addItem("No activity recorded yet.")
            for log in logs:
                self.activity_list.addItem(f"{log['timestamp']}   —   {log['action']}   {log.get('details') or ''}")
        except Exception:
            self.activity_list.addItem("No activity recorded yet.")
