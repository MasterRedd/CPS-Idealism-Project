from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView,
    QComboBox, QDialog, QFormLayout, QTextEdit, QDialogButtonBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor

from ui.pages.patrol_form_dialog import PatrolFormDialog

# Per spec: Chief Officer "manages patrols", Officer can "patrol" (start/end
# their own) but not edit/delete arbitrary logs, Viewer is read-only.
CAN_MANAGE_ROLES = {"Administrator", "CAT Commander", "Chief Officer"}
CAN_DELETE_ROLES = {"Administrator", "CAT Commander"}

COLUMNS = ["ID", "Officer", "Campus", "Building", "Started", "Ended", "Status", "Remarks"]
STATUS_OPTIONS = ["All", "In Progress", "Completed"]


class _QuickStartDialog(QDialog):
    """Small dialog an officer uses to start their own patrol: pick campus/building."""

    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.setWindowTitle("Start Patrol")
        self.setMinimumWidth(360)
        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.campus_combo = QComboBox()
        self.campus_combo.addItem("— No Campus —", None)
        for c in self.db.get_campuses(mcat_code=self.current_user.get("mcat_code")):
            self.campus_combo.addItem(c["name"], c["id"])
        self.campus_combo.currentIndexChanged.connect(self._reload_buildings)
        form.addRow("Campus", self.campus_combo)

        self.building_combo = QComboBox()
        self._reload_buildings()
        form.addRow("Building", self.building_combo)

        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _reload_buildings(self):
        self.building_combo.clear()
        self.building_combo.addItem("— No Building —", None)
        for b in self.db.get_buildings(campus_id=self.campus_combo.currentData()):
            self.building_combo.addItem(b["name"], b["id"])

    def selected(self):
        return self.campus_combo.currentData(), self.building_combo.currentData()


class _QuickEndDialog(QDialog):
    """Small dialog to capture remarks when an officer ends their patrol."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("End Patrol")
        self.setMinimumWidth(360)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Remarks for this patrol (optional):"))
        self.remarks_input = QTextEdit()
        self.remarks_input.setFixedHeight(80)
        layout.addWidget(self.remarks_input)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def remarks(self):
        return self.remarks_input.toPlainText().strip()


class PatrolPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self.officer_id = current_user.get("officer_id")
        self.can_manage = current_user.get("effective_role", current_user["role"]) in CAN_MANAGE_ROLES
        self.can_delete = current_user.get("effective_role", current_user["role"]) in CAN_DELETE_ROLES

        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        header_row = QHBoxLayout()
        title = QLabel("Patrol Logs")
        title.setObjectName("stubTitle")
        header_row.addWidget(title)
        header_row.addStretch()

        # Quick actions for officers patrolling themselves
        self.start_btn = QPushButton("▶ Start Patrol")
        self.start_btn.setObjectName("primaryButton")
        self.start_btn.clicked.connect(self._on_start_patrol)
        self.start_btn.setVisible(bool(self.officer_id))
        header_row.addWidget(self.start_btn)

        self.end_btn = QPushButton("■ End Patrol")
        self.end_btn.setStyleSheet("color: #d9453d;")
        self.end_btn.clicked.connect(self._on_end_patrol)
        self.end_btn.setVisible(bool(self.officer_id))
        header_row.addWidget(self.end_btn)

        self.add_btn = QPushButton("+ Add Patrol Log")
        self.add_btn.clicked.connect(self._on_add)
        self.add_btn.setVisible(self.can_manage)
        header_row.addWidget(self.add_btn)

        layout.addLayout(header_row)

        self.my_status_label = QLabel("")
        self.my_status_label.setStyleSheet("color: #1e9e5a; font-weight: 600;")
        layout.addWidget(self.my_status_label)

        # Search / filter row
        filter_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by officer, campus, building, or remarks...")
        self.search_input.textChanged.connect(self.refresh)
        filter_row.addWidget(self.search_input, 1)

        self.status_filter = QComboBox()
        self.status_filter.addItems(STATUS_OPTIONS)
        self.status_filter.currentTextChanged.connect(self.refresh)
        filter_row.addWidget(self.status_filter)
        layout.addLayout(filter_row)

        # Table
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnHidden(0, True)
        self.table.horizontalHeader().setSectionResizeMode(7, QHeaderView.Stretch)
        self.table.setStyleSheet(
            "QTableWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; }"
            "QHeaderView::section { background-color: #0A2E5C; color: #ffffff; padding: 7px; border: none; font-weight: 600; }"
        )
        self.table.doubleClicked.connect(self._on_edit)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        action_row.addStretch()
        self.edit_btn = QPushButton("Edit Selected")
        self.edit_btn.clicked.connect(self._on_edit)
        self.edit_btn.setVisible(self.can_manage)
        action_row.addWidget(self.edit_btn)

        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setStyleSheet("color: #d9453d;")
        self.delete_btn.clicked.connect(self._on_delete)
        self.delete_btn.setVisible(self.can_delete)
        action_row.addWidget(self.delete_btn)
        layout.addLayout(action_row)

        self.count_label = QLabel("")
        self.count_label.setStyleSheet("color: #8ea0b3; font-size: 12px;")
        layout.addWidget(self.count_label)

    # ------------------------------------------------------------------
    def refresh(self):
        search = self.search_input.text().strip()
        status_filter = self.status_filter.currentText()
        patrols = self.db.get_patrols(search=search, status_filter=status_filter, mcat_code=self.current_user.get("mcat_code"))

        self.table.setRowCount(0)
        for p in patrols:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                str(p["id"]),
                p.get("officer_name") or "—",
                p.get("campus_name") or "—",
                p.get("building_name") or "—",
                p.get("time_started") or "—",
                p.get("time_ended") or "—",
                p.get("status") or "",
                p.get("remarks") or "",
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 6:
                    item.setForeground(QColor("#1e9e5a") if value == "In Progress" else QColor("#5a6b7d"))
                self.table.setItem(row, col, item)

        self.count_label.setText(f"{len(patrols)} patrol log(s)")
        self._update_my_status()

    def _update_my_status(self):
        if not self.officer_id:
            return
        open_patrol = self.db.get_open_patrol_for_officer(self.officer_id)
        if open_patrol:
            self.my_status_label.setText(
                f"🟢 You are currently on patrol (started {open_patrol['time_started']})"
            )
            self.start_btn.setEnabled(False)
            self.end_btn.setEnabled(True)
        else:
            self.my_status_label.setText("You are not currently on patrol.")
            self.start_btn.setEnabled(True)
            self.end_btn.setEnabled(False)

    # ------------------------------------------------------------------
    def _selected_patrol_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return int(self.table.item(row, 0).text())

    def _on_start_patrol(self):
        dialog = _QuickStartDialog(self.db, parent=self)
        if dialog.exec():
            campus_id, building_id = dialog.selected()
            self.db.start_patrol(self.officer_id, campus_id, building_id,
                                  actor_user_id=self.current_user["id"])
            self.refresh()

    def _on_end_patrol(self):
        open_patrol = self.db.get_open_patrol_for_officer(self.officer_id)
        if not open_patrol:
            QMessageBox.information(self, "No active patrol", "You don't have a patrol in progress.")
            return
        dialog = _QuickEndDialog(parent=self)
        if dialog.exec():
            self.db.end_patrol(open_patrol["id"], dialog.remarks(),
                                actor_user_id=self.current_user["id"])
            self.refresh()

    def _on_add(self):
        dialog = PatrolFormDialog(self.db, parent=self, mcat_code=self.current_user.get("mcat_code"))
        if dialog.exec():
            self.db.create_patrol_manual(dialog.result_data, actor_user_id=self.current_user["id"])
            self.refresh()

    def _on_edit(self):
        if not self.can_manage:
            return
        patrol_id = self._selected_patrol_id()
        if patrol_id is None:
            QMessageBox.information(self, "No selection", "Select a patrol log to edit first.")
            return
        patrol = self.db.get_patrol(patrol_id)
        dialog = PatrolFormDialog(self.db, patrol=patrol, parent=self, mcat_code=self.current_user.get("mcat_code"))
        if dialog.exec():
            self.db.update_patrol(patrol_id, dialog.result_data, actor_user_id=self.current_user["id"])
            self.refresh()

    def _on_delete(self):
        patrol_id = self._selected_patrol_id()
        if patrol_id is None:
            QMessageBox.information(self, "No selection", "Select a patrol log to delete first.")
            return
        confirm = QMessageBox.question(
            self, "Confirm delete",
            "Remove this patrol log from active records?\n\n"
            "This is a soft delete — the record is archived, not permanently erased.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_patrol(patrol_id, actor_user_id=self.current_user["id"])
            self.refresh()
