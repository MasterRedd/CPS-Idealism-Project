from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView
)

from ui.pages.campus_form_dialog import CampusFormDialog

CAN_EDIT_ROLES = {"Administrator", "CAT Commander"}
CAN_DELETE_ROLES = {"Administrator"}

COLUMNS = ["ID", "Campus Name", "Address", "Principal", "Contact Number", "Buildings"]


class CampusesPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self.can_edit = current_user.get("effective_role", current_user["role"]) in CAN_EDIT_ROLES
        self.can_delete = current_user.get("effective_role", current_user["role"]) in CAN_DELETE_ROLES

        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        header_row = QHBoxLayout()
        title = QLabel("Campuses")
        title.setObjectName("stubTitle")
        header_row.addWidget(title)
        header_row.addStretch()

        self.add_btn = QPushButton("+ Add Campus")
        self.add_btn.setObjectName("primaryButton")
        self.add_btn.clicked.connect(self._on_add)
        self.add_btn.setVisible(self.can_edit)
        header_row.addWidget(self.add_btn)
        layout.addLayout(header_row)

        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by campus name...")
        self.search_input.textChanged.connect(self.refresh)
        search_row.addWidget(self.search_input)
        layout.addLayout(search_row)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnHidden(0, True)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setStyleSheet(
            "QTableWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; }"
            "QHeaderView::section { background-color: #0A2E5C; color: #ffffff; padding: 7px; border: none; font-weight: 600; }"
        )
        self.table.doubleClicked.connect(self._on_edit)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        action_row.addStretch()

        self.edit_btn = QPushButton("Edit Selected")
        self.edit_btn.clicked.connect(self._on_edit)
        self.edit_btn.setVisible(self.can_edit)
        action_row.addWidget(self.edit_btn)

        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setStyleSheet("color: #d9453d;")
        self.delete_btn.clicked.connect(self._on_delete)
        self.delete_btn.setVisible(self.can_delete)
        action_row.addWidget(self.delete_btn)

        layout.addLayout(action_row)

        self.count_label = QLabel("")
        self.count_label.setStyleSheet("color: #8ea0b3; font-size: 12px;")
        layout.addWidget(self.count_label)

    # ------------------------------------------------------------------
    def refresh(self):
        search = self.search_input.text().strip().lower()
        campuses = self.db.get_campuses(mcat_code=self.current_user.get("mcat_code"))
        if search:
            campuses = [c for c in campuses if search in (c.get("name") or "").lower()]

        buildings = self.db.get_buildings_full(mcat_code=self.current_user.get("mcat_code"))
        building_counts = {}
        for b in buildings:
            building_counts[b["campus_id"]] = building_counts.get(b["campus_id"], 0) + 1

        self.table.setRowCount(0)
        for campus in campuses:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                str(campus["id"]),
                campus.get("name") or "",
                campus.get("address") or "—",
                campus.get("principal") or "—",
                campus.get("contact_number") or "—",
                str(building_counts.get(campus["id"], 0)),
            ]
            for col, value in enumerate(values):
                self.table.setItem(row, col, QTableWidgetItem(value))

        self.count_label.setText(f"{len(campuses)} campus(es)")

    # ------------------------------------------------------------------
    def _selected_campus_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return int(self.table.item(row, 0).text())

    def _on_add(self):
        dialog = CampusFormDialog(parent=self)
        if dialog.exec():
            data = dialog.result_data
            self.db.create_campus(
                data["name"], data["address"], data["principal"], data["contact_number"],
                actor_user_id=self.current_user["id"],
            )
            self.refresh()

    def _on_edit(self):
        campus_id = self._selected_campus_id()
        if campus_id is None:
            QMessageBox.information(self, "No selection", "Select a campus to edit first.")
            return
        campus = self.db.get_campus(campus_id)
        dialog = CampusFormDialog(campus=campus, parent=self)
        if dialog.exec():
            data = dialog.result_data
            self.db.update_campus(
                campus_id, data["name"], data["address"], data["principal"], data["contact_number"],
                actor_user_id=self.current_user["id"],
            )
            self.refresh()

    def _on_delete(self):
        campus_id = self._selected_campus_id()
        if campus_id is None:
            QMessageBox.information(self, "No selection", "Select a campus to delete first.")
            return
        campus = self.db.get_campus(campus_id)
        if self.db.campus_in_use(campus_id):
            QMessageBox.warning(
                self, "Campus in use",
                f"{campus['name']} still has students, officers, or buildings assigned to it. "
                "Reassign or remove those first.",
            )
            return
        confirm = QMessageBox.question(
            self, "Confirm delete",
            f"Remove {campus['name']}? This is a soft delete — records referencing it are kept.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_campus(campus_id, actor_user_id=self.current_user["id"])
            self.refresh()
