"""
Chat — Global (everyone under your Management Code) and Personal
(direct, one-to-one) messaging.

This talks to Supabase, not the local SQLite file, because two different
devices need to see the same conversation. When there's no internet, a
message you send is queued in a local outbox instead of failing outright,
and gets delivered automatically the next time this page notices it's
back online — you can also cancel a queued message before it goes out.

Honest scope note: delivery/refresh is done by polling every few seconds,
not a live push socket, and video attachments open in your system's
default player rather than an in-app video player. Both are reasonable
v1 trade-offs, not accidental gaps.
"""
import os
import time
import uuid
from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QLineEdit,
    QListWidget, QListWidgetItem, QScrollArea, QFrame, QSizePolicy,
    QFileDialog, QMessageBox, QMenu, QDialog, QInputDialog, QCheckBox
)
from PySide6.QtCore import Qt, QTimer, QUrl, QSize, Signal
from PySide6.QtGui import QPixmap, QDesktopServices, QPainter, QPainterPath, QCursor

from online.supabase_client import get_online
from online import media_compress
from ui.pages.image_viewer_dialog import ImageViewerDialog

GLOBAL_KEY = "__global__"
EDIT_WINDOW_SECONDS = 180
REACTION_CHOICES = ["👍", "❤️", "😂", "😮", "😢", "🙏"]


def _circular_pixmap(path: str, size: int = 36) -> QPixmap | None:
    """Loads an image file and masks it into a circle, for avatars."""
    src = QPixmap(path)
    if src.isNull():
        return None
    src = src.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    out = QPixmap(size, size)
    out.fill(Qt.transparent)
    painter = QPainter(out)
    painter.setRenderHint(QPainter.Antialiasing)
    path_shape = QPainterPath()
    path_shape.addEllipse(0, 0, size, size)
    painter.setClipPath(path_shape)
    x = (size - src.width()) // 2
    y = (size - src.height()) // 2
    painter.drawPixmap(x, y, src)
    painter.end()
    return out


def _initial_avatar(name: str, size: int = 36) -> QPixmap:
    """Fallback avatar — a colored circle with the person's first
    initial, used until (or unless) a real profile photo is available."""
    letter = (name or "?").strip()[:1].upper() or "?"
    palette = ["#1657A8", "#B2872F", "#4C9A5A", "#B23B3B", "#6B4C9A", "#2F7FD6"]
    color = palette[abs(hash(name)) % len(palette)]
    out = QPixmap(size, size)
    out.fill(Qt.transparent)
    painter = QPainter(out)
    painter.setRenderHint(QPainter.Antialiasing)
    painter.setBrush(Qt.NoBrush)
    from PySide6.QtGui import QColor, QBrush, QFont
    painter.setBrush(QBrush(QColor(color)))
    painter.setPen(Qt.NoPen)
    painter.drawEllipse(0, 0, size, size)
    painter.setPen(Qt.white)
    font = QFont()
    font.setBold(True)
    font.setPointSize(int(size * 0.42))
    painter.setFont(font)
    painter.drawText(out.rect(), Qt.AlignCenter, letter)
    painter.end()
    return out


class ChatPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.user = current_user
        self.mcat = current_user.get("mcat_code")
        self.self_id = current_user.get("id")
        self.self_name = current_user.get("full_name", "Me")
        self.self_photo_path = current_user.get("photo_path")

        self.scope = "global"
        self.recipient_id = None
        self.recipient_name = None
        self._presence = {}          # user_id -> presence row (from Supabase)
        self._last_typing_sent = 0   # throttle so we don't upsert every keystroke
        self._last_send_error = None
        self._avatar_cache = {}      # user_id -> local file path, or False if none
        self._avatar_pixmap_cache = {}  # user_id -> QPixmap
        self._bubble_index = {}      # client_msg_id -> bubble QWidget (current thread only)
        self._reply_target = None    # {"client_msg_id", "sender_name", "preview"}
        self._avatar_uploaded_this_session = False
        self._pinned_count = 0

        self._build_ui()

        if self.mcat:
            self._load_contacts()
            self._open_thread("global", None, None)
            self.timer = QTimer(self)
            self.timer.timeout.connect(self._sync_tick)
            self.timer.start(4000)
            QTimer.singleShot(300, self._sync_tick)
            QTimer.singleShot(800, self._maybe_upload_own_avatar)
            online = get_online()
            online.set_presence(self.mcat, self.self_id, self.self_name, online=True)
            online.ensure_mcat_registered(self.mcat, current_user.get("full_name", ""))

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        if not self.mcat:
            msg = QLabel(
                "Chat is only available for accounts under a Management Code "
                "(MCAT). The Creator view doesn't have a chat."
            )
            msg.setWordWrap(True)
            msg.setStyleSheet("padding: 28px; font-size: 14px; color: #5a6b7d;")
            layout.addWidget(msg)
            return

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)

        # ---- Left: contact list -----------------------------------
        left = QWidget()
        left.setFixedWidth(250)
        left.setStyleSheet("background-color: #F4F7FB; border-right: 1px solid #dfe6ee;")
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(10, 14, 10, 14)

        header = QLabel("Chat")
        header.setStyleSheet("font-size: 17px; font-weight: 700; color: #10233F; padding: 0 6px 8px 6px;")
        left_layout.addWidget(header)

        self.contact_list = QListWidget()
        self.contact_list.setStyleSheet(
            "QListWidget { border: none; background: transparent; font-size: 13px; }"
            "QListWidget::item { padding: 10px 8px; border-radius: 8px; margin-bottom: 2px; }"
            "QListWidget::item:selected { background-color: #10233F; color: white; }"
        )
        self.contact_list.itemClicked.connect(self._on_contact_clicked)
        left_layout.addWidget(self.contact_list, 1)

        body.addWidget(left)

        # ---- Right: thread ------------------------------------------
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        thread_header = QWidget()
        thread_header.setFixedHeight(54)
        thread_header.setStyleSheet("background-color: white; border-bottom: 1px solid #dfe6ee;")
        th_layout = QHBoxLayout(thread_header)
        th_layout.setContentsMargins(18, 0, 18, 0)
        self.thread_title = QLabel("🌐 Global Chat")
        self.thread_title.setStyleSheet("font-size: 15px; font-weight: 700; color: #10233F;")
        th_layout.addWidget(self.thread_title)
        th_layout.addStretch()

        self.pin_btn = QPushButton("📌 Pinned")
        self.pin_btn.setVisible(False)
        self.pin_btn.setCursor(Qt.PointingHandCursor)
        self.pin_btn.setStyleSheet(
            "QPushButton { background-color: rgba(178,135,47,0.15); color: #8a6a1f; "
            "border: none; border-radius: 12px; padding: 5px 12px; font-size: 11px; font-weight: 700; }"
            "QPushButton:hover { background-color: rgba(178,135,47,0.28); }"
        )
        self.pin_btn.clicked.connect(self._open_pinned_dialog)
        th_layout.addWidget(self.pin_btn)

        self.presence_lbl = QLabel("")
        self.presence_lbl.setStyleSheet("font-size: 11px; color: #4c9a5a; margin: 0 10px;")
        th_layout.addWidget(self.presence_lbl)
        self.status_pill = QLabel("⚪ Checking…")
        self.status_pill.setStyleSheet("font-size: 12px; color: #8ea0b3;")
        th_layout.addWidget(self.status_pill)
        right_layout.addWidget(thread_header)

        self.typing_lbl = QLabel("")
        self.typing_lbl.setStyleSheet("font-size: 11px; color: #8ea0b3; padding: 4px 18px 0 18px; font-style: italic;")
        right_layout.addWidget(self.typing_lbl)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("QScrollArea { border: none; background-color: #EAF0F7; }")
        self.thread_container = QWidget()
        self.thread_container.setStyleSheet("background-color: #EAF0F7;")
        self.thread_layout = QVBoxLayout(self.thread_container)
        self.thread_layout.setContentsMargins(16, 16, 16, 16)
        self.thread_layout.setSpacing(8)
        self.thread_layout.addStretch()
        self.scroll.setWidget(self.thread_container)
        right_layout.addWidget(self.scroll, 1)

        # ---- Reply preview strip (hidden unless replying) -----------
        self.reply_strip = QWidget()
        self.reply_strip.setVisible(False)
        self.reply_strip.setStyleSheet("background-color: #F4F7FB; border-top: 1px solid #dfe6ee;")
        rs_layout = QHBoxLayout(self.reply_strip)
        rs_layout.setContentsMargins(16, 6, 16, 6)
        self.reply_strip_lbl = QLabel("")
        self.reply_strip_lbl.setStyleSheet("font-size: 12px; color: #10233F;")
        rs_layout.addWidget(self.reply_strip_lbl, 1)
        cancel_reply_btn = QPushButton("✕")
        cancel_reply_btn.setFixedWidth(26)
        cancel_reply_btn.setStyleSheet("QPushButton { background: none; border: none; color: #B23B3B; font-weight: 700; }")
        cancel_reply_btn.setCursor(Qt.PointingHandCursor)
        cancel_reply_btn.clicked.connect(self._cancel_reply)
        rs_layout.addWidget(cancel_reply_btn)
        right_layout.addWidget(self.reply_strip)

        input_row = QWidget()
        input_row.setStyleSheet("background-color: white; border-top: 1px solid #dfe6ee;")
        ir_layout = QHBoxLayout(input_row)
        ir_layout.setContentsMargins(14, 10, 14, 10)

        self.input_box = QLineEdit()
        self.input_box.setPlaceholderText("Type a message…")
        self.input_box.returnPressed.connect(self._send_text)
        self.input_box.textChanged.connect(self._on_typing_changed)
        ir_layout.addWidget(self.input_box, 1)

        send_btn = QPushButton("Send")
        send_btn.setObjectName("primaryButton")
        send_btn.clicked.connect(self._send_text)
        ir_layout.addWidget(send_btn)

        right_layout.addWidget(input_row)
        body.addWidget(right, 1)

        layout.addLayout(body, 1)

    # ------------------------------------------------------------------
    def shutdown(self):
        """Stops the background sync timer. Must be called before this page
        (and the window it lives in) goes away — a running QTimer keeps
        firing on a background clock regardless of whether its widget is
        visible, or even hidden after logout, so without this every
        login/logout cycle in a single app session left one more timer
        quietly polling and rebuilding the message list forever, which is
        exactly why the app got laggier the more it was used and only a
        full restart ever fully cleared it."""
        try:
            if hasattr(self, "timer"):
                self.timer.stop()
        except Exception:
            pass

    def _load_contacts(self):
        # Remember what was selected before clearing, so a periodic
        # presence refresh (every 4s) doesn't keep bouncing an open
        # Personal thread back to Global Chat.
        prev_key = GLOBAL_KEY if self.scope == "global" else str(self.recipient_id)

        self.contact_list.clear()
        global_item = QListWidgetItem("🌐  Global Chat")
        global_item.setData(Qt.UserRole, (GLOBAL_KEY, None))
        self.contact_list.addItem(global_item)
        selected_item = global_item

        contacts = self.db.list_chat_contacts(self.mcat, exclude_user_id=self.self_id)
        for c in contacts:
            tag = "⭐" if c["account_type"] == "administrator" else "👮"
            dot = "🟢" if self._is_recently_online(str(c["user_id"])) else ""
            item = QListWidgetItem(f"{tag}  {c['full_name']}  {dot}")
            item.setData(Qt.UserRole, (str(c["user_id"]), c["full_name"]))
            self.contact_list.addItem(item)
            if str(c["user_id"]) == prev_key:
                selected_item = item

        self.contact_list.setCurrentItem(selected_item)

    def _is_recently_online(self, user_id: str) -> bool:
        row = self._presence.get(user_id)
        if not row or not row.get("last_seen_at"):
            return False
        try:
            from datetime import datetime, timezone
            seen = datetime.fromisoformat(str(row["last_seen_at"]).replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - seen).total_seconds()
            return age < 30
        except Exception:
            return False

    def _on_contact_clicked(self, item):
        key, name = item.data(Qt.UserRole)
        if key == GLOBAL_KEY:
            self._open_thread("global", None, None)
        else:
            self._open_thread("personal", key, name)

    def _open_thread(self, scope, recipient_id, recipient_name):
        self.scope = scope
        self.recipient_id = recipient_id
        self.recipient_name = recipient_name
        self.thread_title.setText(
            "🌐 Global Chat" if scope == "global" else f"💬 {recipient_name}"
        )
        self.typing_lbl.setText("")
        self._cancel_reply()
        self._update_presence_label()
        self._last_render_fingerprint = None
        self._render_thread()
        self._refresh_pinned_button()

    def _update_presence_label(self):
        if self.scope == "global" or not self.recipient_id:
            self.presence_lbl.setText("")
            return
        self.presence_lbl.setText(
            "🟢 Active now" if self._is_recently_online(str(self.recipient_id)) else ""
        )

    # ------------------------------------------------------------------
    def _sync_tick(self):
        if not self.mcat:
            return
        online = get_online()
        self._flush_outbox(online)  # keep sending queued messages even off-screen
        if not self.isVisible():
            # The user is on a different page (Dashboard, Students, etc.) —
            # skip the message-list fetch/rebuild below. This used to run
            # unconditionally every 4 seconds, fully rebuilding every
            # message bubble even while Chat wasn't on screen — the main
            # cause of the app feeling sluggish during and after using Chat.
            return
        connected = online.is_available()
        if connected and self._last_send_error:
            self.status_pill.setText("🔴 Send failing — hover for why")
            self.status_pill.setToolTip(str(self._last_send_error))
        elif connected:
            self.status_pill.setText("🟢 Online")
            self.status_pill.setToolTip("")
        else:
            self.status_pill.setText("⚪ Offline — messages will queue")
            self.status_pill.setToolTip(str(online.last_error or ""))
        if connected:
            online.set_presence(self.mcat, self.self_id, self.self_name, online=True)
            self._presence = online.fetch_presence(self.mcat)
            self._load_contacts()
            self._update_presence_label()
            typers = online.fetch_typing(
                self.mcat, self.scope, recipient_id=self.recipient_id, exclude_id=self.self_id
            )
            if typers:
                who = typers[0] if self.scope == "personal" else ", ".join(typers)
                self.typing_lbl.setText(f"{who} {'is' if len(typers) == 1 else 'are'} typing…")
            else:
                self.typing_lbl.setText("")
        self._render_thread()
        self._refresh_pinned_button()

    def _on_typing_changed(self, text):
        if not self.mcat or not text.strip():
            return
        now = time.time()
        if now - self._last_typing_sent < 2:
            return
        self._last_typing_sent = now
        online = get_online()
        if online.is_available():
            online.set_typing(
                self.mcat, self.scope, self.self_id, self.self_name,
                recipient_id=self.recipient_id,
            )

    def _flush_outbox(self, online):
        for row in self.db.get_all_outbox():
            attachment_url = row.get("attachment_url")
            attachment_kb = row.get("attachment_kb")
            if not attachment_url and row["attachment_local_path"]:
                if not os.path.exists(row["attachment_local_path"]):
                    self.db.delete_outbox_message(row["id"])  # file vanished, drop it
                    continue
                dest_name = f"{row['client_msg_id']}{Path(row['attachment_local_path']).suffix}"
                attachment_url = online.upload_attachment(
                    row["mcat_code"], row["attachment_local_path"], dest_name
                )
                if not attachment_url:
                    self._last_send_error = online.last_error
                    continue  # still no connection; try again next tick
                attachment_kb = os.path.getsize(row["attachment_local_path"]) // 1024
            ok = online.send_message(
                mcat_code=row["mcat_code"], scope=row["scope"],
                sender_id=row["sender_id"], sender_name=row["sender_name"],
                client_msg_id=row["client_msg_id"], body=row["body"],
                recipient_id=row["recipient_id"], attachment_url=attachment_url,
                attachment_type=row["attachment_type"], attachment_kb=attachment_kb,
                reply_to_client_id=row.get("reply_to_client_id"),
                reply_preview=row.get("reply_preview"),
                reply_sender_name=row.get("reply_sender_name"),
                is_forwarded=bool(row.get("is_forwarded")),
            )
            if ok:
                self.db.delete_outbox_message(row["id"])
                self._last_send_error = None
            else:
                self._last_send_error = online.last_error

    # ------------------------------------------------------------------
    # Avatars
    # ------------------------------------------------------------------
    def _maybe_upload_own_avatar(self):
        """Uploads this account's profile photo to Storage once per app
        session, so other devices (which don't have the original file on
        disk) can display it. Skipped entirely if there's no photo set."""
        if self._avatar_uploaded_this_session or not self.self_photo_path:
            return
        if not os.path.exists(self.self_photo_path):
            return
        online = get_online()
        if not online.is_available():
            return
        self._avatar_uploaded_this_session = True
        compressed_path, kind, _kb = media_compress.prepare_attachment(self.self_photo_path)
        if kind != "image" or not compressed_path:
            return
        url = online.upload_avatar(self.mcat, compressed_path, self.self_id)
        if url:
            online.set_presence(self.mcat, self.self_id, self.self_name, online=True, avatar_url=url)

    def _avatar_pixmap_for(self, user_id, display_name) -> QPixmap:
        user_id = str(user_id)
        if user_id in self._avatar_pixmap_cache:
            return self._avatar_pixmap_cache[user_id]

        local_path = self._avatar_cache.get(user_id)
        if local_path is None:
            row = self._presence.get(user_id)
            url = row.get("avatar_url") if row else None
            if url:
                cache_path = media_compress.cache_path_for(url)
                if not cache_path.exists():
                    online = get_online()
                    online.download_attachment(url, cache_path)  # small file; ok inline
                local_path = str(cache_path) if cache_path.exists() else False
            else:
                local_path = False
            self._avatar_cache[user_id] = local_path

        pix = _circular_pixmap(local_path) if local_path else None
        if pix is None:
            pix = _initial_avatar(display_name)
        self._avatar_pixmap_cache[user_id] = pix
        return pix

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    def _render_thread(self):
        online = get_online()
        remote = []
        if online.is_available():
            remote = online.fetch_messages(
                self.mcat, self.scope, recipient_id=self.recipient_id,
                self_id=self.self_id, after_id=0, limit=300,
            )
        pending = self.db.get_outbox_for_thread(
            self.mcat, self.scope, self.recipient_id, sender_id=self.self_id
        )
        pending_client_ids = {p["client_msg_id"] for p in pending}
        remote = [m for m in remote if m.get("client_msg_id") not in pending_client_ids]

        combined = [("remote", m) for m in remote] + [("pending", p) for p in pending]
        combined.sort(key=lambda pair: pair[1].get("created_at") or "")

        # Cheap fingerprint of everything that could visibly change (content,
        # edits, deletes, pins, reactions, send status) — if it's identical
        # to what's already on screen, skip the expensive rebuild entirely.
        # Rebuilding every bubble from scratch every 4 seconds regardless of
        # whether anything changed was the main cause of Chat feeling
        # laggy while actively in use.
        fingerprint = tuple(
            (
                item.get("client_msg_id"), item.get("body"), item.get("is_deleted"),
                item.get("edited_at"), item.get("is_pinned"), item.get("reactions_summary"),
                kind,
            )
            for kind, item in combined
        )
        if fingerprint == getattr(self, "_last_render_fingerprint", None):
            return
        self._last_render_fingerprint = fingerprint

        while self.thread_layout.count() > 1:
            child = self.thread_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        self._bubble_index = {}

        pinned_count = 0
        for kind, item in combined:
            if kind == "remote" and item.get("is_pinned"):
                pinned_count += 1
            wrap = self._build_bubble(kind, item)
            self.thread_layout.insertWidget(self.thread_layout.count() - 1, wrap)
            cid = item.get("client_msg_id")
            if cid:
                self._bubble_index[cid] = wrap
        self._pinned_count = pinned_count
        self.pin_btn.setVisible(pinned_count > 0)
        self.pin_btn.setText(f"📌 Pinned ({pinned_count})")

        QTimer.singleShot(30, lambda: self.scroll.verticalScrollBar().setValue(
            self.scroll.verticalScrollBar().maximum()))

    def _refresh_pinned_button(self):
        online = get_online()
        if not online.is_available():
            return
        pinned = online.fetch_pinned(self.mcat, self.scope, recipient_id=self.recipient_id, self_id=self.self_id)
        self.pin_btn.setVisible(len(pinned) > 0)
        self.pin_btn.setText(f"📌 Pinned ({len(pinned)})")

    def _build_bubble(self, kind, item):
        is_mine = str(item.get("sender_id")) == str(self.self_id)
        is_deleted = bool(item.get("is_deleted"))

        wrap = QWidget()
        wrap_layout = QHBoxLayout(wrap)
        wrap_layout.setContentsMargins(0, 0, 0, 0)
        wrap_layout.setSpacing(8)

        # Avatar — shown next to messages from OTHER people (this is the
        # "who sent this" cue requested for Global Chat especially).
        if not is_mine and kind == "remote":
            avatar_lbl = QLabel()
            avatar_lbl.setFixedSize(36, 36)
            avatar_lbl.setPixmap(self._avatar_pixmap_for(item.get("sender_id"), item.get("sender_name", "?")))
            wrap_layout.addWidget(avatar_lbl, 0, Qt.AlignTop)

        bubble = QFrame()
        bubble.setMaximumWidth(400)
        bg = "#F4C542" if is_mine else "white"
        fg = "#10233F"
        bubble.setStyleSheet(
            f"QFrame {{ background-color: {bg}; border-radius: 12px; }}"
        )
        b_layout = QVBoxLayout(bubble)
        b_layout.setContentsMargins(12, 8, 12, 8)
        b_layout.setSpacing(4)

        top_row = QHBoxLayout()
        top_row.setSpacing(6)
        if self.scope == "global" and not is_mine:
            name_lbl = QLabel(item.get("sender_name", ""))
            name_lbl.setStyleSheet("font-size: 11px; font-weight: 700; color: #1657A8;")
            top_row.addWidget(name_lbl)
        if item.get("is_pinned"):
            pin_tag = QLabel("📌")
            pin_tag.setToolTip("Pinned")
            top_row.addWidget(pin_tag)
        top_row.addStretch()
        if kind == "remote" and not is_deleted:
            more_btn = QPushButton("⋯")
            more_btn.setFixedSize(26, 24)
            more_btn.setCursor(Qt.PointingHandCursor)
            more_btn.setToolTip("Reply, pin, react, forward, edit, or delete")
            # Always-visible pill (not just on hover) with real contrast on
            # both the gold "mine" bubbles and the white "theirs" bubbles —
            # the previous pale-gray-on-transparent version was very hard
            # to see, especially on the gold background.
            more_btn.setStyleSheet(
                "QPushButton {"
                "  background-color: rgba(16,35,63,0.14);"
                "  border: none; border-radius: 12px;"
                "  color: #10233F; font-weight: 800; font-size: 14px;"
                "}"
                "QPushButton:hover { background-color: rgba(16,35,63,0.30); }"
                "QPushButton:pressed { background-color: rgba(16,35,63,0.45); }"
            )
            more_btn.clicked.connect(lambda _, it=item, mine=is_mine: self._open_message_menu(it, mine, more_btn))
            top_row.addWidget(more_btn)
        b_layout.addLayout(top_row)

        if is_deleted:
            del_lbl = QLabel("🚫 This message was deleted")
            del_lbl.setStyleSheet("font-size: 12px; color: #8ea0b3; font-style: italic;")
            b_layout.addWidget(del_lbl)
            return self._finish_bubble(wrap, wrap_layout, bubble, is_mine)

        if item.get("is_forwarded"):
            fwd_lbl = QLabel("↪ Forwarded message")
            fwd_lbl.setStyleSheet("font-size: 10px; color: #8ea0b3; font-style: italic;")
            b_layout.addWidget(fwd_lbl)

        if item.get("reply_to_client_id"):
            quote = QPushButton(
                f"↩ {item.get('reply_sender_name', 'Message')}: "
                f"{(item.get('reply_preview') or '').strip()[:60]}"
            )
            quote.setCursor(Qt.PointingHandCursor)
            quote.setStyleSheet(
                "QPushButton { background-color: rgba(16,35,63,0.08); border: none; border-left: 3px solid #1657A8; "
                "border-radius: 4px; padding: 5px 8px; text-align: left; font-size: 11px; color: #445; }"
                "QPushButton:hover { background-color: rgba(16,35,63,0.15); }"
            )
            quote.clicked.connect(lambda _, cid=item.get("reply_to_client_id"): self._jump_to(cid))
            b_layout.addWidget(quote)

        if item.get("body"):
            text_lbl = QLabel(item["body"])
            text_lbl.setWordWrap(True)
            text_lbl.setStyleSheet(f"color: {fg}; font-size: 13px;")
            b_layout.addWidget(text_lbl)

        attachment_type = item.get("attachment_type")
        if attachment_type in ("image", "video"):
            local_path = item.get("attachment_local_path")
            url = item.get("attachment_url")
            att_btn = QPushButton(
                ("🖼️ Photo — tap to view" if attachment_type == "image"
                 else "🎬 Video — tap to open")
            )
            att_btn.setCursor(Qt.PointingHandCursor)
            att_btn.setStyleSheet(
                "QPushButton { background-color: rgba(16,35,63,0.08); border: none; "
                "border-radius: 8px; padding: 8px; text-align: left; font-size: 12px; }"
                "QPushButton:hover { background-color: rgba(16,35,63,0.16); }"
            )
            att_btn.clicked.connect(lambda: self._open_attachment(attachment_type, local_path, url))
            b_layout.addWidget(att_btn)

        reactions = item.get("reactions") or {}
        if reactions:
            react_row = QHBoxLayout()
            react_row.setSpacing(4)
            for emoji, users in reactions.items():
                if not users:
                    continue
                chip = QPushButton(f"{emoji} {len(users)}")
                chip.setCursor(Qt.PointingHandCursor)
                mine_reacted = str(self.self_id) in [str(u) for u in users]
                chip_bg = "rgba(22,87,168,0.18)" if mine_reacted else "rgba(16,35,63,0.06)"
                chip.setStyleSheet(
                    f"QPushButton {{ background-color: {chip_bg}; border: none; border-radius: 10px; "
                    "padding: 2px 8px; font-size: 11px; }"
                )
                chip.clicked.connect(lambda _, cid=item.get("client_msg_id"), e=emoji: self._react(cid, e))
                react_row.addWidget(chip)
            react_row.addStretch()
            b_layout.addLayout(react_row)

        footer_text = ""
        if kind == "pending":
            footer_text = "⏳ Waiting for internet…"
        else:
            if item.get("created_at"):
                footer_text = str(item["created_at"])[11:16]
            if item.get("edited_at"):
                footer_text += "  · edited"
        if footer_text:
            foot = QLabel(footer_text)
            foot.setStyleSheet("font-size: 10px; color: #8ea0b3;")
            b_layout.addWidget(foot)

        if kind == "pending":
            cancel_btn = QPushButton("✕ Cancel send")
            cancel_btn.setStyleSheet(
                "QPushButton { background: none; border: none; color: #B23B3B; "
                "font-size: 11px; text-align: left; padding: 0; }"
            )
            cancel_btn.setCursor(Qt.PointingHandCursor)
            cancel_btn.clicked.connect(lambda: self._cancel_pending(item["id"]))
            b_layout.addWidget(cancel_btn)

        return self._finish_bubble(wrap, wrap_layout, bubble, is_mine)

    def _finish_bubble(self, wrap, wrap_layout, bubble, is_mine):
        if is_mine:
            wrap_layout.addStretch()
            wrap_layout.addWidget(bubble)
        else:
            wrap_layout.addWidget(bubble)
            wrap_layout.addStretch()
        return wrap

    def _jump_to(self, client_msg_id):
        target = self._bubble_index.get(client_msg_id)
        if not target:
            QMessageBox.information(self, "Not visible here",
                                     "That message isn't in the currently loaded part of this thread.")
            return
        self.scroll.ensureWidgetVisible(target, 50, 80)
        original_style = target.styleSheet()
        target.setStyleSheet("background-color: rgba(244, 197, 66, 0.35); border-radius: 12px;")
        QTimer.singleShot(1200, lambda: target.setStyleSheet(original_style))

    def _cancel_pending(self, outbox_id):
        self.db.delete_outbox_message(outbox_id)
        self._render_thread()

    # ------------------------------------------------------------------
    # Message actions: reply / edit / delete / pin / react / forward
    # ------------------------------------------------------------------
    def _open_message_menu(self, item, is_mine, anchor_btn):
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background-color: white; color: #10233F; border: 1px solid #dfe6ee; "
            "border-radius: 8px; padding: 4px; font-size: 13px; }"
            "QMenu::item { padding: 7px 20px; border-radius: 5px; }"
            "QMenu::item:selected { background-color: #0A2E5C; color: white; }"
            "QMenu::separator { height: 1px; background: #e6ecf2; margin: 4px 8px; }"
        )
        menu.addAction("↩ Reply", lambda: self._start_reply(item))
        menu.addAction("↪ Forward", lambda: self._open_forward_dialog(item))

        react_menu = menu.addMenu("😊 React")
        react_menu.setStyleSheet(menu.styleSheet())
        for emoji in REACTION_CHOICES:
            react_menu.addAction(emoji, lambda e=emoji: self._react(item.get("client_msg_id"), e))

        is_pinned = bool(item.get("is_pinned"))
        menu.addAction("📌 Unpin" if is_pinned else "📌 Pin",
                        lambda: self._toggle_pin(item.get("client_msg_id"), not is_pinned))

        if is_mine:
            created = item.get("created_at")
            within_window = self._within_edit_window(created)
            if within_window and item.get("body") is not None:
                menu.addAction("✏️ Edit", lambda: self._start_edit(item))
            menu.addAction("🗑 Delete", lambda: self._delete_message(item))

        menu.exec(anchor_btn.mapToGlobal(anchor_btn.rect().bottomRight()))

    @staticmethod
    def _within_edit_window(created_at_str) -> bool:
        if not created_at_str:
            return False
        try:
            from datetime import datetime, timezone
            created = datetime.fromisoformat(str(created_at_str).replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - created).total_seconds()
            return age <= EDIT_WINDOW_SECONDS
        except Exception:
            return False

    def _start_reply(self, item):
        preview = item.get("body") or (
            "📷 Photo" if item.get("attachment_type") == "image"
            else "🎬 Video" if item.get("attachment_type") == "video" else "message"
        )
        self._reply_target = {
            "client_msg_id": item.get("client_msg_id"),
            "sender_name": item.get("sender_name", "them"),
            "preview": preview,
        }
        self.reply_strip_lbl.setText(f"Replying to {self._reply_target['sender_name']}: {preview[:70]}")
        self.reply_strip.setVisible(True)
        self.input_box.setFocus()

    def _cancel_reply(self):
        self._reply_target = None
        self.reply_strip.setVisible(False)

    def _start_edit(self, item):
        new_text, ok = QInputDialog.getText(
            self, "Edit message", "Update your message (editable for 3 minutes after sending):",
            text=item.get("body") or "",
        )
        if not ok or not new_text.strip():
            return
        if not self._within_edit_window(item.get("created_at")):
            QMessageBox.information(self, "Too late to edit",
                                     "The 3-minute edit window for this message has passed.")
            return
        online = get_online()
        if online.edit_message(self.mcat, item.get("client_msg_id"), new_text.strip()):
            self._render_thread()
        else:
            QMessageBox.warning(self, "Couldn't edit", str(online.last_error or "No connection."))

    def _delete_message(self, item):
        if QMessageBox.question(self, "Delete message", "Delete this message for everyone?") != QMessageBox.Yes:
            return
        online = get_online()
        if online.delete_message(item.get("client_msg_id")):
            self._render_thread()
        else:
            QMessageBox.warning(self, "Couldn't delete", str(online.last_error or "No connection."))

    def _toggle_pin(self, client_msg_id, pinned):
        online = get_online()
        if online.set_pinned(client_msg_id, pinned):
            self._render_thread()
            self._refresh_pinned_button()
        else:
            QMessageBox.warning(self, "Couldn't update pin", str(online.last_error or "No connection."))

    def _react(self, client_msg_id, emoji):
        online = get_online()
        if not online.is_available():
            QMessageBox.information(self, "Offline", "Reactions need an internet connection.")
            return
        result = online.toggle_reaction(client_msg_id, emoji, self.self_id)
        if result is None:
            QMessageBox.warning(self, "Couldn't react", str(online.last_error or ""))
        else:
            self._render_thread()

    def _open_pinned_dialog(self):
        online = get_online()
        pinned = online.fetch_pinned(self.mcat, self.scope, recipient_id=self.recipient_id, self_id=self.self_id) \
            if online.is_available() else []
        dlg = PinnedMessagesDialog(pinned, parent=self)
        dlg.view_requested.connect(self._jump_to)
        dlg.exec()

    def _open_forward_dialog(self, item):
        contacts = self.db.list_chat_contacts(self.mcat, exclude_user_id=self.self_id)
        dlg = ForwardDialog(contacts, parent=self)
        if dlg.exec() != QDialog.Accepted:
            return
        targets = dlg.selected_targets()  # list of ("global", None, None) or ("personal", id, name)
        if not targets:
            return
        body = item.get("body")
        attachment_url = item.get("attachment_url")
        attachment_local_path = item.get("attachment_local_path")
        attachment_type = item.get("attachment_type")
        attachment_kb = item.get("attachment_kb")
        for scope, rid, _name in targets:
            client_msg_id = str(uuid.uuid4())
            self.db.queue_chat_outbox(
                client_msg_id=client_msg_id, mcat_code=self.mcat, scope=scope,
                sender_id=self.self_id, sender_name=self.self_name, body=body,
                recipient_id=rid, attachment_local_path=attachment_local_path,
                attachment_type=attachment_type, attachment_url=attachment_url,
                attachment_kb=attachment_kb, is_forwarded=True,
            )
        self._render_thread()
        QTimer.singleShot(50, lambda: self._flush_outbox(get_online()))
        QTimer.singleShot(300, self._render_thread)
        QMessageBox.information(self, "Forwarded", f"Message forwarded to {len(targets)} chat(s).")

    # ------------------------------------------------------------------
    def _send_text(self):
        text = self.input_box.text().strip()
        if not text:
            return
        self.input_box.clear()
        self._queue_message(body=text)

    def _queue_message(self, body=None, attachment_local_path=None, attachment_type=None):
        client_msg_id = str(uuid.uuid4())
        reply = self._reply_target
        self.db.queue_chat_outbox(
            client_msg_id=client_msg_id, mcat_code=self.mcat, scope=self.scope,
            sender_id=self.self_id, sender_name=self.self_name, body=body,
            recipient_id=self.recipient_id,
            attachment_local_path=attachment_local_path, attachment_type=attachment_type,
            reply_to_client_id=reply["client_msg_id"] if reply else None,
            reply_preview=reply["preview"] if reply else None,
            reply_sender_name=reply["sender_name"] if reply else None,
        )
        self._cancel_reply()
        self._render_thread()
        QTimer.singleShot(50, lambda: self._flush_outbox(get_online()))
        QTimer.singleShot(200, self._render_thread)

    # ------------------------------------------------------------------
    def _open_attachment(self, attachment_type, local_path, url):
        path = local_path
        if not path or not os.path.exists(path):
            if not url:
                QMessageBox.information(self, "Not available", "This attachment isn't available offline yet.")
                return
            cache_path = media_compress.cache_path_for(url)
            if not cache_path.exists():
                online = get_online()
                ok = online.download_attachment(url, cache_path)
                if not ok:
                    QMessageBox.warning(self, "Download failed",
                                         "Couldn't download this attachment. Check your connection and try again.")
                    return
            path = str(cache_path)

        if attachment_type == "image":
            viewer = ImageViewerDialog([{"file_path": path, "label": "Chat Photo"}], parent=self)
            viewer.exec()
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))


# ==========================================================================
class PinnedMessagesDialog(QDialog):
    """Shows every pinned item in the current thread, latest first, with
    a scroll area for long lists. 'View' closes this and jumps to the
    original message in the main chat."""
    view_requested = Signal(str)

    def __init__(self, pinned_rows, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pinned Messages")
        self.setMinimumSize(420, 480)
        layout = QVBoxLayout(self)

        title = QLabel("📌 Pinned Messages")
        title.setStyleSheet("font-size: 15px; font-weight: 700; color: #10233F;")
        layout.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; }")
        container = QWidget()
        v = QVBoxLayout(container)
        v.setSpacing(8)

        if not pinned_rows:
            empty = QLabel("Nothing is pinned in this chat yet.")
            empty.setStyleSheet("color: #8ea0b3; padding: 20px;")
            v.addWidget(empty)
        else:
            for row in pinned_rows:
                card = QFrame()
                card.setStyleSheet("QFrame { background-color: #F4F7FB; border-radius: 10px; }")
                cl = QVBoxLayout(card)
                cl.setContentsMargins(12, 10, 12, 10)
                sender = QLabel(f"<b>{row.get('sender_name', '')}</b>")
                sender.setStyleSheet("font-size: 12px; color: #1657A8;")
                cl.addWidget(sender)
                snippet = row.get("body") or (
                    "📷 Photo" if row.get("attachment_type") == "image"
                    else "🎬 Video" if row.get("attachment_type") == "video" else "")
                body_lbl = QLabel(snippet[:200])
                body_lbl.setWordWrap(True)
                body_lbl.setStyleSheet("font-size: 12px; color: #10233F;")
                cl.addWidget(body_lbl)
                bottom = QHBoxLayout()
                ts = QLabel(str(row.get("created_at") or "")[:16].replace("T", " "))
                ts.setStyleSheet("font-size: 10px; color: #8ea0b3;")
                bottom.addWidget(ts)
                bottom.addStretch()
                view_btn = QPushButton("View")
                view_btn.setCursor(Qt.PointingHandCursor)
                view_btn.setObjectName("primaryButton")
                cid = row.get("client_msg_id")
                view_btn.clicked.connect(lambda _, c=cid: self._on_view(c))
                bottom.addWidget(view_btn)
                cl.addLayout(bottom)
                v.addWidget(card)
        v.addStretch()
        scroll.setWidget(container)
        layout.addWidget(scroll, 1)

    def _on_view(self, client_msg_id):
        self.view_requested.emit(client_msg_id)
        self.accept()


class ForwardDialog(QDialog):
    """Pick one or more destinations (Global Chat and/or specific people
    under the same Management Code) to forward a message to."""
    def __init__(self, contacts, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Forward Message")
        self.setMinimumSize(340, 400)
        self._contacts = contacts
        layout = QVBoxLayout(self)

        title = QLabel("Forward to…")
        title.setStyleSheet("font-size: 14px; font-weight: 700; color: #10233F;")
        layout.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; }")
        container = QWidget()
        v = QVBoxLayout(container)

        self.global_check = QCheckBox("🌐 Global Chat")
        v.addWidget(self.global_check)

        self.contact_checks = []
        for c in contacts:
            tag = "⭐" if c["account_type"] == "administrator" else "👮"
            cb = QCheckBox(f"{tag} {c['full_name']}")
            cb.setProperty("user_id", str(c["user_id"]))
            cb.setProperty("full_name", c["full_name"])
            v.addWidget(cb)
            self.contact_checks.append(cb)
        v.addStretch()
        scroll.setWidget(container)
        layout.addWidget(scroll, 1)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)
        ok_btn = QPushButton("Forward")
        ok_btn.setObjectName("primaryButton")
        ok_btn.clicked.connect(self.accept)
        btn_row.addWidget(ok_btn)
        layout.addLayout(btn_row)

    def selected_targets(self):
        targets = []
        if self.global_check.isChecked():
            targets.append(("global", None, None))
        for cb in self.contact_checks:
            if cb.isChecked():
                targets.append(("personal", cb.property("user_id"), cb.property("full_name")))
        return targets
