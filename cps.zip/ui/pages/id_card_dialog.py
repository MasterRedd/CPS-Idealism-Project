from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog, QMessageBox
)
from PySide6.QtGui import QPixmap, QImage, QPainter
from PySide6.QtCore import Qt

from ui.pages.id_card_generator import generate_id_card_front, generate_id_card_back


def pil_to_qpixmap(pil_img):
    pil_img = pil_img.convert("RGB")
    data = pil_img.tobytes("raw", "RGB")
    qimg = QImage(data, pil_img.width, pil_img.height, pil_img.width * 3, QImage.Format_RGB888)
    return QPixmap.fromImage(qimg.copy())


class IDCardDialog(QDialog):
    """Preview + export an officer's landscape ID card (front & back)."""

    def __init__(self, profile: dict, school_name: str = "CAT Program System", parent=None):
        super().__init__(parent)
        self.profile = profile
        self.school_name = school_name

        self.front_img = generate_id_card_front(profile, school_name)
        self.back_img = generate_id_card_back(profile, school_name)
        self.showing_front = True

        self.setWindowTitle(f"ID Card — {profile.get('full_name', '')}")
        self.setMinimumWidth(760)
        self._build_ui()
        self._refresh_preview()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)

        title = QLabel(f"ID Card — {self.profile.get('full_name', '')}")
        title.setObjectName("stubTitle")
        layout.addWidget(title)

        self.card_label = QLabel()
        self.card_label.setAlignment(Qt.AlignCenter)
        self.card_label.setStyleSheet("border: 1px solid #E2E7EE; border-radius: 8px; background: white;")
        layout.addWidget(self.card_label)

        flip_row = QHBoxLayout()
        flip_row.addStretch()
        self.flip_btn = QPushButton("Flip to Back")
        self.flip_btn.clicked.connect(self._flip)
        flip_row.addWidget(self.flip_btn)
        flip_row.addStretch()
        layout.addLayout(flip_row)

        btn_row = QHBoxLayout()
        save_pdf_btn = QPushButton("Save as PDF (Front + Back)")
        save_pdf_btn.setObjectName("primaryButton")
        save_pdf_btn.clicked.connect(self._save_pdf)
        btn_row.addWidget(save_pdf_btn)

        save_img_btn = QPushButton("Save as Image")
        save_img_btn.clicked.connect(self._save_image)
        btn_row.addWidget(save_img_btn)

        print_btn = QPushButton("Print")
        print_btn.setObjectName("goldButton")
        print_btn.clicked.connect(self._print)
        btn_row.addWidget(print_btn)

        btn_row.addStretch()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(close_btn)

        layout.addLayout(btn_row)

    def _refresh_preview(self):
        img = self.front_img if self.showing_front else self.back_img
        pix = pil_to_qpixmap(img).scaled(700, 440, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.card_label.setPixmap(pix)
        self.flip_btn.setText("Flip to Back" if self.showing_front else "Flip to Front")

    def _flip(self):
        self.showing_front = not self.showing_front
        self._refresh_preview()

    def _save_pdf(self):
        default_name = f"{self.profile.get('officer_number', 'officer')}_id_card.pdf"
        path, _ = QFileDialog.getSaveFileName(self, "Save ID Card as PDF", default_name, "PDF Files (*.pdf)")
        if not path:
            return
        try:
            front = self.front_img.convert("RGB")
            back = self.back_img.convert("RGB")
            front.save(path, save_all=True, append_images=[back])
            QMessageBox.information(self, "Saved", f"ID card saved to:\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "Save Failed", f"Could not save PDF:\n{e}")

    def _save_image(self):
        side = "front" if self.showing_front else "back"
        default_name = f"{self.profile.get('officer_number', 'officer')}_id_card_{side}.png"
        path, _ = QFileDialog.getSaveFileName(self, "Save ID Card Image", default_name, "PNG Image (*.png)")
        if not path:
            return
        try:
            img = self.front_img if self.showing_front else self.back_img
            img.save(path)
            QMessageBox.information(self, "Saved", f"Image saved to:\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "Save Failed", f"Could not save image:\n{e}")

    def _print(self):
        try:
            from PySide6.QtPrintSupport import QPrinter, QPrintDialog
        except Exception:
            QMessageBox.warning(self, "Printing Unavailable", "Print support isn't available on this system.")
            return

        printer = QPrinter(QPrinter.HighResolution)
        dialog = QPrintDialog(printer, self)
        if dialog.exec() != QPrintDialog.Accepted:
            return

        painter = QPainter(printer)
        for i, img in enumerate([self.front_img, self.back_img]):
            if i > 0:
                printer.newPage()
            pix = pil_to_qpixmap(img)
            page_rect = printer.pageRect(QPrinter.Unit.DevicePixel)
            scaled = pix.scaled(int(page_rect.width()), int(page_rect.height()), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            x = (page_rect.width() - scaled.width()) / 2
            y = (page_rect.height() - scaled.height()) / 2
            painter.drawPixmap(int(x), int(y), scaled)
        painter.end()
