from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QComboBox, QTextEdit,
    QDateTimeEdit, QDialogButtonBox, QLabel, QCheckBox
)
from PySide6.QtCore import QDateTime


class PatrolFormDialog(QDialog):
    """Manual add/edit of a patrol log entry. Used by Admin/Commander/Chief
    Officer to record or correct patrol logs directly (as opposed to an
    officer using the quick Start/End Patrol buttons on the page itself)."""

    def __init__(self, db_manager, patrol: dict = None, parent=None, mcat_code: str = None):
        super().__init__(parent)
        self.db = db_manager
        self.mcat_code = mcat_code
        self.patrol = patrol
        self.is_edit = patrol is not None

        self.setWindowTitle("Edit Patrol Log" if self.is_edit else "Add Patrol Log")
        self.setMinimumWidth(420)
        self._build_ui()
        if self.is_edit:
            self._populate_fields()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.officer_combo = QComboBox()
        self._load_officers()
        form.addRow("Officer *", self.officer_combo)

        self.campus_combo = QComboBox()
        self._load_campuses()
        self.campus_combo.currentIndexChanged.connect(self._reload_buildings)
        form.addRow("Campus", self.campus_combo)

        self.building_combo = QComboBox()
        self._reload_buildings()
        form.addRow("Building", self.building_combo)

        self.time_started_input = QDateTimeEdit()
        self.time_started_input.setCalendarPopup(True)
        self.time_started_input.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.time_started_input.setDateTime(QDateTime.currentDateTime())
        form.addRow("Time Started *", self.time_started_input)

        self.still_in_progress_check = QCheckBox("Still in progress (no end time yet)")
        self.still_in_progress_check.setChecked(True)
        self.still_in_progress_check.toggled.connect(
            lambda checked: self.time_ended_input.setEnabled(not checked)
        )
        form.addRow("", self.still_in_progress_check)

        self.time_ended_input = QDateTimeEdit()
        self.time_ended_input.setCalendarPopup(True)
        self.time_ended_input.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.time_ended_input.setDateTime(QDateTime.currentDateTime())
        self.time_ended_input.setEnabled(False)
        form.addRow("Time Ended", self.time_ended_input)

        self.remarks_input = QTextEdit()
        self.remarks_input.setFixedHeight(70)
        form.addRow("Remarks", self.remarks_input)

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _load_officers(self):
        try:
            for officer in self.db.get_officers(mcat_code=self.mcat_code):
                self.officer_combo.addItem(officer["full_name"], officer["id"])
        except Exception:
            pass

    def _load_campuses(self):
        self.campus_combo.addItem("— No Campus —", None)
        try:
            for campus in self.db.get_campuses(mcat_code=self.mcat_code):
                self.campus_combo.addItem(campus["name"], campus["id"])
        except Exception:
            pass

    def _reload_buildings(self):
        self.building_combo.clear()
        self.building_combo.addItem("— No Building —", None)
        campus_id = self.campus_combo.currentData()
        try:
            for building in self.db.get_buildings(campus_id=campus_id):
                self.building_combo.addItem(building["name"], building["id"])
        except Exception:
            pass

    def _populate_fields(self):
        p = self.patrol
        idx = self.officer_combo.findData(p.get("officer_id"))
        if idx >= 0:
            self.officer_combo.setCurrentIndex(idx)
        if p.get("campus_id"):
            idx = self.campus_combo.findData(p["campus_id"])
            if idx >= 0:
                self.campus_combo.setCurrentIndex(idx)
        self._reload_buildings()
        if p.get("building_id"):
            idx = self.building_combo.findData(p["building_id"])
            if idx >= 0:
                self.building_combo.setCurrentIndex(idx)
        if p.get("time_started"):
            dt = QDateTime.fromString(p["time_started"], "yyyy-MM-dd HH:mm:ss")
            if dt.isValid():
                self.time_started_input.setDateTime(dt)
        if p.get("time_ended"):
            dt = QDateTime.fromString(p["time_ended"], "yyyy-MM-dd HH:mm:ss")
            if dt.isValid():
                self.time_ended_input.setDateTime(dt)
                self.still_in_progress_check.setChecked(False)
        self.remarks_input.setPlainText(p.get("remarks") or "")

    def _on_save(self):
        officer_id = self.officer_combo.currentData()
        if officer_id is None:
            self.error_label.setText("Select an officer.")
            return

        time_ended = None
        if not self.still_in_progress_check.isChecked():
            time_ended = self.time_ended_input.dateTime().toString("yyyy-MM-dd HH:mm:ss")
            if self.time_ended_input.dateTime() < self.time_started_input.dateTime():
                self.error_label.setText("End time cannot be before the start time.")
                return

        self.result_data = {
            "officer_id": officer_id,
            "campus_id": self.campus_combo.currentData(),
            "building_id": self.building_combo.currentData(),
            "time_started": self.time_started_input.dateTime().toString("yyyy-MM-dd HH:mm:ss"),
            "time_ended": time_ended,
            "remarks": self.remarks_input.toPlainText().strip(),
        }
        self.accept()
