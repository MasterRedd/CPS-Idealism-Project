from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView
)
from PySide6.QtCore import Qt

from ui.pages.student_form_dialog import StudentFormDialog
from ui.pages.student_profile_dialog import StudentProfileDialog

# Roles that are allowed to add / edit / delete students.
# Per the spec: Officers can view/patrol/confiscate but not delete records,
# and Viewers are read-only across the board.
CAN_EDIT_ROLES = {"Administrator", "CAT Commander", "Chief Officer"}
CAN_DELETE_ROLES = {"Administrator", "CAT Commander"}

COLUMNS = ["ID", "Student No.", "Full Name", "Grade", "Section", "Campus", "Status"]


class StudentsPage(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user
        self.can_edit = current_user.get("effective_role", current_user["role"]) in CAN_EDIT_ROLES
        self.can_delete = current_user.get("effective_role", current_user["role"]) in CAN_DELETE_ROLES

        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        # Header row: title + add button
        header_row = QHBoxLayout()
        title = QLabel("Students")
        title.setObjectName("stubTitle")
        header_row.addWidget(title)
        header_row.addStretch()

        self.add_btn = QPushButton("+ Add Student")
        self.add_btn.setObjectName("primaryButton")
        self.add_btn.clicked.connect(self._on_add)
        self.add_btn.setVisible(self.can_edit)
        header_row.addWidget(self.add_btn)
        layout.addLayout(header_row)

        # Search row
        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by name or student number...")
        self.search_input.textChanged.connect(self.refresh)
        search_row.addWidget(self.search_input)
        layout.addLayout(search_row)

        # Table
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnHidden(0, True)  # ID column kept for lookups, hidden from view
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setStyleSheet(
            "QTableWidget { background: white; border: 1px solid #E2E7EE; border-radius: 8px; }"
            "QHeaderView::section { background-color: #0A2E5C; color: #ffffff; padding: 7px; border: none; font-weight: 600; }"
        )
        self.table.doubleClicked.connect(self._on_edit)
        layout.addWidget(self.table)

        # Action row (edit / delete for the selected row)
        action_row = QHBoxLayout()
        action_row.addStretch()

        self.edit_btn = QPushButton("Edit Selected")
        self.edit_btn.clicked.connect(self._on_edit)
        self.edit_btn.setVisible(self.can_edit)
        action_row.addWidget(self.edit_btn)

        self.profile_btn = QPushButton("👤 View Profile")
        self.profile_btn.clicked.connect(self._on_view_profile)
        action_row.addWidget(self.profile_btn)

        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setStyleSheet("color: #d9453d;")
        self.delete_btn.clicked.connect(self._on_delete)
        self.delete_btn.setVisible(self.can_delete)
        action_row.addWidget(self.delete_btn)

        layout.addLayout(action_row)

        self.count_label = QLabel("")
        self.count_label.setStyleSheet("color: #8ea0b3; font-size: 12px;")
        layout.addWidget(self.count_label)

    # ------------------------------------------------------------------
    def refresh(self):
        search = self.search_input.text().strip()
        students = self.db.get_students(search=search, mcat_code=self.current_user.get("mcat_code"))

        self.table.setRowCount(0)
        for student in students:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                str(student["id"]),
                student.get("student_number") or "",
                student.get("full_name") or "",
                student.get("grade") or "",
                student.get("section") or "",
                student.get("campus_name") or "—",
                student.get("status") or "",
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 6:
                    item.setForeground(self._status_color(value))
                self.table.setItem(row, col, item)

        self.count_label.setText(f"{len(students)} student(s)")

    @staticmethod
    def _status_color(status):
        from PySide6.QtGui import QColor
        mapping = {
            "Good Standing": QColor("#1e9e5a"),
            "Suspicious": QColor("#c98a1c"),
            "Under Investigation": QColor("#d97706"),
            "Suspended": QColor("#d9453d"),
        }
        return mapping.get(status, QColor("#10233F"))

    # ------------------------------------------------------------------
    def _selected_student_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return int(self.table.item(row, 0).text())

    def _on_add(self):
        dialog = StudentFormDialog(self.db, parent=self, mcat_code=self.current_user.get("mcat_code"))
        if dialog.exec():
            self.db.create_student(dialog.result_data, actor_user_id=self.current_user["id"])
            self.refresh()

    def _on_edit(self):
        student_id = self._selected_student_id()
        if student_id is None:
            QMessageBox.information(self, "No selection", "Select a student to edit first.")
            return
        student = self.db.get_student(student_id)
        dialog = StudentFormDialog(self.db, student=student, parent=self, mcat_code=self.current_user.get("mcat_code"))
        if dialog.exec():
            self.db.update_student(student_id, dialog.result_data, actor_user_id=self.current_user["id"])
            self.refresh()

    def _on_view_profile(self):
        student_id = self._selected_student_id()
        if student_id is None:
            QMessageBox.information(self, "No selection", "Select a student to view first.")
            return
        joined = next((s for s in self.db.get_students(mcat_code=self.current_user.get("mcat_code")) if s["id"] == student_id), None)
        student = joined or self.db.get_student(student_id)
        dialog = StudentProfileDialog(student, parent=self)
        dialog.exec()

    def _on_delete(self):
        student_id = self._selected_student_id()
        if student_id is None:
            QMessageBox.information(self, "No selection", "Select a student to delete first.")
            return
        student = self.db.get_student(student_id)
        confirm = QMessageBox.question(
            self,
            "Confirm delete",
            f"Remove {student['full_name']} from active records?\n\n"
            "This is a soft delete — the record is archived, not permanently erased.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_student(student_id, actor_user_id=self.current_user["id"])
            self.refresh()
