from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QLabel,
    QDialogButtonBox, QMessageBox
)
from PySide6.QtCore import Qt

from ui.widgets.photo_picker import PhotoPicker
from ui.widgets.scrollable import make_scrollable


class AdminRegisterDialog(QDialog):
    """'No admin account? Create one!' flow: Name, Photo (optional),
    Password, Confirm Password. On success, self.mcat_code holds the
    newly issued Management Code."""

    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.mcat_code = None
        self.is_online_code = False
        self.setWindowTitle("Create Administrator Account")
        self.setMinimumWidth(420)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        heading = QLabel("Create a new Administrator account")
        heading.setStyleSheet("font-size: 16px; font-weight: 700; color: #0A2E5C;")
        hint = QLabel(
            "This will issue you a unique Management Code (MCAT). You'll need "
            "it to log in, and any Officer account you create will need it too."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #6b7c93; font-size: 11px;")
        layout.addWidget(heading)
        layout.addWidget(hint)
        layout.addSpacing(6)

        form = QFormLayout()
        form.setSpacing(10)

        self.photo_picker = PhotoPicker()
        form.addRow("Photo (optional):", self.photo_picker)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Full name")
        form.addRow("Full Name:", self.name_input)

        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        form.addRow("Password:", self.password_input)

        self.confirm_input = QLineEdit()
        self.confirm_input.setEchoMode(QLineEdit.Password)
        form.addRow("Confirm Password:", self.confirm_input)

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Cancel)
        create_btn = buttons.addButton("Create", QDialogButtonBox.AcceptRole)
        create_btn.setObjectName("primaryButton")
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self._on_create)
        layout.addWidget(buttons)

        make_scrollable(self)

    def _on_create(self):
        name = self.name_input.text().strip()
        password = self.password_input.text()
        confirm = self.confirm_input.text()

        if not name:
            self.error_label.setText("Please enter your full name.")
            return
        if not password:
            self.error_label.setText("Please choose a password.")
            return
        if password != confirm:
            self.error_label.setText("Passwords do not match.")
            return
        if len(password) < 6:
            self.error_label.setText("Password should be at least 6 characters.")
            return

        online_code = None
        try:
            from online.supabase_client import get_online
            online_code = get_online().register_admin_online(name)
        except Exception:
            online_code = None

        self.is_online_code = online_code is not None
        self.mcat_code = self.db.create_administrator_account(
            full_name=name, password=password, photo_path=self.photo_picker.value(),
            mcat_override=online_code,
        )
        self.accept()


class McatRevealDialog(QDialog):
    """Shown exactly once, right after an Administrator account is created,
    so they can note down their Management Code."""

    def __init__(self, mcat_code: str, parent=None, is_online: bool = False):
        super().__init__(parent)
        self.setWindowTitle("Your Management Code")
        self.setMinimumWidth(380)
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)

        title = QLabel("Account created!")
        title.setStyleSheet("font-size: 16px; font-weight: 700; color: #0A2E5C;")
        title.setAlignment(Qt.AlignCenter)

        code_label = QLabel(mcat_code)
        code_label.setStyleSheet(
            "font-size: 30px; font-weight: 800; color: #D4AF37; "
            "background: #0A2E5C; border-radius: 8px; padding: 16px 24px;"
        )
        code_label.setAlignment(Qt.AlignCenter)

        status = QLabel(
            "🟢 Confirmed globally unique (online)" if is_online
            else "⚪ Assigned locally — connect to the internet soon so this "
                 "device can confirm it's globally unique"
        )
        status.setStyleSheet("font-size: 11px; color: #6b7c93;")
        status.setAlignment(Qt.AlignCenter)
        status.setWordWrap(True)

        note = QLabel(
            "This is your Management Code. Save it somewhere safe — you'll "
            "need it every time you log in, and every Officer account you "
            "create will need it too. You can always find it again in "
            "Settings once you're logged in."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #6b7c93; font-size: 12px;")
        note.setAlignment(Qt.AlignCenter)

        ok_btn = QDialogButtonBox(QDialogButtonBox.Ok)
        ok_btn.accepted.connect(self.accept)

        layout.addWidget(title)
        layout.addSpacing(10)
        layout.addWidget(code_label)
        layout.addSpacing(6)
        layout.addWidget(status)
        layout.addSpacing(10)
        layout.addWidget(note)
        layout.addSpacing(6)
        layout.addWidget(ok_btn)
