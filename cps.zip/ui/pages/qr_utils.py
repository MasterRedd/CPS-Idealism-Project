"""
Shared helpers for QR code scanning — used by the generic "Scan QR" lookup
dialog and the "Scan IRL Log In / Log Out" attendance dialogs so both share
the exact same camera-opening and image-decoding logic instead of drifting
apart over time.

Decoding strategy: pyzbar (which wraps the ZBar library) is used as the
primary decoder because it is noticeably more reliable than OpenCV's built-in
cv2.QRCodeDetector, especially on photos of a printed/screen QR code that
aren't perfectly cropped, lit, or in focus — which is exactly the "I picked
a clear image and it still says no QR detected" situation this exists to
fix. cv2.QRCodeDetector is kept as an automatic fallback for machines where
the system ZBar library isn't installed (pyzbar needs it), so the app still
works without pyzbar — just less reliably.
"""
import os
import sys

# Quiet OpenCV's internal backend logging (e.g. FFmpeg/V4L2/libavdevice
# warnings printed straight to the console) before cv2 is imported. These
# are almost always harmless — OpenCV just tried one backend, it didn't
# have what it wanted, and it fell back to another one — but they read
# like errors to anyone watching the terminal.
os.environ.setdefault("OPENCV_LOG_LEVEL", "SILENT")
os.environ.setdefault("OPENCV_VIDEOIO_PRIORITY_MSMF", "0")

try:
    import cv2
except Exception:
    cv2 = None

try:
    from pyzbar import pyzbar
except Exception:
    pyzbar = None

try:
    import numpy as np
except Exception:
    np = None


def open_camera():
    """Try a small set of backends/indices so the scanner works across
    Windows, macOS, and Linux instead of assuming a single default
    backend is available. Returns an opened cv2.VideoCapture or None."""
    if cv2 is None:
        return None

    if sys.platform.startswith("win"):
        backend_candidates = [cv2.CAP_DSHOW, cv2.CAP_MSMF, cv2.CAP_ANY]
    elif sys.platform == "darwin":
        backend_candidates = [cv2.CAP_AVFOUNDATION, cv2.CAP_ANY]
    else:
        backend_candidates = [cv2.CAP_V4L2, cv2.CAP_ANY]

    for backend in backend_candidates:
        for index in range(3):
            try:
                cap = cv2.VideoCapture(index, backend)
            except Exception:
                continue
            if cap is not None and cap.isOpened():
                return cap
            if cap is not None:
                cap.release()
    return None


def _variants(image):
    """Yields a handful of preprocessed versions of the same image to try
    decoding against, in order of "most likely to just work" first. This is
    what rescues real-world photos: slightly too small/large, low contrast,
    or with the ZBar/OpenCV decoder needing plain grayscale instead of BGR."""
    yield image

    if cv2 is None:
        return

    try:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    except Exception:
        gray = None

    if gray is not None:
        yield gray

        h, w = gray.shape[:2]
        # Upscale small images — a QR photographed from a distance often
        # has each "module" only a couple of pixels wide, which is too
        # small for either decoder to read reliably.
        if max(h, w) < 900:
            scale = 900 / max(h, w)
            try:
                yield cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            except Exception:
                pass

        # Downscale very large images — some decoders choke on huge phone
        # camera photos.
        if max(h, w) > 2200:
            scale = 2200 / max(h, w)
            try:
                yield cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
            except Exception:
                pass

        # Contrast boost via adaptive threshold — helps with glare, shadows,
        # or a low-contrast printout/screen photo.
        try:
            yield cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, 5
            )
        except Exception:
            pass

        # Plain global threshold as one more fallback.
        try:
            _, simple = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            yield simple
        except Exception:
            pass


def _decode_with_pyzbar(image):
    if pyzbar is None:
        return ""
    try:
        results = pyzbar.decode(image)
    except Exception:
        return ""
    for r in results:
        try:
            return r.data.decode("utf-8")
        except Exception:
            continue
    return ""


def _decode_with_opencv(image):
    if cv2 is None:
        return ""
    try:
        detector = cv2.QRCodeDetector()
        data, _points, _ = detector.detectAndDecode(image)
        return data or ""
    except Exception:
        return ""


def _decode_any(image):
    """Runs both decoders against a handful of preprocessed variants of the
    image and returns the first successful result, or ''."""
    if image is None:
        return ""
    for variant in _variants(image):
        data = _decode_with_pyzbar(variant)
        if data:
            return data
        data = _decode_with_opencv(variant)
        if data:
            return data
    return ""


def decode_qr_from_frame(frame):
    """Returns the decoded string from a live camera frame, or '' if none found."""
    return _decode_any(frame)


def decode_qr_from_image_path(path: str):
    """Reads an arbitrary image file from disk and tries to decode a QR code
    from it, trying several preprocessing passes so a slightly imperfect
    real-world photo (bad crop, glare, low contrast, too small) still has a
    good chance of decoding. Returns the decoded string, or '' if no QR
    code was found / the file couldn't be read at all."""
    if cv2 is None:
        return ""
    try:
        # imdecode handles unicode/odd paths more reliably on Windows than imread
        with open(path, "rb") as f:
            buf = f.read()
        if np is not None:
            arr = np.frombuffer(buf, dtype="uint8")
            image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        else:
            image = cv2.imread(path)
    except Exception:
        image = None
    if image is None:
        return ""
    return _decode_any(image)
