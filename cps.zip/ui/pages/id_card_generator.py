"""
ID Card Generator
------------------
Builds a landscape, CR-80-style ID card (front + back) for a CAT officer
as PIL Images, in the app's Blue / Gold / White theme. The back embeds a
QR code carrying the officer's full identity as JSON, for future
verification-by-scan use cases.
"""

import json
from datetime import date, datetime
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
import qrcode

# CR-80 card ratio at 300 DPI-equivalent resolution
CARD_W, CARD_H = 1013, 638

NAVY = (10, 46, 92)
NAVY_DARK = (13, 53, 104)
GOLD = (212, 175, 55)
WHITE = (255, 255, 255)
LIGHT = (245, 248, 252)
MUTED = (90, 107, 125)
TEXT = (20, 30, 45)

_FONT_CANDIDATES_BOLD = [
    "arialbd.ttf", "Arial Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
]
_FONT_CANDIDATES_REGULAR = [
    "arial.ttf", "Arial.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
]


def _load_font(candidates, size):
    for name in candidates:
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            continue
    return ImageFont.load_default()


def font_bold(size):
    return _load_font(_FONT_CANDIDATES_BOLD, size)


def font_regular(size):
    return _load_font(_FONT_CANDIDATES_REGULAR, size)


def _calculate_age(birthday_str):
    if not birthday_str:
        return "—"
    try:
        b = datetime.strptime(birthday_str, "%Y-%m-%d").date()
    except ValueError:
        return "—"
    today = date.today()
    years = today.year - b.year - ((today.month, today.day) < (b.month, b.day))
    return str(years)


def _load_photo(photo_path, size):
    """Returns a square-cropped, resized RGB photo, or a placeholder silhouette."""
    if photo_path and Path(photo_path).exists():
        try:
            img = Image.open(photo_path).convert("RGB")
            # Center-crop to square
            w, h = img.size
            side = min(w, h)
            left = (w - side) // 2
            top = (h - side) // 2
            img = img.crop((left, top, left + side, top + side))
            return img.resize((size, size), Image.LANCZOS)
        except Exception:
            pass
    # Placeholder: soft gray square with initials-free silhouette
    placeholder = Image.new("RGB", (size, size), (226, 231, 238))
    d = ImageDraw.Draw(placeholder)
    d.ellipse((size * 0.28, size * 0.16, size * 0.72, size * 0.58), fill=(190, 200, 212))
    d.ellipse((size * 0.12, size * 0.60, size * 0.88, size * 1.15), fill=(190, 200, 212))
    return placeholder


def _rounded_rect(draw, box, radius, fill):
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def generate_id_card_front(profile: dict, school_name: str = "CAT Program System") -> Image.Image:
    img = Image.new("RGB", (CARD_W, CARD_H), WHITE)
    draw = ImageDraw.Draw(img)

    # Header
    draw.rectangle((0, 0, CARD_W, 96), fill=NAVY)
    draw.rectangle((0, 96, CARD_W, 101), fill=GOLD)
    draw.text((28, 18), school_name, font=font_bold(30), fill=WHITE)
    draw.text((28, 56), "CAT OFFICER IDENTIFICATION CARD", font=font_regular(15), fill=(199, 214, 236))

    # Photo
    photo_size = 220
    photo = _load_photo(profile.get("photo_path"), photo_size)
    photo_x, photo_y = 40, 135
    img.paste(photo, (photo_x, photo_y))
    draw.rectangle((photo_x, photo_y, photo_x + photo_size, photo_y + photo_size), outline=NAVY, width=3)

    # Name + core info (middle column)
    mid_x = photo_x + photo_size + 36
    draw.text((mid_x, 130), profile.get("full_name", ""), font=font_bold(30), fill=TEXT)
    draw.text((mid_x, 172), profile.get("rank") or profile.get("position") or "CAT Officer",
              font=font_regular(17), fill=(176, 141, 30))

    rows = [
        ("Age", _calculate_age(profile.get("birthday"))),
        ("Birthday", profile.get("birthday") or "—"),
        ("Grade", profile.get("grade") or "—"),
        ("Section", profile.get("section") or "—"),
    ]
    y = 216
    for label, value in rows:
        draw.text((mid_x, y), f"{label}:", font=font_bold(15), fill=MUTED)
        draw.text((mid_x + 100, y), str(value), font=font_regular(15), fill=TEXT)
        y += 30

    # Side info strip (right column)
    strip_x = CARD_W - 300
    draw.rectangle((strip_x, 110, CARD_W - 24, CARD_H - 24), fill=LIGHT, outline=(226, 231, 238))
    side_rows = [
        ("Officer ID", profile.get("officer_number") or "—"),
        ("Rank", profile.get("rank") or "—"),
        ("Position", profile.get("position") or "—"),
        ("Campus", profile.get("campus_name") or "—"),
        ("Building", profile.get("building_name") or "—"),
        ("Account Role", profile.get("account_role") or "—"),
        ("Username", profile.get("username") or "—"),
        ("Management Code", profile.get("mcat_code") or "—"),
    ]
    sy = 128
    for label, value in side_rows:
        draw.text((strip_x + 16, sy), label.upper(), font=font_bold(11), fill=(140, 155, 170))
        draw.text((strip_x + 16, sy + 15), _truncate(value, 26), font=font_regular(15), fill=TEXT)
        sy += 46

    # Footer
    draw.rectangle((0, CARD_H - 34, CARD_W, CARD_H), fill=NAVY)
    draw.text((28, CARD_H - 28), "This card is property of the school. If found, please return to the campus office.",
               font=font_regular(12), fill=(199, 214, 236))

    return img


def generate_id_card_back(profile: dict, school_name: str = "CAT Program System") -> Image.Image:
    img = Image.new("RGB", (CARD_W, CARD_H), WHITE)
    draw = ImageDraw.Draw(img)

    draw.rectangle((0, 0, CARD_W, 60), fill=NAVY)
    draw.rectangle((0, 60, CARD_W, 65), fill=GOLD)
    draw.text((28, 16), "VERIFICATION QR CODE", font=font_bold(20), fill=WHITE)

    # Build the verification payload
    payload = {
        "type": "CPS-OFFICER-ID",
        "officer_number": profile.get("officer_number"),
        "full_name": profile.get("full_name"),
        "gender": profile.get("gender"),
        "birthday": profile.get("birthday"),
        "grade": profile.get("grade"),
        "section": profile.get("section"),
        "rank": profile.get("rank"),
        "position": profile.get("position"),
        "campus": profile.get("campus_name"),
        "building": profile.get("building_name"),
        "account_role": profile.get("account_role"),
        "username": profile.get("username"),
        "mcat_code": profile.get("mcat_code"),
    }
    qr_img = qrcode.make(json.dumps(payload), border=2).convert("RGB")
    qr_size = 340
    qr_img = qr_img.resize((qr_size, qr_size), Image.NEAREST)
    qr_x = (CARD_W - qr_size) // 2
    qr_y = 95
    img.paste(qr_img, (qr_x, qr_y))
    draw.rectangle((qr_x - 4, qr_y - 4, qr_x + qr_size + 4, qr_y + qr_size + 4), outline=(226, 231, 238), width=2)

    caption = "Scan with the Officers > Scan QR tool to pull up this officer's record."
    draw.text((CARD_W / 2, qr_y + qr_size + 24), caption, font=font_regular(14), fill=MUTED, anchor="ma")
    draw.text((CARD_W / 2, qr_y + qr_size + 48),
              f"Officer ID: {profile.get('officer_number') or '—'}",
              font=font_bold(15), fill=TEXT, anchor="ma")

    draw.rectangle((0, CARD_H - 34, CARD_W, CARD_H), fill=NAVY)
    draw.text((CARD_W / 2, CARD_H - 28), school_name, font=font_regular(12), fill=(199, 214, 236), anchor="ma")

    return img


def _truncate(value, max_len):
    value = str(value)
    return value if len(value) <= max_len else value[: max_len - 1] + "…"


def qr_payload_for_officer(profile: dict) -> str:
    """Same payload builder as the back-of-card QR, exposed separately so the
    QR scanner can be tested / reused without regenerating an image."""
    payload = {
        "type": "CPS-OFFICER-ID",
        "officer_number": profile.get("officer_number"),
    }
    return json.dumps(payload)
