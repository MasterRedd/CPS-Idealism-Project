import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFrame, QGraphicsDropShadowEffect, QCheckBox, QApplication
)
from PySide6.QtCore import Qt, Signal, QThread, QTimer, QEvent, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QColor, QAction, QIcon, QPixmap, QPainter, QPen

from ui.pages.admin_register_dialog import AdminRegisterDialog, McatRevealDialog
from ui.pages.mcat_dialogs import DeletionCountdownDialog
from ui.logo_animator import LogoAnimatorWidget
from ui.accent_bar import AccentMoodBar


def _make_eye_icon(open_eye: bool) -> QIcon:
    """Small hand-drawn eye / eye-off glyph so we don't depend on a
    bundled icon font or extra asset file."""
    pm = QPixmap(20, 20)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    pen = QPen(QColor("#6b7c93"))
    pen.setWidthF(1.6)
    p.setPen(pen)
    p.setBrush(Qt.NoBrush)
    p.drawEllipse(2, 5, 16, 10)
    if open_eye:
        p.setBrush(QColor("#6b7c93"))
        p.drawEllipse(8, 8, 4, 4)
    else:
        p.drawLine(2, 16, 18, 2)
    p.end()
    return QIcon(pm)


class _ConnectionCheckThread(QThread):
    """Runs the real (network) connection-quality check off the UI thread
    so the login screen never freezes waiting on it."""
    result_ready = Signal(dict)

    def run(self):
        try:
            from online.supabase_client import get_online
            result = get_online().check_connection_quality()
        except Exception as e:
            result = {"level": "offline", "label": f"Offline — {e}", "ms": None}
        self.result_ready.emit(result)


class LoginWindow(QWidget):
    """Emits `login_successful(user_dict)` once authentication passes."""

    login_successful = Signal(dict)

    def __init__(self, db_manager):
        super().__init__()
        self.db = db_manager
        self.account_type = "administrator"  # or "officer"
        self.setWindowTitle("CAT Program System — Login")
        self.setMinimumSize(900, 620)
        self._conn_thread = None
        self._wrong_attempts = 0            # general failed-login counter
        self._creator_wrong_attempts = 0    # Creator-specific failed count (max 3)
        self._greeted_time_of_day = False   # only greet once per session
        self._is_sleepy = False
        self._build_ui()
        self._start_connection_check()

        # ── inactivity tracking → "sleepy" mood after a stretch of nothing ─
        self._inactivity_timer = QTimer(self)
        self._inactivity_timer.setInterval(20_000)   # 20s of no interaction
        self._inactivity_timer.setSingleShot(True)
        self._inactivity_timer.timeout.connect(self._go_sleepy)
        self._inactivity_timer.start()
        self.installEventFilter(self)

    def _build_ui(self):
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── Left brand panel ─────────────────────────────────────────────
        brand = QFrame()
        brand.setStyleSheet("background-color: #0A2E5C;")
        brand_layout = QVBoxLayout(brand)
        brand_layout.setContentsMargins(50, 0, 50, 0)
        brand_layout.setSpacing(0)
        brand_layout.setAlignment(Qt.AlignCenter)

        # Animated logo: fade-in → drop → impact zoom → shatter flash
        self.logo_anim = LogoAnimatorWidget()
        brand_layout.addWidget(self.logo_anim, 0, Qt.AlignHCenter)

        # Living accent bar — sits directly under the logo, centered, and
        # reacts (colour / length / shake / floating bubble) to whatever
        # the person is doing on the login form.
        self.accent_bar = AccentMoodBar()
        brand_layout.addWidget(self.accent_bar, 0, Qt.AlignHCenter)
        self.logo_anim.impactOccurred.connect(lambda: self.accent_bar.react("impact"))

        title = QLabel("CAT Program\nSystem")
        title.setAlignment(Qt.AlignHCenter)
        title.setStyleSheet(
            "color: white; font-size: 30px; font-weight: 800; margin-top: 4px;"
        )
        subtitle = QLabel("Citizenship Advancement Training\nManagement Platform")
        subtitle.setAlignment(Qt.AlignHCenter)
        subtitle.setStyleSheet("color: #D4AF37; font-size: 13px; margin-top: 10px;")

        brand_layout.addWidget(title)
        brand_layout.addWidget(subtitle)
        outer.addWidget(brand, 1)

        # Right login panel
        right = QFrame()
        right.setStyleSheet("background-color: #F5F8FC;")
        right_layout = QVBoxLayout(right)
        right_layout.setAlignment(Qt.AlignCenter)

        panel = QFrame()
        panel.setObjectName("loginPanel")
        panel.setFixedWidth(380)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(30)
        shadow.setColor(QColor(10, 46, 92, 60))
        shadow.setOffset(0, 8)
        panel.setGraphicsEffect(shadow)

        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(32, 28, 32, 28)
        panel_layout.setSpacing(10)

        heading = QLabel("Sign in")
        heading.setStyleSheet("font-size: 20px; font-weight: 700; color: #0A2E5C;")

        # --- Account type toggle ---
        toggle_row = QHBoxLayout()
        self.admin_toggle_btn = QPushButton("Administrator")
        self.officer_toggle_btn = QPushButton("Officer")
        for b in (self.admin_toggle_btn, self.officer_toggle_btn):
            b.setCheckable(True)
        self.admin_toggle_btn.setChecked(True)
        self.admin_toggle_btn.clicked.connect(lambda: self._set_account_type("administrator"))
        self.officer_toggle_btn.clicked.connect(lambda: self._set_account_type("officer"))
        toggle_row.addWidget(self.admin_toggle_btn)
        toggle_row.addWidget(self.officer_toggle_btn)

        self.identifier_label = QLabel("Full Name")
        self.identifier_label.setStyleSheet("font-size: 11px; color: #6b7c93; margin-top: 4px;")
        self.identifier_input = QLineEdit()
        self.identifier_input.setPlaceholderText("Full name")

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Password")
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.returnPressed.connect(self._attempt_login)
        self._pw_visible = False
        self._toggle_pw_action = QAction(_make_eye_icon(False), "Show password", self)
        self._toggle_pw_action.triggered.connect(self._toggle_password_visibility)
        self.password_input.addAction(self._toggle_pw_action, QLineEdit.TrailingPosition)
        self.password_input.installEventFilter(self)
        self.password_input.textChanged.connect(lambda _t: self._reset_inactivity())

        self.mcat_label = QLabel("Management Code (MCAT)")
        self.mcat_label.setStyleSheet("font-size: 11px; color: #6b7c93; margin-top: 4px;")
        self.mcat_input = QLineEdit()
        self.mcat_input.setPlaceholderText("e.g. MCAT-1  (leave blank only if you are the Creator)")
        self.mcat_input.returnPressed.connect(self._attempt_login)
        self.identifier_input.textChanged.connect(self._sync_creator_ui)
        self.identifier_input.textChanged.connect(self._react_identifier_typed)
        self.identifier_input.textChanged.connect(lambda _t: self._reset_inactivity())

        self.remember_checkbox = QCheckBox("Stay logged in on this device?")
        self.remember_checkbox.setStyleSheet("font-size: 12px; color: #10233F;")

        self.connection_label = QLabel("● Checking connection…")
        self.connection_label.setStyleSheet("font-size: 11px; color: #6b7c93; margin-top: 2px;")

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #d9453d; font-size: 12px;")
        self.error_label.setWordWrap(True)

        login_btn = QPushButton("Log In")
        login_btn.setObjectName("primaryButton")
        login_btn.clicked.connect(self._attempt_login)
        self.login_btn = login_btn

        self.create_admin_link = QPushButton("No admin account? Create one!")
        self.create_admin_link.setFlat(True)
        self.create_admin_link.setStyleSheet(
            "color: #1657A8; text-decoration: underline; border: none; font-size: 12px;"
        )
        self.create_admin_link.clicked.connect(self._open_create_admin)

        panel_layout.addWidget(heading)
        panel_layout.addWidget(self.connection_label)
        panel_layout.addLayout(toggle_row)
        panel_layout.addSpacing(4)
        panel_layout.addWidget(self.identifier_label)
        panel_layout.addWidget(self.identifier_input)
        panel_layout.addWidget(self.password_input)
        panel_layout.addWidget(self.mcat_label)
        panel_layout.addWidget(self.mcat_input)
        panel_layout.addWidget(self.remember_checkbox)
        panel_layout.addWidget(self.error_label)
        panel_layout.addSpacing(4)
        panel_layout.addWidget(login_btn)
        panel_layout.addSpacing(6)
        panel_layout.addWidget(self.create_admin_link)

        right_layout.addWidget(panel)
        outer.addWidget(right, 1)

        self._set_account_type("administrator")

    def _set_account_type(self, account_type):
        self.account_type = account_type
        self.admin_toggle_btn.setChecked(account_type == "administrator")
        self.officer_toggle_btn.setChecked(account_type == "officer")
        if account_type == "administrator":
            self.identifier_label.setText("Full Name")
            self.identifier_input.setPlaceholderText("Full name (or 'Creator')")
            self.create_admin_link.show()
        else:
            self.identifier_label.setText("Username")
            self.identifier_input.setPlaceholderText("Username")
            self.create_admin_link.hide()
        self.error_label.setText("")
        self._wrong_attempts = 0
        self._sync_creator_ui()
        self._react_identifier_typed(self.identifier_input.text())

    def _is_creator_entry(self) -> bool:
        return (
            self.account_type == "administrator"
            and self.identifier_input.text().strip() == self.db.CREATOR_USERNAME
        )

    def _react_identifier_typed(self, _text: str):
        """Accent bar reacts to what's being typed in the identifier field —
        a different excited mood for admins vs. officers, and a respectful
        greeting the moment 'Creator' is typed exactly."""
        if not hasattr(self, "accent_bar"):
            return
        text = self.identifier_input.text().strip()
        if not text:
            if not self._greeted_time_of_day:
                self._greeted_time_of_day = True
                hour = datetime.datetime.now().hour
                if 5 <= hour < 12:
                    mood = "morning_greet"
                elif hour >= 19 or hour < 5:
                    mood = "evening_greet"
                else:
                    mood = "idle_admin" if self.account_type == "administrator" else "idle_officer"
            else:
                mood = "idle_admin" if self.account_type == "administrator" else "idle_officer"
        elif self._is_creator_entry():
            mood = "creator_greet"
        elif self.account_type == "administrator":
            mood = "typing_admin"
        else:
            mood = "typing_officer"
        self.accent_bar.react(mood)

    def _sync_creator_ui(self):
        # The Creator login is a view-only override with no MCAT and no
        # "stay logged in" session — make that visually obvious rather than
        # showing controls that quietly do nothing once Creator is typed in.
        is_creator = self._is_creator_entry()
        self.mcat_label.setVisible(not is_creator)
        self.mcat_input.setVisible(not is_creator)
        self.remember_checkbox.setVisible(not is_creator)
        if is_creator:
            self.remember_checkbox.setChecked(False)

    def _start_connection_check(self):
        from PySide6.QtWidgets import QGraphicsOpacityEffect
        self._conn_pulse_effect = QGraphicsOpacityEffect(self.connection_label)
        self.connection_label.setGraphicsEffect(self._conn_pulse_effect)
        self._conn_pulse_anim = QPropertyAnimation(self._conn_pulse_effect, b"opacity")
        self._conn_pulse_anim.setDuration(700)
        self._conn_pulse_anim.setStartValue(1.0)
        self._conn_pulse_anim.setEndValue(0.35)
        self._conn_pulse_anim.setEasingCurve(QEasingCurve.InOutSine)
        self._conn_pulse_anim.setLoopCount(-1)
        self._conn_pulse_anim.setKeyValueAt(0.0, 1.0)
        self._conn_pulse_anim.setKeyValueAt(0.5, 0.35)
        self._conn_pulse_anim.setKeyValueAt(1.0, 1.0)
        self._conn_pulse_anim.start()

        self._conn_thread = _ConnectionCheckThread(self)
        self._conn_thread.result_ready.connect(self._on_connection_result)
        self._conn_thread.start()

    def _on_connection_result(self, result: dict):
        if self._conn_pulse_anim:
            self._conn_pulse_anim.stop()
        self._conn_pulse_effect.setOpacity(1.0)

        colors = {
            "best": "#1E8E3E",     # green
            "mid": "#D4AF37",      # gold
            "weak": "#E07A00",     # amber
            "offline": "#d9453d",  # red
        }
        level = result.get("level", "offline")
        color = colors.get(level, "#6b7c93")
        bars = {"best": "▮▮▮", "mid": "▮▮▯", "weak": "▮▯▯", "offline": "▯▯▯"}.get(level, "▯▯▯")
        self.connection_label.setText(f"{bars} {result.get('label', 'Offline')}")
        self.connection_label.setStyleSheet(
            f"font-size: 11px; color: {color}; font-weight: 600; margin-top: 2px;"
        )

    def _open_create_admin(self):
        self.accent_bar.react("detective")
        dialog = AdminRegisterDialog(self.db, parent=self)
        if dialog.exec() and dialog.mcat_code:
            reveal = McatRevealDialog(dialog.mcat_code, parent=self, is_online=dialog.is_online_code)
            reveal.exec()
            self.accent_bar.react("case_closed")
            self.identifier_input.setText(dialog.name_input.text().strip())
            self.mcat_input.setText(dialog.mcat_code)
            self.password_input.clear()
            self.password_input.setFocus()
        else:
            self._react_identifier_typed(self.identifier_input.text())

    def _attempt_login(self):
        self._wake_up()
        identifier = self.identifier_input.text().strip()
        password = self.password_input.text()
        mcat_code = self.mcat_input.text().strip() or None
        is_creator_attempt = self._is_creator_entry()

        if not identifier or not password:
            self.error_label.setText("Please fill in all required fields.")
            return
        if not mcat_code and not is_creator_attempt:
            self.error_label.setText("Management Code (MCAT) is required.")
            return

        # Brief "verifying" beat so the login button and accent bar both
        # visibly acknowledge the click before the result lands — makes
        # even a near-instant local check feel deliberate rather than
        # like nothing happened.
        was_struggling = self._wrong_attempts >= 2 or self._creator_wrong_attempts >= 1
        self.accent_bar.react("verifying")
        self.login_btn.setEnabled(False)
        self._login_btn_original_text = self.login_btn.text()
        self.login_btn.setText("Verifying…")
        QTimer.singleShot(
            260,
            lambda: self._finish_login(identifier, password, mcat_code,
                                        is_creator_attempt, was_struggling),
        )

    def _finish_login(self, identifier, password, mcat_code, is_creator_attempt, was_struggling):
        self.login_btn.setEnabled(True)
        self.login_btn.setText(getattr(self, "_login_btn_original_text", "Log In"))

        user = self.db.authenticate(self.account_type, identifier, password, mcat_code)
        if not user:
            self.error_label.setText("Invalid credentials, or Management Code doesn't match.")
            self.password_input.clear()
            self._react_to_wrong_login(is_creator_attempt)
            return

        self.error_label.setText("")
        self._wrong_attempts = 0
        self._creator_wrong_attempts = 0
        if was_struggling:
            self.accent_bar.react("relief")
            QTimer.singleShot(900, lambda: self.accent_bar.react("success"))
        else:
            self.accent_bar.react("success")

        # Creator: skip attendance/remember-me, just hand off straight away.
        if user.get("account_type") == "creator":
            self.login_successful.emit(user)
            return

        if user.get("id"):
            self.db.log_activity(user["id"], "Logged In", f"user={identifier}")

        if self.remember_checkbox.isChecked() and user.get("id"):
            import secrets
            token = secrets.token_hex(24)
            self.db.set_remember_token(user["id"], token)
            self._save_remember_token(token)
        elif user.get("id"):
            self.db.clear_remember_token(user["id"])
            self._save_remember_token(None)

        # Administrator deletion-countdown check.
        if user.get("account_type") == "administrator":
            status = self.db.get_deletion_status(user["mcat_code"])
            if status:
                dlg = DeletionCountdownDialog(
                    self.db, user["mcat_code"], status["hours_left"], parent=self
                )
                dlg.exec()
                if dlg.deleted_now:
                    self.error_label.setText("That account has been deleted.")
                    return

        self.login_successful.emit(user)

    def _react_to_wrong_login(self, is_creator_attempt: bool):
        """Escalating accent-bar reaction to a failed login.

        Regular accounts: disappointed → sad → mad (mood keeps escalating
        but the form stays usable).

        Creator: gets angrier each of 3 attempts — on the 3rd wrong
        password the program closes itself.
        """
        if is_creator_attempt:
            self._creator_wrong_attempts += 1
            if self._creator_wrong_attempts >= 3:
                self.accent_bar.react("creator_angry3")
                self.error_label.setText("Too many incorrect attempts. Closing…")
                self.identifier_input.setEnabled(False)
                self.password_input.setEnabled(False)
                self.mcat_input.setEnabled(False)
                for w in self._login_action_widgets():
                    w.setEnabled(False)
                QTimer.singleShot(1700, QApplication.instance().quit)
            elif self._creator_wrong_attempts == 2:
                self.accent_bar.react("creator_angry2")
            else:
                self.accent_bar.react("creator_angry1")
        else:
            self._wrong_attempts += 1
            if self._wrong_attempts >= 3:
                self.accent_bar.react("mad")
            elif self._wrong_attempts == 2:
                self.accent_bar.react("sad")
            else:
                self.accent_bar.react("disappointed")

    def _toggle_password_visibility(self):
        self._wake_up()
        self._pw_visible = not self._pw_visible
        self.password_input.setEchoMode(
            QLineEdit.Normal if self._pw_visible else QLineEdit.Password
        )
        self._toggle_pw_action.setIcon(_make_eye_icon(self._pw_visible))
        self._toggle_pw_action.setText("Hide password" if self._pw_visible else "Show password")
        self.accent_bar.react("password_shown" if self._pw_visible else "password_hidden")

    # ── inactivity / sleepy handling ─────────────────────────────────────

    def _reset_inactivity(self):
        self._inactivity_timer.start()   # restart the 20s countdown
        if self._is_sleepy:
            self._wake_up()

    def _wake_up(self):
        if self._is_sleepy:
            self._is_sleepy = False
            self._react_identifier_typed(self.identifier_input.text())
        self._inactivity_timer.start()

    def _go_sleepy(self):
        # Don't doze off mid-conversation — only when the bar would
        # otherwise just be sitting there.
        self._is_sleepy = True
        self.accent_bar.react("sleepy")

    def eventFilter(self, obj, event):
        # Any real user interaction anywhere on the window resets the
        # inactivity clock (and wakes the bar back up if it had dozed off).
        if event.type() in (
            QEvent.MouseButtonPress, QEvent.KeyPress, QEvent.MouseMove,
        ):
            self._reset_inactivity()

        # Lightweight Caps-Lock heuristic while typing the password: if the
        # Shift key state disagrees with the letter case actually produced,
        # Caps Lock is almost certainly on.
        if obj is self.password_input and event.type() == QEvent.KeyPress:
            text = event.text()
            if text and text.isalpha():
                shift_held = bool(event.modifiers() & Qt.ShiftModifier)
                if text.isupper() != shift_held:
                    self.accent_bar.react("caps_lock")
        return super().eventFilter(obj, event)

    def _login_action_widgets(self):
        widgets = [
            self.admin_toggle_btn, self.officer_toggle_btn,
            self.create_admin_link, self.login_btn,
        ]
        return [w for w in widgets if w is not None]

    def closeEvent(self, event):
        if self._conn_thread is not None and self._conn_thread.isRunning():
            self._conn_thread.quit()
            self._conn_thread.wait(1500)
        super().closeEvent(event)

    @staticmethod
    def _save_remember_token(token):
        # Wrapped defensively: on some Windows setups, the registry-backed
        # QSettings store can be briefly locked or unavailable. Previously an
        # exception here would silently abort BEFORE the value was written,
        # so "stay logged in" looked checked but never actually persisted.
        # We also force an explicit .sync() so the value hits disk/registry
        # immediately instead of waiting for object teardown.
        from PySide6.QtCore import QSettings
        try:
            settings = QSettings("CPS", "CATProgramSystem")
            if token:
                settings.setValue("remember_token", token)
            else:
                settings.remove("remember_token")
            settings.sync()
        except Exception:
            pass
