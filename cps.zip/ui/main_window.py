from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
    QStackedWidget, QButtonGroup, QStatusBar
)
from PySide6.QtCore import Qt, Signal

from ui.pages.dashboard_page import DashboardPage
from ui.pages.students_page import StudentsPage
from ui.pages.officers_page import OfficersPage
from ui.pages.campuses_page import CampusesPage
from ui.pages.buildings_page import BuildingsPage
from ui.pages.patrol_page import PatrolPage
from ui.pages.incidents_page import IncidentsPage
from ui.pages.confiscated_page import ConfiscatedPage
from ui.pages.reports_page import ReportsPage
from ui.pages.analytics_page import AnalyticsPage
from ui.pages.settings_page import SettingsPage
from ui.pages.irl_sign_book_page import IRLSignBookPage
from ui.pages.chat_page import ChatPage
from ui.animations import fade_in_widget


# Sidebar entries: (label, page factory, roles allowed to see it)
# "ALL" means every role can see it.
NAV_ITEMS = [
    ("Dashboard", "dashboard", "ALL"),
    ("Students", "students", "ALL"),
    ("Officers", "officers", {"Administrator", "CAT Commander", "Chief Officer"}),
    ("IRL Sign Book", "irl_sign_book", "OFFICER_ONLY"),
    ("Campuses", "campuses", {"Administrator", "CAT Commander"}),
    ("Buildings", "buildings", {"Administrator", "CAT Commander"}),
    ("Patrol Logs", "patrol", "ALL"),
    ("Incidents", "incidents", "ALL"),
    ("Confiscated Items", "confiscated", "ALL"),
    ("Chat", "chat", "MCAT_ONLY"),
    ("Reports", "reports", {"Administrator", "CAT Commander", "Chief Officer", "Viewer"}),
    ("Analytics", "analytics", {"Administrator", "CAT Commander"}),
    ("Settings", "settings", "ALL"),
]


class MainWindow(QMainWindow):
    logout_requested = Signal()

    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db = db_manager
        self.current_user = current_user

        self.setWindowTitle("CAT Program System")
        self.setMinimumSize(1180, 720)
        self.setAttribute(Qt.WA_DeleteOnClose, True)

        self.pages = {}
        self.nav_buttons = {}

        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self):
        central = QWidget()
        central.setObjectName("centralWidget")
        self.setCentralWidget(central)

        root_layout = QHBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        root_layout.addWidget(self._build_sidebar())

        right_col = QVBoxLayout()
        right_col.setContentsMargins(0, 0, 0, 0)
        right_col.setSpacing(0)
        right_col.addWidget(self._build_topbar())
        right_col.addWidget(self._build_content_stack())

        right_wrapper = QWidget()
        right_wrapper.setLayout(right_col)
        root_layout.addWidget(right_wrapper, 1)

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Ready")

        # Default view
        self._select_nav("dashboard")

    # ------------------------------------------------------------------
    def _build_sidebar(self):
        sidebar = QWidget()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(230)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 10, 0, 10)
        layout.setSpacing(2)

        title = QLabel("CAT Program")
        title.setObjectName("sidebarTitle")
        subtitle = QLabel("SYSTEM")
        subtitle.setObjectName("sidebarSubtitle")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)

        role = self.current_user.get("effective_role", self.current_user["role"])
        for label, key, allowed_roles in NAV_ITEMS:
            if allowed_roles == "OFFICER_ONLY":
                if not self.current_user.get("officer_id"):
                    continue
            elif allowed_roles == "MCAT_ONLY":
                if not self.current_user.get("mcat_code"):
                    continue
            elif allowed_roles != "ALL" and role not in allowed_roles:
                continue
            btn = QPushButton(label)
            btn.setObjectName("navButton")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked, k=key: self._select_nav(k))
            layout.addWidget(btn)
            self.nav_group.addButton(btn)
            self.nav_buttons[key] = btn

        layout.addStretch()

        logout_btn = QPushButton("Log Out")
        logout_btn.setObjectName("navButton")
        logout_btn.setStyleSheet("color: #F0A9A0; font-weight: 600;")
        logout_btn.clicked.connect(self._logout)
        layout.addWidget(logout_btn)

        return sidebar

    # ------------------------------------------------------------------
    def _build_topbar(self):
        topbar = QWidget()
        topbar.setObjectName("topBar")
        topbar.setFixedHeight(58)

        layout = QHBoxLayout(topbar)
        layout.setContentsMargins(24, 0, 24, 0)

        self.page_title_label = QLabel("Dashboard")
        self.page_title_label.setObjectName("pageTitle")
        layout.addWidget(self.page_title_label)
        layout.addStretch()

        user_badge = QLabel(f"{self.current_user['full_name']}  ·  {self.current_user['role']}")
        user_badge.setObjectName("userBadge")
        layout.addWidget(user_badge)

        return topbar

    # ------------------------------------------------------------------
    def _build_content_stack(self):
        self.stack = QStackedWidget()
        self.stack.setObjectName("contentArea")

        self.pages["dashboard"] = DashboardPage(self.db, self.current_user)
        self.pages["students"] = StudentsPage(self.db, self.current_user)
        self.pages["officers"] = OfficersPage(self.db, self.current_user)
        self.pages["irl_sign_book"] = IRLSignBookPage(self.db, self.current_user)
        self.pages["campuses"] = CampusesPage(self.db, self.current_user)
        self.pages["buildings"] = BuildingsPage(self.db, self.current_user)
        self.pages["patrol"] = PatrolPage(self.db, self.current_user)
        self.pages["incidents"] = IncidentsPage(self.db, self.current_user)
        self.pages["confiscated"] = ConfiscatedPage(self.db, self.current_user)
        self.pages["chat"] = ChatPage(self.db, self.current_user)
        self.pages["reports"] = ReportsPage(self.db, self.current_user)
        self.pages["analytics"] = AnalyticsPage(self.db, self.current_user)
        self.pages["settings"] = SettingsPage(self.db, self.current_user)

        for page in self.pages.values():
            self.stack.addWidget(page)

        return self.stack

    # ------------------------------------------------------------------
    def _select_nav(self, key):
        if key not in self.pages:
            return
        page = self.pages[key]
        self.stack.setCurrentWidget(page)
        fade_in_widget(page, duration=200)
        label = next(label for label, k, _ in NAV_ITEMS if k == key)
        self.page_title_label.setText(label)
        if key in self.nav_buttons:
            self.nav_buttons[key].setChecked(True)
        self.statusBar().showMessage(f"Viewing {label}")

    def _mark_chat_presence_offline(self):
        if not self.current_user.get("mcat_code"):
            return
        try:
            from online.supabase_client import get_online
            online = get_online()
            if online.is_available():
                online.set_presence(
                    self.current_user["mcat_code"], self.current_user["id"],
                    self.current_user.get("full_name", ""), online=False,
                )
        except Exception:
            pass  # never let a Chat-presence hiccup block logout/close

    def _logout(self):
        self.db.log_activity(self.current_user["id"], "Logged Out")
        if self.current_user.get("account_type") == "administrator":
            self.db.touch_administrator_online(self.current_user["mcat_code"], online=False)
        self._mark_chat_presence_offline()
        # Explicit logout clears "stay logged in" for this account.
        self.db.clear_remember_token(self.current_user["id"])
        self.logout_requested.emit()
        self.close()

    def closeEvent(self, event):
        # Whether the officer clicks "Log Out" or just closes the window,
        # their attendance record should still be closed out cleanly.
        if self.current_user.get("officer_id"):
            open_record = self.db.get_open_attendance(self.current_user["officer_id"])
            if open_record:
                self.db.officer_clock_out(self.current_user["officer_id"], open_record["id"])
        if self.current_user.get("account_type") == "administrator":
            self.db.touch_administrator_online(self.current_user["mcat_code"], online=False)
        self._mark_chat_presence_offline()
        if "chat" in self.pages:
            self.pages["chat"].shutdown()
        super().closeEvent(event)
