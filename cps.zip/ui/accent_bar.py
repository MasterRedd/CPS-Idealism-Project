"""
ui/accent_bar.py
─────────────────
The "living" accent bar for the CPS login page.

It sits directly under the logo and reacts — via colour, length, glow,
a brief shake, a floating text+emoji bubble, and the odd sparkle — to
what the person is doing on the login screen:

    • idle_admin / idle_officer        baseline colour per account type
    • morning_greet / evening_greet    time-of-day flavoured idle greeting
    • typing_admin / typing_officer    excited greeting while typing a name
    • creator_greet                    respectful greeting for "Creator"
    • detective                       investigative mood while creating
                                       an admin account
    • case_closed                     wraps up the detective moment
    • disappointed / sad / mad        escalating reaction to wrong creds
    • relief                          quick breath before a hard-won success
    • creator_angry1/2/3              escalating anger for a wrong Creator
                                       password (3rd = the program closes)
    • impact                          quick flash timed to the logo's CEffect
    • success                         warm green welcome on a correct login
    • password_shown / password_hidden  reacts to the eye-toggle
    • caps_lock                       warns while typing with Caps Lock on
    • sleepy                          drifts off after a stretch of no input
    • curious                         a little flicker if you hover over it
    • verifying                       brief "thinking" mood while logging in

At rest it also breathes gently — a slow glow pulse — so it never looks
like a dead pixel even when nobody is touching the form.

Usage
─────
    bar = AccentMoodBar()
    layout.addWidget(bar, 0, Qt.AlignHCenter)
    bar.react("typing_admin")
    bar.react("mad")                       # uses preset text + emoji
    bar.react("sad", text_override="…")    # override the preset text
"""

from __future__ import annotations

import math

from PySide6.QtWidgets import QWidget, QLabel, QGraphicsOpacityEffect, QSizePolicy
from PySide6.QtCore import (
    Qt, Property, QPropertyAnimation, QEasingCurve, QTimer, QRectF, QSettings, QPointF,
)
from PySide6.QtGui import QPainter, QColor, QLinearGradient, QPolygonF


class AccentMoodBar(QWidget):
    """Self-contained animated accent bar + floating reaction bubble."""

    _BAR_HEIGHT = 5
    _WIDTH      = 300
    _HEIGHT     = 76
    _BUBBLE_TOP = 2

    # mood name -> (color, length, emoji, text, hold_ms, shake_amplitude)
    MOOD_PRESETS = {
        "idle":            dict(color="#D4AF37", length=50),
        "idle_admin":      dict(color="#4FC3F7", length=56),
        "idle_officer":    dict(color="#43D17A", length=56),

        "morning_greet":   dict(color="#FFC85C", length=70, emoji="☀️",
                                 text="Good morning!", hold=1800),
        "evening_greet":   dict(color="#7C93D9", length=70, emoji="🌙",
                                 text="Working late?", hold=1800),

        "typing_admin":    dict(color="#4FC3F7", length=112, emoji="🤝",
                                 text="Hi there, Admin!", hold=1500),
        "typing_officer":  dict(color="#43D17A", length=112, emoji="👮",
                                 text="Hi there, Officer!", hold=1500),

        "creator_greet":   dict(color="#B388FF", length=180, emoji="🎩",
                                 text="Welcome back, Creator.", hold=2100),

        "detective":       dict(color="#26C6DA", length=132, emoji="🕵️",
                                 text="Verifying your details…", hold=2100),
        "case_closed":     dict(color="#43D17A", length=150, emoji="🎉",
                                 text="Case closed!", hold=1600),

        "disappointed":    dict(color="#E07A00", length=68, emoji="😕",
                                 text="Hmm, that's not right…", hold=1700),
        "sad":             dict(color="#6b7c93", length=52, emoji="😢",
                                 text="Still not matching…", hold=1700),
        "mad":             dict(color="#d9453d", length=94, emoji="😠",
                                 text="Please check carefully!", hold=1800, shake=8),
        "relief":          dict(color="#8BD8BD", length=110, emoji="😅",
                                 text="Phew! Got it.", hold=1100),

        "creator_angry1":  dict(color="#E64A19", length=104, emoji="😠",
                                 text="Wrong password. Careful.", hold=1700, shake=10),
        "creator_angry2":  dict(color="#C62828", length=140, emoji="🤬",
                                 text="That's twice. Last try!", hold=1700, shake=16),
        "creator_angry3":  dict(color="#7B0000", length=230, emoji="💥",
                                 text="That's it. Goodbye.", hold=1600, shake=26),

        "impact":          dict(color="#FFF3B0", length=196, emoji="⚡",
                                 text=None, hold=800, sparkle=True),
        "success":         dict(color="#1E8E3E", length=142, emoji="✅",
                                 text="Welcome in!", hold=1500, sparkle=True),
        "verifying":       dict(color="#4FC3F7", length=88, emoji="🔎",
                                 text="Checking…", hold=900),

        "password_shown":  dict(color="#4FC3F7", length=90, emoji="👁️",
                                 text="Password visible", hold=1100),
        "password_hidden": dict(color="#8FA3BF", length=70, emoji="🙈",
                                 text="Password hidden", hold=1000),

        "caps_lock":       dict(color="#FFB300", length=120, emoji="🔠",
                                 text="Caps Lock is on", hold=1600),
        "sleepy":          dict(color="#4A5A78", length=40, emoji="😴",
                                 text="Still there?", hold=2200),
        "curious":         dict(color="#D4AF37", length=64, emoji="🤔",
                                 text=None, hold=900),
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(self._WIDTH, self._HEIGHT)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.setStyleSheet("background: transparent;")
        self.setAttribute(Qt.WA_Hover, True)

        # ── reduce-motion accessibility flag ────────────────────────────
        try:
            self._reduce_motion = bool(
                QSettings("CPS", "CATProgramSystem").value("reduce_motion", False, type=bool)
            )
        except Exception:
            self._reduce_motion = False

        # ── backing values for animated properties ─────────────────────
        self._bar_color   = QColor("#D4AF37")
        self._bar_len     = 50.0
        self._shake       = 0.0
        self._breathe      = 0.0   # -1..1, drives the idle glow pulse
        self._base_len     = 50.0  # length the breathing loop oscillates around
        self._base_color   = QColor("#D4AF37")

        # ── floating reaction bubble ─────────────────────────────────
        self._bubble = QLabel("", self)
        self._bubble.setAlignment(Qt.AlignCenter)
        self._bubble.setWordWrap(True)
        self._bubble.setStyleSheet("""
            QLabel {
                background-color: rgba(10, 46, 92, 235);
                color: white;
                border-radius: 12px;
                padding: 6px 14px;
                font-size: 12px;
                font-weight: 600;
                border: 1px solid rgba(212, 175, 55, 140);
            }
        """)
        self._bubble.setMaximumWidth(self._WIDTH - 20)
        self._bubble_opacity = QGraphicsOpacityEffect(self._bubble)
        self._bubble_opacity.setOpacity(0.0)
        self._bubble.setGraphicsEffect(self._bubble_opacity)
        self._bubble.hide()
        self._bubble_visible = False

        # ── pending-bubble queue (avoid abrupt interrupts while typing) ─
        self._queue: list[tuple[str, int]] = []

        # ── sparkle particles: list of dicts {x, y, vx, vy, life, max_life} ─
        self._sparkles: list[dict] = []
        self._sparkle_timer = QTimer(self)
        self._sparkle_timer.setInterval(16)
        self._sparkle_timer.timeout.connect(self._tick_sparkles)

        # ── animation refs (kept alive to avoid GC mid-flight) ─────────
        self._color_anim   = None
        self._len_anim      = None
        self._shake_anim    = None
        self._bubble_anim   = None
        self._breathe_anim  = None

        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._fade_bubble_out)

        self._start_breathing()

    # ── Qt animatable properties ────────────────────────────────────────

    def _get_bar_color(self) -> QColor:
        return self._bar_color

    def _set_bar_color(self, c: QColor):
        self._bar_color = QColor(c)
        self.update()

    barColor = Property(QColor, _get_bar_color, _set_bar_color)

    def _get_bar_len(self) -> float:
        return self._bar_len

    def _set_bar_len(self, v: float):
        self._bar_len = max(10.0, float(v))
        self.update()

    barLength = Property(float, _get_bar_len, _set_bar_len)

    def _get_shake(self) -> float:
        return self._shake

    def _set_shake(self, v: float):
        self._shake = float(v)
        self.update()

    shakeOffset = Property(float, _get_shake, _set_shake)

    def _get_breathe(self) -> float:
        return self._breathe

    def _set_breathe(self, v: float):
        self._breathe = float(v)
        # Gently modulate the resting glow; only really visible when idle,
        # since any real reaction immediately overrides barLength anyway.
        self.update()

    breathe = Property(float, _get_breathe, _set_breathe)

    # ── public API ───────────────────────────────────────────────────────

    def react(self, mood: str, text_override: str | None = None,
              emoji_override: str | None = None):
        """Trigger a mood reaction: colour/length shift, optional shake,
        optional floating bubble with text + emoji."""
        preset = self.MOOD_PRESETS.get(mood)
        if not preset:
            return

        self._base_len   = float(preset["length"])
        self._base_color = QColor(preset["color"])
        self._animate_bar(self._base_color, self._base_len)

        shake_amp = 0 if self._reduce_motion else preset.get("shake", 0)
        if shake_amp:
            self._trigger_shake(shake_amp)

        if preset.get("sparkle") and not self._reduce_motion:
            self._spawn_sparkles(self._base_color)

        text  = text_override  if text_override  is not None else preset.get("text")
        emoji = emoji_override if emoji_override is not None else preset.get("emoji")
        if text or emoji:
            combined = f"{emoji + ' ' if emoji else ''}{text or ''}".strip()
            self._queue_bubble(combined, preset.get("hold", 1700))

    def set_reduce_motion(self, enabled: bool):
        self._reduce_motion = bool(enabled)

    # ── idle breathing loop ──────────────────────────────────────────────

    def _start_breathing(self):
        if self._reduce_motion:
            return
        a = QPropertyAnimation(self, b"breathe")
        a.setDuration(3400)
        a.setLoopCount(-1)
        a.setKeyValueAt(0.0, -1.0)
        a.setKeyValueAt(0.5,  1.0)
        a.setKeyValueAt(1.0, -1.0)
        a.setEasingCurve(QEasingCurve.InOutSine)
        self._breathe_anim = a
        a.start()

    # ── internal animation helpers ──────────────────────────────────────

    def _animate_bar(self, color: QColor, length: float):
        if self._color_anim:
            self._color_anim.stop()
        if self._len_anim:
            self._len_anim.stop()

        self._color_anim = QPropertyAnimation(self, b"barColor")
        self._color_anim.setDuration(320)
        self._color_anim.setStartValue(self._bar_color)
        self._color_anim.setEndValue(color)
        self._color_anim.setEasingCurve(QEasingCurve.OutCubic)

        self._len_anim = QPropertyAnimation(self, b"barLength")
        self._len_anim.setDuration(380)
        self._len_anim.setStartValue(self._bar_len)
        self._len_anim.setEndValue(length)
        self._len_anim.setEasingCurve(QEasingCurve.OutBack)

        self._color_anim.start()
        self._len_anim.start()

    def _trigger_shake(self, amplitude: float):
        if self._shake_anim:
            self._shake_anim.stop()
        a = QPropertyAnimation(self, b"shakeOffset")
        a.setDuration(400)
        a.setKeyValueAt(0.0,  0.0)
        a.setKeyValueAt(0.15, -amplitude)
        a.setKeyValueAt(0.35,  amplitude)
        a.setKeyValueAt(0.55, -amplitude * 0.6)
        a.setKeyValueAt(0.75,  amplitude * 0.6)
        a.setKeyValueAt(1.0,  0.0)
        a.setEasingCurve(QEasingCurve.InOutSine)
        self._shake_anim = a
        a.start()

    # ── bubble queueing ──────────────────────────────────────────────────

    def _queue_bubble(self, text: str, hold_ms: int):
        if self._bubble_visible:
            # Don't spam mid-display; keep only the freshest pending one
            # so a burst of keystrokes settles on the last mood, not a
            # jittery replay of every intermediate one.
            self._queue = [(text, hold_ms)]
            return
        self._queue.clear()
        self._show_bubble(text, hold_ms)

    def _show_bubble(self, text: str, hold_ms: int):
        self._hide_timer.stop()
        self._bubble_visible = True

        self._bubble.setText(text)
        self._bubble.adjustSize()
        bw = self._bubble.width()
        self._bubble.move(int((self.width() - bw) / 2), self._BUBBLE_TOP)
        self._bubble.show()
        self._bubble.raise_()

        if self._bubble_anim:
            self._bubble_anim.stop()
        self._bubble_anim = QPropertyAnimation(self._bubble_opacity, b"opacity")
        self._bubble_anim.setDuration(220)
        self._bubble_anim.setStartValue(self._bubble_opacity.opacity())
        self._bubble_anim.setEndValue(1.0)
        self._bubble_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._bubble_anim.start()

        self._hide_timer.start(hold_ms)
        self.update()

    def _fade_bubble_out(self):
        if self._bubble_anim:
            self._bubble_anim.stop()
        self._bubble_anim = QPropertyAnimation(self._bubble_opacity, b"opacity")
        self._bubble_anim.setDuration(320)
        self._bubble_anim.setStartValue(self._bubble_opacity.opacity())
        self._bubble_anim.setEndValue(0.0)
        self._bubble_anim.setEasingCurve(QEasingCurve.InCubic)

        def _done():
            self._bubble.hide()
            self._bubble_visible = False
            self.update()
            if self._queue:
                text, hold_ms = self._queue.pop(0)
                self._show_bubble(text, hold_ms)

        self._bubble_anim.finished.connect(_done)
        self._bubble_anim.start()

    # ── sparkle burst ────────────────────────────────────────────────────

    def _spawn_sparkles(self, color: QColor):
        import random
        cx = self.width() / 2.0
        bar_y = self._HEIGHT - self._BAR_HEIGHT - 6
        for _ in range(14):
            angle = random.uniform(0, math.pi * 2)
            speed = random.uniform(0.6, 2.2)
            self._sparkles.append(dict(
                x=cx, y=bar_y,
                vx=math.cos(angle) * speed,
                vy=math.sin(angle) * speed - 0.6,
                life=1.0,
                color=QColor(color),
                size=random.uniform(1.5, 3.2),
            ))
        if not self._sparkle_timer.isActive():
            self._sparkle_timer.start()

    def _tick_sparkles(self):
        alive = []
        for s in self._sparkles:
            s["x"] += s["vx"]
            s["y"] += s["vy"]
            s["vy"] += 0.05  # gentle gravity
            s["life"] -= 0.045
            if s["life"] > 0:
                alive.append(s)
        self._sparkles = alive
        if not self._sparkles:
            self._sparkle_timer.stop()
        self.update()

    # ── hover reaction ───────────────────────────────────────────────────

    def enterEvent(self, event):
        # Only flicker curiosity when nothing more important is happening.
        if not self._bubble_visible:
            self.react("curious")
        super().enterEvent(event)

    # ── paint ────────────────────────────────────────────────────────────

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        bar_y = self._HEIGHT - self._BAR_HEIGHT - 6
        cx = self.width() / 2.0 + self._shake

        # Idle breathing nudges the rendered length/glow slightly — purely
        # cosmetic, the "real" target length set by react() is _base_len.
        breathe_amt = 0.0 if self._reduce_motion else self._breathe
        eff_len = max(10.0, self._bar_len + breathe_amt * 3.0)
        half = eff_len / 2.0
        rect = QRectF(cx - half, bar_y, eff_len, self._BAR_HEIGHT)

        # soft glow — a few translucent passes behind the solid bar,
        # breathing subtly brighter/dimmer at rest
        glow = QColor(self._bar_color)
        base_alpha = 16 + (int(max(0.0, breathe_amt) * 10) if not self._reduce_motion else 0)
        p.setPen(Qt.NoPen)
        for i in range(4, 0, -1):
            glow.setAlpha(base_alpha)
            gr = rect.adjusted(-i * 3, -i * 1.4, i * 3, i * 1.4)
            p.setBrush(glow)
            p.drawRoundedRect(gr, self._BAR_HEIGHT, self._BAR_HEIGHT)

        # gradient fill — brighter core, darker edges, reads as "glowing"
        grad = QLinearGradient(rect.left(), 0, rect.right(), 0)
        edge = QColor(self._bar_color).darker(160)
        core = QColor(self._bar_color).lighter(130)
        grad.setColorAt(0.0, edge)
        grad.setColorAt(0.5, core)
        grad.setColorAt(1.0, edge)
        p.setBrush(grad)
        p.drawRoundedRect(rect, self._BAR_HEIGHT / 2.0, self._BAR_HEIGHT / 2.0)

        # bubble tail — little triangle connecting bubble to the bar
        if self._bubble_visible and self._bubble.isVisible():
            op = self._bubble_opacity.opacity()
            if op > 0.02:
                bx = self._bubble.x() + self._bubble.width() / 2.0
                by = self._bubble.y() + self._bubble.height()
                tail = QPolygonF([
                    QPointF(bx - 6, by - 1),
                    QPointF(bx + 6, by - 1),
                    QPointF(bx, by + 8),
                ])
                tail_color = QColor(10, 46, 92, int(235 * op))
                p.setBrush(tail_color)
                p.setPen(Qt.NoPen)
                p.drawPolygon(tail)

        # sparkles
        for s in self._sparkles:
            alpha = max(0.0, s["life"])
            c = QColor(s["color"])
            c.setAlpha(int(255 * alpha))
            p.setBrush(c)
            p.setPen(Qt.NoPen)
            r = s["size"]
            p.drawEllipse(QPointF(s["x"], s["y"]), r, r)

        p.end()
