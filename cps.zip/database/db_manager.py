"""
Database Manager
-----------------
This is the ONLY module allowed to talk to SQLite directly.
The UI layer must never import sqlite3 itself — it goes through
the methods exposed here. This keeps the architecture clean and
makes it easy to swap the storage engine later if needed.
"""

import sqlite3
import hashlib
import os
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "cps.db"
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


class DatabaseManager:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON;")
        self._initialize_schema()
        self._migrate_users_role_constraint()
        self._migrate_patrol_and_case_tables()
        self._migrate_confiscated_items_tables()
        self._migrate_role_permissions_table()
        self._migrate_mcat_system()
        self._migrate_chat_outbox_table()
        self._migrate_tenant_scoping()
        self.check_deletion_countdowns()

    def _add_column_if_missing(self, table: str, column: str, ddl_type: str):
        """Safe helper: adds `column` to `table` only if it doesn't already
        exist. Existing databases (created before a column was introduced)
        get it added transparently on next launch; fresh databases already
        have it from schema.sql, so this is just a no-op for them."""
        cols = [r["name"] for r in self._conn.execute(f"PRAGMA table_info({table})")]
        if column not in cols:
            self._conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl_type}")
            self._conn.commit()

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------
    def _initialize_schema(self):
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            script = f.read()
        self._conn.executescript(script)
        self._conn.commit()

    def _migrate_users_role_constraint(self):
        """Older databases were created with a CHECK(role IN (...)) constraint that
        only allowed 5 fixed role names. Admins now need to type custom role names,
        so this rebuilds the users table without that constraint if it's still present.
        Existing rows/data are preserved exactly."""
        row = self._conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='users'"
        ).fetchone()
        if not row or "CHECK" not in (row["sql"] or ""):
            return  # already migrated (or a fresh db created from the updated schema.sql)

        self._conn.executescript(
            """
            BEGIN TRANSACTION;
            ALTER TABLE users RENAME TO users_old_migrating;
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                full_name TEXT NOT NULL,
                role TEXT NOT NULL,
                officer_id INTEGER,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (officer_id) REFERENCES officers(id)
            );
            INSERT INTO users (id, username, password_hash, full_name, role, officer_id, is_active, created_at)
                SELECT id, username, password_hash, full_name, role, officer_id, is_active, created_at
                FROM users_old_migrating;
            DROP TABLE users_old_migrating;
            COMMIT;
            """
        )
        self._conn.commit()

    def _migrate_patrol_and_case_tables(self):
        """Older databases were created before patrol_logs had a soft-delete
        column. case_updates / evidence_locker are already handled by
        CREATE TABLE IF NOT EXISTS in _initialize_schema, since that script
        re-runs on every startup — only ALTER TABLE needs a manual check."""
        cols = [r["name"] for r in self._conn.execute("PRAGMA table_info(patrol_logs)")]
        if "is_deleted" not in cols:
            self._conn.execute(
                "ALTER TABLE patrol_logs ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0"
            )
            self._conn.commit()

    def _migrate_confiscated_items_tables(self):
        """Older databases predate soft-delete on confiscated_items and the
        confiscated_item_id column on evidence_locker (which used to only
        support incidents). Add both if missing; existing data untouched."""
        cols = [r["name"] for r in self._conn.execute("PRAGMA table_info(confiscated_items)")]
        if "is_deleted" not in cols:
            self._conn.execute(
                "ALTER TABLE confiscated_items ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0"
            )
            self._conn.commit()

        cols = [r["name"] for r in self._conn.execute("PRAGMA table_info(evidence_locker)")]
        if "confiscated_item_id" not in cols:
            self._conn.execute(
                "ALTER TABLE evidence_locker ADD COLUMN confiscated_item_id INTEGER"
            )
            self._conn.commit()

    def _migrate_role_permissions_table(self):
        """Older databases predate the role_permissions table used to map a
        custom account role to one of the 5 standard permission tiers."""
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS role_permissions (
                role_name TEXT PRIMARY KEY,
                base_tier TEXT NOT NULL DEFAULT 'Officer'
            )"""
        )
        self._conn.commit()

    def _migrate_chat_outbox_table(self):
        """Older databases predate the Chat feature's offline outbox."""
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS chat_outbox (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_msg_id TEXT NOT NULL UNIQUE,
                mcat_code TEXT NOT NULL,
                scope TEXT NOT NULL,
                sender_id TEXT NOT NULL,
                sender_name TEXT NOT NULL,
                recipient_id TEXT,
                body TEXT,
                attachment_local_path TEXT,
                attachment_type TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                last_error TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            )"""
        )
        self._conn.commit()
        # Reply / forward / already-hosted-attachment support, added
        # alongside Edit/Delete/Reply/Pin/React/Forward — an existing
        # database won't have these columns, so add them if missing.
        cols = [r["name"] for r in self._conn.execute("PRAGMA table_info(chat_outbox)")]
        for col, ddl in (
            ("attachment_url", "TEXT"),
            ("attachment_kb", "INTEGER"),
            ("reply_to_client_id", "TEXT"),
            ("reply_preview", "TEXT"),
            ("reply_sender_name", "TEXT"),
            ("is_forwarded", "INTEGER NOT NULL DEFAULT 0"),
        ):
            if col not in cols:
                self._conn.execute(f"ALTER TABLE chat_outbox ADD COLUMN {col} {ddl}")
        self._conn.commit()

    # The Creator account is never stored in the database — it's the one
    # override login that can see every Administrator across this device
    # (and, once online sync exists, across every device). It cannot edit
    # anything; it can only view and delete Administrator accounts.
    CREATOR_USERNAME = "Creator"
    CREATOR_PASSWORD = "104149111621201120162021"

    def _migrate_mcat_system(self):
        """Adds the Management Code (MCAT) system. Handles two cases:
        1. Fresh database created from the current schema.sql — administrators
           table already exists, users already has the new columns.
        2. Older database — add the missing users columns, create the
           administrators table, and fold the legacy seeded admin/admin123
           account (if present) into a real Administrator with MCAT-1 so
           existing installs keep working instead of being locked out."""
        cols = [r["name"] for r in self._conn.execute("PRAGMA table_info(users)")]
        if "account_type" not in cols:
            self._conn.execute("ALTER TABLE users ADD COLUMN account_type TEXT NOT NULL DEFAULT 'officer'")
        if "mcat_code" not in cols:
            self._conn.execute("ALTER TABLE users ADD COLUMN mcat_code TEXT")
        if "photo_path" not in cols:
            self._conn.execute("ALTER TABLE users ADD COLUMN photo_path TEXT")
        if "remember_token" not in cols:
            self._conn.execute("ALTER TABLE users ADD COLUMN remember_token TEXT")
        self._conn.commit()

        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS administrators (
                mcat_code TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                is_deleted INTEGER NOT NULL DEFAULT 0,
                is_online INTEGER NOT NULL DEFAULT 0,
                last_seen_at TEXT DEFAULT (datetime('now')),
                deletion_scheduled_at TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )"""
        )
        self._conn.commit()

        # Fold the legacy admin/admin123 seed into a real Administrator with
        # MCAT-1, but only once, and only if no administrators exist yet.
        admin_count = self._conn.execute("SELECT COUNT(*) AS c FROM administrators").fetchone()["c"]
        if admin_count == 0:
            legacy = self._conn.execute(
                "SELECT * FROM users WHERE username = 'admin' AND role = 'Administrator'"
            ).fetchone()
            if legacy:
                mcat = "MCAT-1"
                self._conn.execute(
                    "UPDATE users SET account_type = 'administrator', mcat_code = ? WHERE id = ?",
                    (mcat, legacy["id"]),
                )
                self._conn.execute(
                    "INSERT INTO administrators (mcat_code, user_id) VALUES (?, ?)",
                    (mcat, legacy["id"]),
                )
                # Any officer accounts created so far were created under this
                # legacy admin — tie them to MCAT-1 too so their logins keep working.
                self._conn.execute(
                    "UPDATE users SET mcat_code = ? WHERE mcat_code IS NULL AND id != ?",
                    (mcat, legacy["id"]),
                )
                self._conn.commit()

    def _migrate_tenant_scoping(self):
        """Every Administrator's data (campuses, students, officers, patrols,
        incidents, confiscated items) must stay separate from every other
        Administrator's — previously these tables had no owner at all, so
        anyone logging into any account on this device saw everyone else's
        records too. This adds an mcat_code column to each of them.

        Backfill: on a database that already had data before this column
        existed, there's no way to know which admin each old row belonged
        to. Rather than making that data invisible to everyone (which would
        look like data loss), it's assigned to the very first Administrator
        account on this device (MCAT-1) — the same admin who would have
        been the only one able to create it before multi-tenant support
        existed. New rows created after this point are scoped correctly
        from the moment they're created."""
        tables_needing_mcat = [
            "campuses", "buildings", "students", "officers",
            "patrol_logs", "incidents", "confiscated_items",
        ]
        newly_added = []
        for table in tables_needing_mcat:
            cols = [r["name"] for r in self._conn.execute(f"PRAGMA table_info({table})")]
            if "mcat_code" not in cols:
                self._conn.execute(f"ALTER TABLE {table} ADD COLUMN mcat_code TEXT")
                newly_added.append(table)
        self._conn.commit()

        if newly_added:
            first_admin = self._conn.execute(
                "SELECT mcat_code FROM administrators ORDER BY created_at ASC LIMIT 1"
            ).fetchone()
            if first_admin:
                for table in newly_added:
                    self._conn.execute(
                        f"UPDATE {table} SET mcat_code = ? WHERE mcat_code IS NULL",
                        (first_admin["mcat_code"],),
                    )
                self._conn.commit()

    def _actor_mcat(self, actor_user_id):
        """Looks up the Management Code of whoever performed an action, so
        new records (campuses, students, officers, etc.) are automatically
        tagged with the right tenant. Returns None if unknown (e.g. no
        actor_user_id passed) — such records fall back to being visible
        only under the legacy/first admin via the migration above."""
        if not actor_user_id:
            return None
        row = self._conn.execute(
            "SELECT mcat_code FROM users WHERE id = ?", (actor_user_id,)
        ).fetchone()
        return row["mcat_code"] if row else None

    # ------------------------------------------------------------------
    # Management Codes (MCAT) / Administrator accounts
    # ------------------------------------------------------------------
    def generate_next_mcat_code(self) -> str:
        """MCAT numbers are never reused, even after an Administrator is
        deleted, so this counts every administrator ever created rather than
        just active ones. (Locally, for now — once this device can reach a
        real server, that server becomes the source of truth for numbering.)"""
        cur = self._conn.execute("SELECT COUNT(*) AS c FROM administrators")
        n = cur.fetchone()["c"] + 1
        return f"MCAT-{n}"

    def create_administrator_account(self, full_name: str, password: str, photo_path: str = None,
                                      mcat_override: str = None) -> str:
        """mcat_override should be an already-confirmed, globally-unique code
        obtained from register_admin_online() when the device is online.
        Only when that's unavailable (no internet) does this fall back to
        counting local rows — which is provisional and can theoretically
        collide with another offline device's numbering until both are
        online at once. See admin_register_dialog.py for the online-first
        flow this exists to support."""
        mcat = mcat_override or self.generate_next_mcat_code()
        cur = self._conn.execute(
            """INSERT INTO users (username, password_hash, full_name, role, account_type, mcat_code, photo_path)
               VALUES (?, ?, ?, 'Administrator', 'administrator', ?, ?)""",
            (full_name, self.hash_password(password), full_name, mcat, photo_path),
        )
        user_id = cur.lastrowid
        self._conn.execute(
            "INSERT INTO administrators (mcat_code, user_id) VALUES (?, ?)",
            (mcat, user_id),
        )
        self._conn.commit()
        self.log_activity(user_id, "Administrator Account Created", f"{full_name} ({mcat})")
        return mcat

    def get_administrator(self, mcat_code: str):
        row = self._conn.execute(
            """SELECT a.*, u.full_name, u.photo_path, u.username
               FROM administrators a JOIN users u ON u.id = a.user_id
               WHERE a.mcat_code = ?""",
            (mcat_code,),
        ).fetchone()
        return dict(row) if row else None

    def reset_administrator_password(self, mcat_code: str) -> str:
        """Creator-only 'forgot password' path. Generates a new random
        temporary password, saves its hash, and returns the PLAIN password
        once so the Creator can relay it back to the Administrator. Also
        clears any 'stay logged in' token for that account, since the old
        password (and any saved session) should no longer be trusted."""
        import secrets, string
        alphabet = string.ascii_uppercase + string.ascii_lowercase + string.digits
        new_password = "".join(secrets.choice(alphabet) for _ in range(10))
        admin = self.get_administrator(mcat_code)
        if not admin:
            return None
        self._conn.execute(
            "UPDATE users SET password_hash = ?, remember_token = NULL WHERE id = ?",
            (self.hash_password(new_password), admin["user_id"]),
        )
        self._conn.commit()
        return new_password

    def list_administrators(self):
        """For the Creator's view-only dashboard."""
        rows = self._conn.execute(
            """SELECT a.mcat_code, a.is_deleted, a.is_online, a.last_seen_at,
                      a.deletion_scheduled_at, a.created_at,
                      u.id AS user_id, u.full_name, u.photo_path, u.password_hash,
                      (SELECT COUNT(*) FROM users o WHERE o.mcat_code = a.mcat_code
                        AND o.account_type = 'officer' AND o.is_active = 1) AS officer_count
               FROM administrators a JOIN users u ON u.id = a.user_id
               ORDER BY a.created_at"""
        ).fetchall()
        return [dict(r) for r in rows]

    def get_officers_under_mcat(self, mcat_code: str):
        rows = self._conn.execute(
            """SELECT u.id AS user_id, u.username, u.full_name, u.is_active,
                      o.rank, o.position
               FROM users u LEFT JOIN officers o ON o.id = u.officer_id
               WHERE u.mcat_code = ? AND u.account_type = 'officer'
               ORDER BY u.full_name""",
            (mcat_code,),
        ).fetchall()
        return [dict(r) for r in rows]

    def list_chat_contacts(self, mcat_code: str, exclude_user_id=None):
        """Every account under one Management Code — the administrator plus
        every officer — for the Personal Message contact list. A person can
        only message someone who shares their MCAT, by design."""
        rows = self._conn.execute(
            """SELECT id AS user_id, full_name, role, account_type, photo_path
               FROM users
               WHERE mcat_code = ? AND is_active = 1
               ORDER BY (account_type = 'administrator') DESC, full_name""",
            (mcat_code,),
        ).fetchall()
        contacts = [dict(r) for r in rows]
        if exclude_user_id is not None:
            contacts = [c for c in contacts if c["user_id"] != exclude_user_id]
        return contacts

    # ------------------------------------------------------------------
    # Chat outbox (offline queue)
    # ------------------------------------------------------------------
    def queue_chat_outbox(self, client_msg_id, mcat_code, scope, sender_id,
                           sender_name, body=None, recipient_id=None,
                           attachment_local_path=None, attachment_type=None,
                           attachment_url=None, attachment_kb=None,
                           reply_to_client_id=None, reply_preview=None,
                           reply_sender_name=None, is_forwarded=False):
        self._conn.execute(
            """INSERT OR IGNORE INTO chat_outbox
               (client_msg_id, mcat_code, scope, sender_id, sender_name,
                recipient_id, body, attachment_local_path, attachment_type,
                attachment_url, attachment_kb, reply_to_client_id,
                reply_preview, reply_sender_name, is_forwarded)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (client_msg_id, mcat_code, scope, str(sender_id), sender_name,
             str(recipient_id) if recipient_id is not None else None,
             body, attachment_local_path, attachment_type,
             attachment_url, attachment_kb, reply_to_client_id,
             reply_preview, reply_sender_name, 1 if is_forwarded else 0),
        )
        self._conn.commit()

    def get_outbox_for_thread(self, mcat_code, scope, recipient_id=None, sender_id=None):
        """IMPORTANT: always pass sender_id (the currently logged-in user).
        This device's SQLite file is shared by every account under one
        MCAT, so without filtering by sender_id here, a message someone
        else queued while offline (then logged out before it could send)
        would show up in the CURRENT user's thread as if they'd sent it.
        Personal threads are additionally filtered by recipient_id so a
        pending DM to person X never leaks into a thread with person Y."""
        if scope == "personal":
            rows = self._conn.execute(
                """SELECT * FROM chat_outbox WHERE mcat_code = ? AND scope = 'personal'
                   AND recipient_id = ? AND sender_id = ? ORDER BY id""",
                (mcat_code, str(recipient_id), str(sender_id)),
            ).fetchall()
        else:
            rows = self._conn.execute(
                """SELECT * FROM chat_outbox WHERE mcat_code = ? AND scope = 'global'
                   AND sender_id = ? ORDER BY id""",
                (mcat_code, str(sender_id)),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_all_outbox(self):
        rows = self._conn.execute("SELECT * FROM chat_outbox ORDER BY id").fetchall()
        return [dict(r) for r in rows]

    def mark_outbox_failed(self, outbox_id, error_message):
        self._conn.execute(
            "UPDATE chat_outbox SET status = 'failed', last_error = ? WHERE id = ?",
            (error_message, outbox_id),
        )
        self._conn.commit()

    def delete_outbox_message(self, outbox_id):
        """Lets the sender cancel a pending message before it ever goes
        out — once deleted here, nothing is sent when internet returns."""
        self._conn.execute("DELETE FROM chat_outbox WHERE id = ?", (outbox_id,))
        self._conn.commit()

    def get_outbox_by_id(self, outbox_id):
        row = self._conn.execute(
            "SELECT * FROM chat_outbox WHERE id = ?", (outbox_id,)
        ).fetchone()
        return dict(row) if row else None

    def touch_administrator_online(self, mcat_code: str, online: bool):
        self._conn.execute(
            """UPDATE administrators SET is_online = ?, last_seen_at = datetime('now'),
               deletion_scheduled_at = NULL WHERE mcat_code = ?""",
            (1 if online else 0, mcat_code),
        )
        self._conn.commit()

    def cancel_administrator_deletion_countdown(self, mcat_code: str):
        self._conn.execute(
            "UPDATE administrators SET deletion_scheduled_at = NULL, last_seen_at = datetime('now') WHERE mcat_code = ?",
            (mcat_code,),
        )
        self._conn.commit()

    def delete_administrator(self, mcat_code: str, actor_user_id=None):
        """Soft-delete: the MCAT code itself is never reused. The
        Administrator's login and every officer account created under them
        stop working, but their historical records stay intact."""
        admin = self.get_administrator(mcat_code)
        self._conn.execute(
            "UPDATE administrators SET is_deleted = 1, is_online = 0 WHERE mcat_code = ?",
            (mcat_code,),
        )
        self._conn.execute(
            "UPDATE users SET is_active = 0 WHERE mcat_code = ?", (mcat_code,)
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Administrator Deleted",
                           f"{admin['full_name'] if admin else mcat_code} ({mcat_code})")

    def check_deletion_countdowns(self):
        """Run at every startup. 30 days with no login starts a 24-hour
        countdown; if still inactive after that, the account (and every
        officer account under it) is deactivated. The MCAT code is kept,
        marked inactive, so numbering never gets corrupted."""
        rows = self._conn.execute(
            "SELECT mcat_code, last_seen_at, deletion_scheduled_at FROM administrators WHERE is_deleted = 0"
        ).fetchall()
        for r in rows:
            last_seen = r["last_seen_at"]
            scheduled = r["deletion_scheduled_at"]
            if scheduled:
                elapsed = self._conn.execute(
                    "SELECT (strftime('%s','now') - strftime('%s',?)) AS secs", (scheduled,)
                ).fetchone()["secs"]
                if elapsed is not None and elapsed >= 24 * 3600:
                    self.delete_administrator(r["mcat_code"])
                continue
            if last_seen:
                elapsed = self._conn.execute(
                    "SELECT (strftime('%s','now') - strftime('%s',?)) AS secs", (last_seen,)
                ).fetchone()["secs"]
                if elapsed is not None and elapsed >= 30 * 24 * 3600:
                    self._conn.execute(
                        "UPDATE administrators SET deletion_scheduled_at = datetime('now') WHERE mcat_code = ?",
                        (r["mcat_code"],),
                    )
        self._conn.commit()

    def get_deletion_status(self, mcat_code: str):
        """Returns None if no countdown is active, else a dict with hours_left."""
        row = self._conn.execute(
            "SELECT deletion_scheduled_at FROM administrators WHERE mcat_code = ?", (mcat_code,)
        ).fetchone()
        if not row or not row["deletion_scheduled_at"]:
            return None
        elapsed = self._conn.execute(
            "SELECT (strftime('%s','now') - strftime('%s',?)) AS secs", (row["deletion_scheduled_at"],)
        ).fetchone()["secs"]
        hours_left = max(0.0, 24 - (elapsed / 3600.0))
        return {"scheduled_at": row["deletion_scheduled_at"], "hours_left": round(hours_left, 1)}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def hash_password(password: str) -> str:
        # NOTE: For production, replace with a salted algorithm such as
        # bcrypt or argon2. SHA-256 is used here to keep the skeleton
        # dependency-free.
        return hashlib.sha256(password.encode("utf-8")).hexdigest()

    def log_activity(self, user_id, action, details=""):
        self._conn.execute(
            "INSERT INTO activity_logs (user_id, action, details) VALUES (?, ?, ?)",
            (user_id, action, details),
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Users / Authentication
    # ------------------------------------------------------------------
    def create_user(self, username, password, full_name, role, officer_id=None, mcat_code=None):
        self._conn.execute(
            """INSERT INTO users (username, password_hash, full_name, role, officer_id, mcat_code)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (username, self.hash_password(password), full_name, role, officer_id, mcat_code),
        )
        self._conn.commit()

    def authenticate(self, account_type: str, identifier: str, password: str, mcat_code: str = None):
        """account_type is 'administrator' or 'officer'. identifier is the
        Administrator's full name (admin mode) or username (officer mode).
        mcat_code disambiguates accounts that share the same name/username +
        password under different Administrators — required for both account
        types, EXCEPT the Creator override login.

        Returns a user dict (with an added 'effective_role' and, for the
        Creator, account_type='creator') on success, or None."""
        # --- Creator override: no MCAT needed, not a real database row ---
        if account_type == "administrator" and identifier.strip() == self.CREATOR_USERNAME \
                and password == self.CREATOR_PASSWORD:
            return {
                "id": None, "username": self.CREATOR_USERNAME, "full_name": "Creator",
                "role": "Creator", "effective_role": "Creator", "account_type": "creator",
                "officer_id": None, "mcat_code": None,
            }

        if account_type == "administrator":
            cur = self._conn.execute(
                """SELECT u.* FROM users u
                   WHERE u.account_type = 'administrator' AND u.full_name = ?
                         AND u.mcat_code = ? AND u.is_active = 1""",
                (identifier, mcat_code),
            )
        else:
            cur = self._conn.execute(
                """SELECT u.* FROM users u
                   WHERE u.account_type = 'officer' AND u.username = ?
                         AND u.mcat_code = ? AND u.is_active = 1""",
                (identifier, mcat_code),
            )
        row = cur.fetchone()
        if not row or row["password_hash"] != self.hash_password(password):
            return None

        # Make sure the Administrator this account belongs to hasn't been deleted.
        admin_row = self._conn.execute(
            "SELECT is_deleted FROM administrators WHERE mcat_code = ?", (mcat_code,)
        ).fetchone()
        if not admin_row or admin_row["is_deleted"]:
            return None

        user = dict(row)
        user["effective_role"] = self.get_effective_role(user["role"])
        if account_type == "administrator":
            self.touch_administrator_online(mcat_code, online=True)
        return user

    def set_remember_token(self, user_id: int, token: str):
        self._conn.execute("UPDATE users SET remember_token = ? WHERE id = ?", (token, user_id))
        self._conn.commit()

    def get_user_by_remember_token(self, token: str):
        if not token:
            return None
        row = self._conn.execute(
            "SELECT * FROM users WHERE remember_token = ? AND is_active = 1", (token,)
        ).fetchone()
        if not row:
            return None
        user = dict(row)
        user["effective_role"] = self.get_effective_role(user["role"])
        if user["account_type"] == "administrator":
            admin_row = self._conn.execute(
                "SELECT is_deleted FROM administrators WHERE mcat_code = ?", (user["mcat_code"],)
            ).fetchone()
            if not admin_row or admin_row["is_deleted"]:
                return None
            self.touch_administrator_online(user["mcat_code"], online=True)
        return user

    def clear_remember_token(self, user_id: int):
        self._conn.execute("UPDATE users SET remember_token = NULL WHERE id = ?", (user_id,))
        self._conn.commit()

    STANDARD_ROLES = {"Administrator", "CAT Commander", "Chief Officer", "Officer", "Viewer"}

    def get_effective_role(self, role: str) -> str:
        """A custom account role (e.g. 'Squad Leader') doesn't unlock sidebar
        menus on its own — it inherits whichever of the 5 standard tiers the
        admin mapped it to in Settings > Users & Permissions. Standard role
        names always map to themselves. Unmapped custom roles default to
        'Officer' (the most restrictive non-viewer tier)."""
        if role in self.STANDARD_ROLES:
            return role
        row = self._conn.execute(
            "SELECT base_tier FROM role_permissions WHERE role_name = ?", (role,)
        ).fetchone()
        return row["base_tier"] if row else "Officer"

    def set_role_tier(self, role_name: str, base_tier: str, actor_user_id=None):
        self._conn.execute(
            """INSERT INTO role_permissions (role_name, base_tier) VALUES (?, ?)
               ON CONFLICT(role_name) DO UPDATE SET base_tier = excluded.base_tier""",
            (role_name, base_tier),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Role Permission Set", f"{role_name} -> {base_tier}")

    def get_role_tier_map(self) -> dict:
        rows = self._conn.execute("SELECT role_name, base_tier FROM role_permissions").fetchall()
        return {r["role_name"]: r["base_tier"] for r in rows}

    def get_distinct_custom_roles(self):
        """All role names currently in use by an account that aren't one of
        the 5 standard roles — these are the ones Settings needs to map."""
        rows = self._conn.execute("SELECT DISTINCT role FROM users").fetchall()
        return sorted(r["role"] for r in rows if r["role"] not in self.STANDARD_ROLES)

    # ------------------------------------------------------------------
    # Officers (each officer optionally has a linked login account)
    # ------------------------------------------------------------------
    def get_buildings(self, campus_id=None):
        if campus_id:
            cur = self._conn.execute(
                "SELECT * FROM buildings WHERE is_deleted = 0 AND campus_id = ? ORDER BY name",
                (campus_id,),
            )
        else:
            cur = self._conn.execute(
                "SELECT * FROM buildings WHERE is_deleted = 0 ORDER BY name"
            )
        return [dict(r) for r in cur.fetchall()]

    def username_exists(self, username: str, mcat_code: str = None, exclude_user_id: int = None) -> bool:
        """Usernames only need to be unique *within one Administrator's
        Management Code* — the same username can exist under a different
        MCAT without conflict."""
        if exclude_user_id:
            cur = self._conn.execute(
                "SELECT COUNT(*) AS c FROM users WHERE username = ? AND mcat_code = ? AND id != ?",
                (username, mcat_code, exclude_user_id),
            )
        else:
            cur = self._conn.execute(
                "SELECT COUNT(*) AS c FROM users WHERE username = ? AND mcat_code = ?",
                (username, mcat_code),
            )
        return cur.fetchone()["c"] > 0

    def officer_number_exists(self, officer_number: str, exclude_id: int = None) -> bool:
        if exclude_id:
            cur = self._conn.execute(
                "SELECT COUNT(*) AS c FROM officers WHERE officer_number = ? AND id != ?",
                (officer_number, exclude_id),
            )
        else:
            cur = self._conn.execute(
                "SELECT COUNT(*) AS c FROM officers WHERE officer_number = ?",
                (officer_number,),
            )
        return cur.fetchone()["c"] > 0

    def get_officers(self, search: str = "", mcat_code: str = None):
        # NOTE: on_duty here is computed LIVE (open attendance today OR open IRL
        # session today) rather than read from the stored officers.on_duty column.
        # The stored column only tracked app-login attendance, so an officer who
        # was still physically on duty (IRL-signed-in) but simply logged out of
        # the desktop app to free it up would incorrectly show as "not on duty".
        #
        # Tenant scoping: prefer the linked login account's mcat_code (always
        # current), falling back to the officer row's own mcat_code (set at
        # creation) if there's no linked account.
        query = """
            SELECT o.id, o.officer_number, o.full_name, o.photo_path, o.biography,
                   o.birthday, o.gender, o.grade, o.section, o.rank, o.position,
                   o.campus_id, o.assigned_building_id, o.is_active, o.is_deleted,
                   o.created_at,
                   c.name AS campus_name, b.name AS building_name,
                   u.username AS username, u.id AS user_id, u.role AS account_role,
                   COALESCE(u.mcat_code, o.mcat_code) AS mcat_code,
                   CASE WHEN EXISTS (
                       SELECT 1 FROM attendance a
                       WHERE a.officer_id = o.id AND a.date = date('now','localtime')
                             AND a.logout_time IS NULL
                   ) OR EXISTS (
                       SELECT 1 FROM irl_sign_book i
                       WHERE i.officer_id = o.id AND i.date = date('now','localtime')
                             AND i.logout_time IS NULL
                   ) THEN 1 ELSE 0 END AS on_duty
            FROM officers o
            LEFT JOIN campuses c ON c.id = o.campus_id
            LEFT JOIN buildings b ON b.id = o.assigned_building_id
            LEFT JOIN users u ON u.officer_id = o.id
            WHERE o.is_deleted = 0
        """
        params = []
        if mcat_code:
            query += " AND COALESCE(u.mcat_code, o.mcat_code) = ?"
            params.append(mcat_code)
        if search:
            query += " AND (o.full_name LIKE ? OR o.officer_number LIKE ?)"
            like = f"%{search}%"
            params.extend([like, like])
        query += " ORDER BY o.full_name"
        cur = self._conn.execute(query, params)
        return [dict(r) for r in cur.fetchall()]

    def get_officer(self, officer_id: int):
        cur = self._conn.execute("SELECT * FROM officers WHERE id = ?", (officer_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def create_officer_account(self, officer_data: dict, username: str, password: str,
                                role: str = "Officer", actor_user_id=None, mcat_code: str = None):
        """Creates the officer record AND its login account together, linked by officer_id.
        mcat_code ties the new login to whichever Administrator created it —
        an officer needs this code (in addition to username/password) to log in."""
        cur = self._conn.execute(
            """INSERT INTO officers
               (officer_number, full_name, photo_path, gender, birthday, grade, section,
                rank, position, campus_id, assigned_building_id, mcat_code)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                officer_data.get("officer_number"),
                officer_data.get("full_name"),
                officer_data.get("photo_path"),
                officer_data.get("gender"),
                officer_data.get("birthday"),
                officer_data.get("grade"),
                officer_data.get("section"),
                officer_data.get("rank"),
                officer_data.get("position"),
                officer_data.get("campus_id"),
                officer_data.get("assigned_building_id"),
                mcat_code,
            ),
        )
        officer_id = cur.lastrowid
        self._conn.execute(
            """INSERT INTO users (username, password_hash, full_name, role, officer_id, account_type, mcat_code)
               VALUES (?, ?, ?, ?, ?, 'officer', ?)""",
            (username, self.hash_password(password), officer_data.get("full_name"), role, officer_id, mcat_code),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Officer Account Created", officer_data.get("full_name", ""))
        return officer_id

    def update_officer(self, officer_id: int, officer_data: dict, actor_user_id=None,
                        new_password: str = None):
        self._conn.execute(
            """UPDATE officers SET
                officer_number = ?, full_name = ?, photo_path = ?, gender = ?, birthday = ?,
                grade = ?, section = ?, rank = ?, position = ?,
                campus_id = ?, assigned_building_id = ?
               WHERE id = ?""",
            (
                officer_data.get("officer_number"),
                officer_data.get("full_name"),
                officer_data.get("photo_path"),
                officer_data.get("gender"),
                officer_data.get("birthday"),
                officer_data.get("grade"),
                officer_data.get("section"),
                officer_data.get("rank"),
                officer_data.get("position"),
                officer_data.get("campus_id"),
                officer_data.get("assigned_building_id"),
                officer_id,
            ),
        )
        # Keep the linked user's display name in sync
        self._conn.execute(
            "UPDATE users SET full_name = ? WHERE officer_id = ?",
            (officer_data.get("full_name"), officer_id),
        )
        if new_password:
            self._conn.execute(
                "UPDATE users SET password_hash = ? WHERE officer_id = ?",
                (self.hash_password(new_password), officer_id),
            )
        self._conn.commit()
        self.log_activity(actor_user_id, "Officer Updated", officer_data.get("full_name", ""))

    def update_officer_role(self, officer_id: int, role: str, actor_user_id=None):
        """Changes the account role of the officer's linked login account."""
        self._conn.execute("UPDATE users SET role = ? WHERE officer_id = ?", (role, officer_id))
        self._conn.commit()
        self.log_activity(actor_user_id, "Officer Account Role Changed", f"officer_id={officer_id} -> {role}")

    def delete_officer(self, officer_id: int, actor_user_id=None):
        """Soft-deletes the officer and deactivates (not deletes) their login account."""
        row = self._conn.execute(
            "SELECT full_name FROM officers WHERE id = ?", (officer_id,)
        ).fetchone()
        self._conn.execute("UPDATE officers SET is_deleted = 1 WHERE id = ?", (officer_id,))
        self._conn.execute("UPDATE users SET is_active = 0 WHERE officer_id = ?", (officer_id,))
        self._conn.commit()
        self.log_activity(actor_user_id, "Officer Deleted", row["full_name"] if row else "")

    def get_officer_by_user(self, user: dict):
        """Given a logged-in user dict, return their linked officer record, or None."""
        if not user or not user.get("officer_id"):
            return None
        return self.get_officer(user["officer_id"])

    # ------------------------------------------------------------------
    # Attendance — officer login/logout tracking (spec section 10)
    # ------------------------------------------------------------------
    def get_open_attendance(self, officer_id: int):
        """Returns today's still-open (not yet logged out) attendance row, if any."""
        today = datetime.now().strftime("%Y-%m-%d")
        cur = self._conn.execute(
            """SELECT * FROM attendance
               WHERE officer_id = ? AND date = ? AND logout_time IS NULL
               ORDER BY id DESC LIMIT 1""",
            (officer_id, today),
        )
        row = cur.fetchone()
        return dict(row) if row else None

    def officer_clock_in(self, officer_id: int):
        """Clocks an officer in for today. Reuses an already-open record instead of
        creating a duplicate if they're somehow triggered twice in one day."""
        existing = self.get_open_attendance(officer_id)
        if existing:
            return existing["id"]

        today = datetime.now().strftime("%Y-%m-%d")
        now = datetime.now().isoformat(timespec="seconds")
        cur = self._conn.execute(
            "INSERT INTO attendance (officer_id, date, login_time) VALUES (?, ?, ?)",
            (officer_id, today, now),
        )
        self._conn.execute(
            "UPDATE officers SET is_active = 1, on_duty = 1 WHERE id = ?", (officer_id,)
        )
        self._conn.commit()
        self.log_activity(None, "Officer Logged In (Attendance)", f"officer_id={officer_id}")
        return cur.lastrowid

    def officer_clock_out(self, officer_id: int, attendance_id: int):
        now = datetime.now().isoformat(timespec="seconds")
        row = self._conn.execute(
            "SELECT login_time FROM attendance WHERE id = ?", (attendance_id,)
        ).fetchone()
        hours_worked = None
        if row and row["login_time"]:
            start = datetime.fromisoformat(row["login_time"])
            hours_worked = round((datetime.now() - start).total_seconds() / 3600, 2)
        self._conn.execute(
            "UPDATE attendance SET logout_time = ?, hours_worked = ? WHERE id = ?",
            (now, hours_worked, attendance_id),
        )
        self._conn.execute(
            "UPDATE officers SET is_active = 0, on_duty = 0 WHERE id = ?", (officer_id,)
        )
        self._conn.commit()
        self.log_activity(None, "Officer Logged Out (Attendance)", f"officer_id={officer_id}")

    def get_attendance_for_month(self, year: int, month: int):
        """Returns every attendance row within the given month, across all officers."""
        prefix = f"{year:04d}-{month:02d}"
        cur = self._conn.execute(
            "SELECT * FROM attendance WHERE date LIKE ? ORDER BY date", (f"{prefix}%",)
        )
        return [dict(r) for r in cur.fetchall()]

    def get_attendance_for_day(self, date_str: str):
        """Returns every attendance row for one specific calendar day."""
        cur = self._conn.execute(
            "SELECT * FROM attendance WHERE date = ? ORDER BY officer_id", (date_str,)
        )
        return [dict(r) for r in cur.fetchall()]

    def get_attendance_for_year(self, year: int):
        """Returns every attendance row within the given year, across all officers."""
        prefix = f"{year:04d}"
        cur = self._conn.execute(
            "SELECT * FROM attendance WHERE date LIKE ? ORDER BY date", (f"{prefix}%",)
        )
        return [dict(r) for r in cur.fetchall()]

    def update_attendance_manual(self, attendance_id: int, login_time: str, logout_time: str,
                                  actor_user_id=None):
        """Admin correction for a missed or wrong log in/out. Times are ISO strings
        ('YYYY-MM-DDTHH:MM:SS') or None."""
        hours_worked = None
        if login_time and logout_time:
            start = datetime.fromisoformat(login_time)
            end = datetime.fromisoformat(logout_time)
            hours_worked = round((end - start).total_seconds() / 3600, 2)
        self._conn.execute(
            """UPDATE attendance SET login_time = ?, logout_time = ?, hours_worked = ?,
               is_manual_edit = 1, edited_by = ? WHERE id = ?""",
            (login_time, logout_time, hours_worked, actor_user_id, attendance_id),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Attendance Manually Corrected", f"attendance_id={attendance_id}")

    def create_manual_attendance(self, officer_id: int, date: str, login_time: str,
                                  logout_time: str, actor_user_id=None):
        """Adds a brand-new attendance record for a day an officer forgot to log entirely."""
        hours_worked = None
        if login_time and logout_time:
            start = datetime.fromisoformat(login_time)
            end = datetime.fromisoformat(logout_time)
            hours_worked = round((end - start).total_seconds() / 3600, 2)
        cur = self._conn.execute(
            """INSERT INTO attendance (officer_id, date, login_time, logout_time,
               hours_worked, is_manual_edit, edited_by)
               VALUES (?, ?, ?, ?, ?, 1, ?)""",
            (officer_id, date, login_time, logout_time, hours_worked, actor_user_id),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Attendance Manually Added", f"officer_id={officer_id} date={date}")
        return cur.lastrowid

    # ------------------------------------------------------------------
    # Campuses (needed as a dropdown/foreign key for Students)
    # ------------------------------------------------------------------
    def get_campuses(self, mcat_code: str = None):
        if mcat_code:
            cur = self._conn.execute(
                "SELECT * FROM campuses WHERE is_deleted = 0 AND mcat_code = ? ORDER BY name",
                (mcat_code,),
            )
        else:
            cur = self._conn.execute(
                "SELECT * FROM campuses WHERE is_deleted = 0 ORDER BY name"
            )
        return [dict(r) for r in cur.fetchall()]

    def create_campus(self, name, address="", principal="", contact_number="", actor_user_id=None):
        mcat_code = self._actor_mcat(actor_user_id)
        cur = self._conn.execute(
            """INSERT INTO campuses (name, address, principal, contact_number, mcat_code)
               VALUES (?, ?, ?, ?, ?)""",
            (name, address, principal, contact_number, mcat_code),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Campus Added", name)
        return cur.lastrowid

    def get_campus(self, campus_id: int):
        cur = self._conn.execute("SELECT * FROM campuses WHERE id = ?", (campus_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def update_campus(self, campus_id: int, name, address="", principal="",
                       contact_number="", actor_user_id=None):
        self._conn.execute(
            """UPDATE campuses SET name = ?, address = ?, principal = ?, contact_number = ?
               WHERE id = ?""",
            (name, address, principal, contact_number, campus_id),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Campus Updated", name)

    def delete_campus(self, campus_id: int, actor_user_id=None):
        row = self._conn.execute("SELECT name FROM campuses WHERE id = ?", (campus_id,)).fetchone()
        self._conn.execute("UPDATE campuses SET is_deleted = 1 WHERE id = ?", (campus_id,))
        self._conn.commit()
        self.log_activity(actor_user_id, "Campus Deleted", row["name"] if row else "")

    def campus_in_use(self, campus_id: int) -> bool:
        """True if any non-deleted student, officer, or building still references this campus."""
        for table, col in (("students", "campus_id"), ("officers", "campus_id"), ("buildings", "campus_id")):
            cur = self._conn.execute(
                f"SELECT COUNT(*) AS c FROM {table} WHERE {col} = ? AND is_deleted = 0", (campus_id,)
            )
            if cur.fetchone()["c"] > 0:
                return True
        return False

    # ------------------------------------------------------------------
    # Buildings (each belongs to a campus)
    # ------------------------------------------------------------------
    def get_buildings_full(self, search: str = "", mcat_code: str = None):
        """Buildings joined with their campus name, for the Buildings management page."""
        query = """
            SELECT b.*, c.name AS campus_name
            FROM buildings b
            LEFT JOIN campuses c ON c.id = b.campus_id
            WHERE b.is_deleted = 0
        """
        params = []
        if mcat_code:
            query += " AND b.mcat_code = ?"
            params.append(mcat_code)
        if search:
            query += " AND (b.name LIKE ? OR c.name LIKE ? OR b.building_type LIKE ?)"
            like = f"%{search}%"
            params.extend([like, like, like])
        query += " ORDER BY c.name, b.name"
        cur = self._conn.execute(query, params)
        return [dict(r) for r in cur.fetchall()]

    def get_building(self, building_id: int):
        cur = self._conn.execute("SELECT * FROM buildings WHERE id = ?", (building_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def create_building(self, name, campus_id, building_type="", actor_user_id=None):
        mcat_code = self._actor_mcat(actor_user_id)
        cur = self._conn.execute(
            "INSERT INTO buildings (campus_id, name, building_type, mcat_code) VALUES (?, ?, ?, ?)",
            (campus_id, name, building_type, mcat_code),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Building Added", name)
        return cur.lastrowid

    def update_building(self, building_id: int, name, campus_id, building_type="", actor_user_id=None):
        self._conn.execute(
            "UPDATE buildings SET name = ?, campus_id = ?, building_type = ? WHERE id = ?",
            (name, campus_id, building_type, building_id),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Building Updated", name)

    def delete_building(self, building_id: int, actor_user_id=None):
        row = self._conn.execute("SELECT name FROM buildings WHERE id = ?", (building_id,)).fetchone()
        self._conn.execute("UPDATE buildings SET is_deleted = 1 WHERE id = ?", (building_id,))
        self._conn.commit()
        self.log_activity(actor_user_id, "Building Deleted", row["name"] if row else "")

    def building_in_use(self, building_id: int) -> bool:
        """True if any non-deleted officer still references this building."""
        cur = self._conn.execute(
            "SELECT COUNT(*) AS c FROM officers WHERE assigned_building_id = ? AND is_deleted = 0",
            (building_id,),
        )
        return cur.fetchone()["c"] > 0

    # ------------------------------------------------------------------
    # IRL Sign Book — manual, physical duty log kept separate from the
    # app login/logout attendance above. An officer presses "Log In IRL"
    # when they physically arrive on campus and "Log Out IRL" when they
    # leave; a live stopwatch runs the whole time, and the running
    # session survives the app being closed and reopened because the
    # start time is persisted in the database, not held in memory.
    # ------------------------------------------------------------------
    def get_irl_record_for_date(self, officer_id: int, date_str: str):
        cur = self._conn.execute(
            "SELECT * FROM irl_sign_book WHERE officer_id = ? AND date = ? ORDER BY id DESC LIMIT 1",
            (officer_id, date_str),
        )
        row = cur.fetchone()
        return dict(row) if row else None

    def get_irl_today(self, officer_id: int):
        today = datetime.now().strftime("%Y-%m-%d")
        return self.get_irl_record_for_date(officer_id, today)

    def irl_sign_in(self, officer_id: int):
        """Starts today's IRL duty session. Returns the record id, or None if the
        officer already completed (signed out of) their IRL duty for today."""
        today = datetime.now().strftime("%Y-%m-%d")
        existing = self.get_irl_record_for_date(officer_id, today)
        if existing:
            if existing.get("logout_time"):
                return None  # already completed today — can't sign in again until tomorrow
            return existing["id"]  # already signed in — reuse, don't duplicate

        now = datetime.now().isoformat(timespec="seconds")
        cur = self._conn.execute(
            "INSERT INTO irl_sign_book (officer_id, date, login_time) VALUES (?, ?, ?)",
            (officer_id, today, now),
        )
        self._conn.commit()
        self.log_activity(None, "IRL Sign In", f"officer_id={officer_id}")
        return cur.lastrowid

    def irl_sign_out(self, officer_id: int, record_id: int):
        now = datetime.now().isoformat(timespec="seconds")
        row = self._conn.execute(
            "SELECT login_time FROM irl_sign_book WHERE id = ?", (record_id,)
        ).fetchone()
        hours_worked = None
        if row and row["login_time"]:
            start = datetime.fromisoformat(row["login_time"])
            hours_worked = round((datetime.now() - start).total_seconds() / 3600, 2)
        self._conn.execute(
            "UPDATE irl_sign_book SET logout_time = ?, hours_worked = ? WHERE id = ?",
            (now, hours_worked, record_id),
        )
        self._conn.commit()
        self.log_activity(None, "IRL Sign Out", f"officer_id={officer_id}")

    def get_irl_history(self, officer_id: int, limit: int = 31):
        cur = self._conn.execute(
            "SELECT * FROM irl_sign_book WHERE officer_id = ? ORDER BY date DESC LIMIT ?",
            (officer_id, limit),
        )
        return [dict(r) for r in cur.fetchall()]

    def get_irl_for_month(self, year: int, month: int):
        """Every IRL sign book row within the given month, across all officers."""
        prefix = f"{year:04d}-{month:02d}"
        cur = self._conn.execute(
            "SELECT * FROM irl_sign_book WHERE date LIKE ? ORDER BY date", (f"{prefix}%",)
        )
        return [dict(r) for r in cur.fetchall()]

    def get_irl_for_day(self, date_str: str):
        """Every IRL sign book row for one specific calendar day."""
        cur = self._conn.execute(
            "SELECT * FROM irl_sign_book WHERE date = ? ORDER BY officer_id", (date_str,)
        )
        return [dict(r) for r in cur.fetchall()]

    def get_irl_for_year(self, year: int):
        """Every IRL sign book row within the given year, across all officers."""
        prefix = f"{year:04d}"
        cur = self._conn.execute(
            "SELECT * FROM irl_sign_book WHERE date LIKE ? ORDER BY date", (f"{prefix}%",)
        )
        return [dict(r) for r in cur.fetchall()]

    def update_irl_manual(self, record_id: int, login_time: str, logout_time: str, actor_user_id=None):
        """Admin correction for a missed or wrong IRL sign in/out."""
        hours_worked = None
        if login_time and logout_time:
            start = datetime.fromisoformat(login_time)
            end = datetime.fromisoformat(logout_time)
            hours_worked = round((end - start).total_seconds() / 3600, 2)
        self._conn.execute(
            """UPDATE irl_sign_book SET login_time = ?, logout_time = ?, hours_worked = ?,
               is_manual_edit = 1, edited_by = ? WHERE id = ?""",
            (login_time, logout_time, hours_worked, actor_user_id, record_id),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "IRL Sign Book Manually Corrected", f"record_id={record_id}")

    def create_manual_irl(self, officer_id: int, date: str, login_time: str,
                           logout_time: str, actor_user_id=None):
        hours_worked = None
        if login_time and logout_time:
            start = datetime.fromisoformat(login_time)
            end = datetime.fromisoformat(logout_time)
            hours_worked = round((end - start).total_seconds() / 3600, 2)
        cur = self._conn.execute(
            """INSERT INTO irl_sign_book (officer_id, date, login_time, logout_time,
               hours_worked, is_manual_edit, edited_by)
               VALUES (?, ?, ?, ?, ?, 1, ?)""",
            (officer_id, date, login_time, logout_time, hours_worked, actor_user_id),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "IRL Sign Book Manually Added", f"officer_id={officer_id} date={date}")
        return cur.lastrowid

    # ------------------------------------------------------------------
    # Patrol Logs
    # ------------------------------------------------------------------
    def get_patrols(self, search: str = "", status_filter: str = "", mcat_code: str = None):
        query = """
            SELECT p.*, o.full_name AS officer_name,
                   c.name AS campus_name, b.name AS building_name
            FROM patrol_logs p
            LEFT JOIN officers o ON o.id = p.officer_id
            LEFT JOIN campuses c ON c.id = p.campus_id
            LEFT JOIN buildings b ON b.id = p.building_id
            WHERE p.is_deleted = 0
        """
        params = []
        if mcat_code:
            query += " AND p.mcat_code = ?"
            params.append(mcat_code)
        if search:
            query += " AND (o.full_name LIKE ? OR c.name LIKE ? OR b.name LIKE ? OR p.remarks LIKE ?)"
            like = f"%{search}%"
            params.extend([like, like, like, like])
        if status_filter and status_filter != "All":
            query += " AND p.status = ?"
            params.append(status_filter)
        query += " ORDER BY p.time_started DESC"
        cur = self._conn.execute(query, params)
        return [dict(r) for r in cur.fetchall()]

    def get_patrol(self, patrol_id: int):
        cur = self._conn.execute("SELECT * FROM patrol_logs WHERE id = ?", (patrol_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def get_open_patrol_for_officer(self, officer_id: int):
        cur = self._conn.execute(
            "SELECT * FROM patrol_logs WHERE officer_id = ? AND status = 'In Progress' "
            "AND is_deleted = 0 ORDER BY time_started DESC LIMIT 1",
            (officer_id,),
        )
        row = cur.fetchone()
        return dict(row) if row else None

    def start_patrol(self, officer_id: int, campus_id=None, building_id=None, actor_user_id=None):
        mcat_code = self._actor_mcat(actor_user_id)
        cur = self._conn.execute(
            """INSERT INTO patrol_logs (officer_id, campus_id, building_id, time_started, status, mcat_code)
               VALUES (?, ?, ?, datetime('now','localtime'), 'In Progress', ?)""",
            (officer_id, campus_id, building_id, mcat_code),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Patrol Started", f"officer_id={officer_id}")
        return cur.lastrowid

    def end_patrol(self, patrol_id: int, remarks: str = "", actor_user_id=None):
        self._conn.execute(
            """UPDATE patrol_logs SET time_ended = datetime('now','localtime'),
               status = 'Completed', remarks = ? WHERE id = ?""",
            (remarks, patrol_id),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Patrol Finished", f"patrol_id={patrol_id}")

    def create_patrol_manual(self, data: dict, actor_user_id=None):
        mcat_code = self._actor_mcat(actor_user_id)
        cur = self._conn.execute(
            """INSERT INTO patrol_logs
               (officer_id, campus_id, building_id, time_started, time_ended, remarks, status, mcat_code)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("officer_id"),
                data.get("campus_id"),
                data.get("building_id"),
                data.get("time_started"),
                data.get("time_ended"),
                data.get("remarks"),
                "Completed" if data.get("time_ended") else "In Progress",
                mcat_code,
            ),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Patrol Log Added", f"officer_id={data.get('officer_id')}")
        return cur.lastrowid

    def update_patrol(self, patrol_id: int, data: dict, actor_user_id=None):
        self._conn.execute(
            """UPDATE patrol_logs SET
                officer_id = ?, campus_id = ?, building_id = ?,
                time_started = ?, time_ended = ?, remarks = ?, status = ?
               WHERE id = ?""",
            (
                data.get("officer_id"),
                data.get("campus_id"),
                data.get("building_id"),
                data.get("time_started"),
                data.get("time_ended"),
                data.get("remarks"),
                "Completed" if data.get("time_ended") else "In Progress",
                patrol_id,
            ),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Patrol Log Updated", f"patrol_id={patrol_id}")

    def delete_patrol(self, patrol_id: int, actor_user_id=None):
        self._conn.execute("UPDATE patrol_logs SET is_deleted = 1 WHERE id = ?", (patrol_id,))
        self._conn.commit()
        self.log_activity(actor_user_id, "Patrol Log Deleted", f"patrol_id={patrol_id}")

    # ------------------------------------------------------------------
    # Incidents (Case Management)
    # ------------------------------------------------------------------
    def get_incidents(self, search: str = "", stage_filter: str = "", mcat_code: str = None):
        query = """
            SELECT i.*, s.full_name AS student_name, s.student_number,
                   o.full_name AS officer_name,
                   c.name AS campus_name, b.name AS building_name
            FROM incidents i
            LEFT JOIN students s ON s.id = i.student_id
            LEFT JOIN officers o ON o.id = i.officer_id
            LEFT JOIN campuses c ON c.id = i.campus_id
            LEFT JOIN buildings b ON b.id = i.building_id
            WHERE i.is_deleted = 0
        """
        params = []
        if mcat_code:
            query += " AND i.mcat_code = ?"
            params.append(mcat_code)
        if search:
            query += (" AND (s.full_name LIKE ? OR o.full_name LIKE ? OR "
                      "i.category LIKE ? OR i.description LIKE ?)")
            like = f"%{search}%"
            params.extend([like, like, like, like])
        if stage_filter and stage_filter != "All":
            query += " AND i.case_stage = ?"
            params.append(stage_filter)
        query += " ORDER BY i.date DESC"
        cur = self._conn.execute(query, params)
        return [dict(r) for r in cur.fetchall()]

    def get_incident(self, incident_id: int):
        cur = self._conn.execute(
            """SELECT i.*, s.full_name AS student_name, s.student_number,
                      o.full_name AS officer_name,
                      c.name AS campus_name, b.name AS building_name
               FROM incidents i
               LEFT JOIN students s ON s.id = i.student_id
               LEFT JOIN officers o ON o.id = i.officer_id
               LEFT JOIN campuses c ON c.id = i.campus_id
               LEFT JOIN buildings b ON b.id = i.building_id
               WHERE i.id = ?""",
            (incident_id,),
        )
        row = cur.fetchone()
        return dict(row) if row else None

    def create_incident(self, data: dict, actor_user_id=None):
        mcat_code = self._actor_mcat(actor_user_id)
        cur = self._conn.execute(
            """INSERT INTO incidents
               (student_id, officer_id, building_id, campus_id, category,
                severity, description, evidence_path, case_stage, mcat_code)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'New', ?)""",
            (
                data.get("student_id"),
                data.get("officer_id"),
                data.get("building_id"),
                data.get("campus_id"),
                data.get("category"),
                data.get("severity", "Low"),
                data.get("description"),
                data.get("evidence_path"),
                mcat_code,
            ),
        )
        incident_id = cur.lastrowid
        if data.get("student_id"):
            self._conn.execute(
                "UPDATE students SET incident_count = incident_count + 1 WHERE id = ?",
                (data["student_id"],),
            )
        self._conn.commit()
        self.add_case_update(incident_id, actor_user_id, "Case created.", new_stage="New")
        self.log_activity(actor_user_id, "Incident Recorded", data.get("category", ""))
        return incident_id

    def update_incident(self, incident_id: int, data: dict, actor_user_id=None):
        # evidence_path (legacy single-file column) is intentionally left
        # untouched here — multi-photo evidence now lives in evidence_locker
        # and is managed separately via add_evidence/delete_evidence.
        self._conn.execute(
            """UPDATE incidents SET
                student_id = ?, officer_id = ?, building_id = ?, campus_id = ?,
                category = ?, severity = ?, description = ?
               WHERE id = ?""",
            (
                data.get("student_id"),
                data.get("officer_id"),
                data.get("building_id"),
                data.get("campus_id"),
                data.get("category"),
                data.get("severity", "Low"),
                data.get("description"),
                incident_id,
            ),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Incident Updated", data.get("category", ""))

    def get_case_updates(self, incident_id: int):
        cur = self._conn.execute(
            """SELECT cu.*, u.full_name AS user_name
               FROM case_updates cu
               LEFT JOIN users u ON u.id = cu.user_id
               WHERE cu.incident_id = ?
               ORDER BY cu.timestamp ASC""",
            (incident_id,),
        )
        return [dict(r) for r in cur.fetchall()]

    def add_case_update(self, incident_id: int, user_id, update_text: str, new_stage: str = None):
        self._conn.execute(
            """INSERT INTO case_updates (incident_id, user_id, update_text, new_stage)
               VALUES (?, ?, ?, ?)""",
            (incident_id, user_id, update_text, new_stage),
        )
        self._conn.commit()

    def change_case_stage(self, incident_id: int, new_stage: str, note: str = "",
                           resolution: str = None, actor_user_id=None):
        if resolution is not None:
            self._conn.execute(
                "UPDATE incidents SET case_stage = ?, resolution = ? WHERE id = ?",
                (new_stage, resolution, incident_id),
            )
        else:
            self._conn.execute(
                "UPDATE incidents SET case_stage = ? WHERE id = ?", (new_stage, incident_id)
            )
        self._conn.commit()
        text = note.strip() if note and note.strip() else f"Stage changed to {new_stage}."
        self.add_case_update(incident_id, actor_user_id, text, new_stage=new_stage)
        self.log_activity(actor_user_id, "Incident Case Stage Changed",
                           f"incident_id={incident_id} -> {new_stage}")

    # ---- Evidence (multiple images/files per incident) --------------
    def get_evidence_for_incident(self, incident_id: int):
        """Returns all non-deleted evidence files attached to a case,
        oldest first. Also folds in the legacy single `evidence_path`
        column (from before multi-evidence support existed) as a
        synthetic first entry so old incidents don't lose their file."""
        items = []
        incident = self._conn.execute(
            "SELECT evidence_path FROM incidents WHERE id = ?", (incident_id,)
        ).fetchone()
        if incident and incident["evidence_path"]:
            items.append({
                "id": None,
                "incident_id": incident_id,
                "file_path": incident["evidence_path"],
                "description": "",
                "legacy": True,
            })
        cur = self._conn.execute(
            """SELECT * FROM evidence_locker
               WHERE incident_id = ? AND is_deleted = 0
               ORDER BY created_at ASC, id ASC""",
            (incident_id,),
        )
        for row in cur.fetchall():
            d = dict(row)
            d["legacy"] = False
            items.append(d)
        return items

    def add_evidence(self, incident_id: int, file_path: str, description: str = "", added_by=None):
        cur = self._conn.execute(
            """INSERT INTO evidence_locker (incident_id, file_path, description, added_by)
               VALUES (?, ?, ?, ?)""",
            (incident_id, file_path, description, added_by),
        )
        self._conn.commit()
        self.add_case_update(incident_id, added_by, "Evidence attached.")
        self.log_activity(added_by, "Evidence Attached", f"incident_id={incident_id}")
        return cur.lastrowid

    def delete_evidence(self, evidence_id: int, actor_user_id=None):
        row = self._conn.execute(
            "SELECT incident_id FROM evidence_locker WHERE id = ?", (evidence_id,)
        ).fetchone()
        self._conn.execute("UPDATE evidence_locker SET is_deleted = 1 WHERE id = ?", (evidence_id,))
        self._conn.commit()
        if row:
            self.add_case_update(row["incident_id"], actor_user_id, "Evidence removed.")
            self.log_activity(actor_user_id, "Evidence Removed", f"evidence_id={evidence_id}")

    def delete_incident(self, incident_id: int, actor_user_id=None):
        row = self._conn.execute(
            "SELECT student_id, category FROM incidents WHERE id = ?", (incident_id,)
        ).fetchone()
        self._conn.execute("UPDATE incidents SET is_deleted = 1 WHERE id = ?", (incident_id,))
        if row and row["student_id"]:
            self._conn.execute(
                "UPDATE students SET incident_count = MAX(0, incident_count - 1) WHERE id = ?",
                (row["student_id"],),
            )
        self._conn.commit()
        self.log_activity(actor_user_id, "Incident Deleted", row["category"] if row else "")

    # ------------------------------------------------------------------
    # Confiscated Items
    # ------------------------------------------------------------------
    def get_confiscated_items(self, search: str = "", status_filter: str = "", mcat_code: str = None):
        query = """
            SELECT ci.*, s.full_name AS student_name, s.student_number,
                   o.full_name AS officer_name
            FROM confiscated_items ci
            LEFT JOIN students s ON s.id = ci.student_id
            LEFT JOIN officers o ON o.id = ci.officer_id
            WHERE ci.is_deleted = 0
        """
        params = []
        if mcat_code:
            query += " AND ci.mcat_code = ?"
            params.append(mcat_code)
        if search:
            query += (" AND (s.full_name LIKE ? OR o.full_name LIKE ? OR "
                      "ci.item_name LIKE ? OR ci.reason LIKE ?)")
            like = f"%{search}%"
            params.extend([like, like, like, like])
        if status_filter == "Returned":
            query += " AND ci.returned = 1"
        elif status_filter == "Not Returned":
            query += " AND ci.returned = 0"
        query += " ORDER BY ci.date_confiscated DESC"
        cur = self._conn.execute(query, params)
        return [dict(r) for r in cur.fetchall()]

    def get_confiscated_item(self, item_id: int):
        cur = self._conn.execute(
            """SELECT ci.*, s.full_name AS student_name, s.student_number,
                      o.full_name AS officer_name
               FROM confiscated_items ci
               LEFT JOIN students s ON s.id = ci.student_id
               LEFT JOIN officers o ON o.id = ci.officer_id
               WHERE ci.id = ?""",
            (item_id,),
        )
        row = cur.fetchone()
        return dict(row) if row else None

    def create_confiscated_item(self, data: dict, actor_user_id=None):
        mcat_code = self._actor_mcat(actor_user_id)
        cur = self._conn.execute(
            """INSERT INTO confiscated_items
               (student_id, officer_id, item_name, quantity, reason,
                evidence_photo_path, returned, return_date, mcat_code)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("student_id"),
                data.get("officer_id"),
                data.get("item_name"),
                data.get("quantity", 1),
                data.get("reason"),
                data.get("evidence_photo_path"),
                1 if data.get("returned") else 0,
                data.get("return_date"),
                mcat_code,
            ),
        )
        item_id = cur.lastrowid
        self._conn.commit()
        self.log_activity(actor_user_id, "Item Confiscated", data.get("item_name", ""))
        return item_id

    def update_confiscated_item(self, item_id: int, data: dict, actor_user_id=None):
        self._conn.execute(
            """UPDATE confiscated_items SET
                student_id = ?, officer_id = ?, item_name = ?, quantity = ?,
                reason = ?, returned = ?, return_date = ?
               WHERE id = ?""",
            (
                data.get("student_id"),
                data.get("officer_id"),
                data.get("item_name"),
                data.get("quantity", 1),
                data.get("reason"),
                1 if data.get("returned") else 0,
                data.get("return_date"),
                item_id,
            ),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Confiscated Item Updated", data.get("item_name", ""))

    def set_confiscated_item_returned(self, item_id: int, returned: bool, return_date: str = None,
                                       actor_user_id=None):
        self._conn.execute(
            "UPDATE confiscated_items SET returned = ?, return_date = ? WHERE id = ?",
            (1 if returned else 0, return_date, item_id),
        )
        self._conn.commit()
        action = "Item Marked Returned" if returned else "Item Marked Not Returned"
        self.log_activity(actor_user_id, action, f"confiscated_item_id={item_id}")

    def delete_confiscated_item(self, item_id: int, actor_user_id=None):
        row = self._conn.execute(
            "SELECT item_name FROM confiscated_items WHERE id = ?", (item_id,)
        ).fetchone()
        self._conn.execute("UPDATE confiscated_items SET is_deleted = 1 WHERE id = ?", (item_id,))
        self._conn.commit()
        self.log_activity(actor_user_id, "Confiscated Item Deleted", row["item_name"] if row else "")

    # ---- Evidence (multiple images per confiscated item) -------------
    def get_evidence_for_confiscated_item(self, item_id: int):
        """Mirrors get_evidence_for_incident: folds in the legacy single
        evidence_photo_path column as a synthetic first entry."""
        items = []
        row = self._conn.execute(
            "SELECT evidence_photo_path FROM confiscated_items WHERE id = ?", (item_id,)
        ).fetchone()
        if row and row["evidence_photo_path"]:
            items.append({
                "id": None,
                "confiscated_item_id": item_id,
                "file_path": row["evidence_photo_path"],
                "description": "",
                "legacy": True,
            })
        cur = self._conn.execute(
            """SELECT * FROM evidence_locker
               WHERE confiscated_item_id = ? AND is_deleted = 0
               ORDER BY created_at ASC, id ASC""",
            (item_id,),
        )
        for r in cur.fetchall():
            d = dict(r)
            d["legacy"] = False
            items.append(d)
        return items

    def add_confiscated_evidence(self, item_id: int, file_path: str, description: str = "", added_by=None):
        cur = self._conn.execute(
            """INSERT INTO evidence_locker (confiscated_item_id, file_path, description, added_by)
               VALUES (?, ?, ?, ?)""",
            (item_id, file_path, description, added_by),
        )
        self._conn.commit()
        self.log_activity(added_by, "Evidence Attached", f"confiscated_item_id={item_id}")
        return cur.lastrowid

    def delete_confiscated_evidence(self, evidence_id: int, actor_user_id=None):
        self._conn.execute("UPDATE evidence_locker SET is_deleted = 1 WHERE id = ?", (evidence_id,))
        self._conn.commit()
        self.log_activity(actor_user_id, "Evidence Removed", f"evidence_id={evidence_id}")

    # ------------------------------------------------------------------
    # Students
    # ------------------------------------------------------------------
    def get_students(self, search: str = "", mcat_code: str = None):
        """Returns non-deleted students, optionally filtered by name/number, with campus name joined in."""
        query = """
            SELECT s.*, c.name AS campus_name
            FROM students s
            LEFT JOIN campuses c ON c.id = s.campus_id
            WHERE s.is_deleted = 0
        """
        params = []
        if mcat_code:
            query += " AND s.mcat_code = ?"
            params.append(mcat_code)
        if search:
            query += " AND (s.full_name LIKE ? OR s.student_number LIKE ?)"
            like = f"%{search}%"
            params.extend([like, like])
        query += " ORDER BY s.full_name"
        cur = self._conn.execute(query, params)
        return [dict(r) for r in cur.fetchall()]

    def get_student(self, student_id: int):
        cur = self._conn.execute("SELECT * FROM students WHERE id = ?", (student_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def student_number_exists(self, student_number: str, exclude_id: int = None) -> bool:
        if exclude_id:
            cur = self._conn.execute(
                "SELECT COUNT(*) AS c FROM students WHERE student_number = ? AND id != ?",
                (student_number, exclude_id),
            )
        else:
            cur = self._conn.execute(
                "SELECT COUNT(*) AS c FROM students WHERE student_number = ?",
                (student_number,),
            )
        return cur.fetchone()["c"] > 0

    def create_student(self, data: dict, actor_user_id=None):
        mcat_code = self._actor_mcat(actor_user_id)
        self._conn.execute(
            """INSERT INTO students
               (student_number, full_name, gender, birthday, photo_path,
                grade, section, adviser, campus_id, status, notes, mcat_code)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("student_number"),
                data.get("full_name"),
                data.get("gender"),
                data.get("birthday"),
                data.get("photo_path"),
                data.get("grade"),
                data.get("section"),
                data.get("adviser"),
                data.get("campus_id"),
                data.get("status", "Good Standing"),
                data.get("notes"),
                mcat_code,
            ),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Student Added", data.get("full_name", ""))

    def update_student(self, student_id: int, data: dict, actor_user_id=None):
        self._conn.execute(
            """UPDATE students SET
                student_number = ?, full_name = ?, gender = ?, birthday = ?,
                photo_path = ?, grade = ?, section = ?, adviser = ?,
                campus_id = ?, status = ?, notes = ?
               WHERE id = ?""",
            (
                data.get("student_number"),
                data.get("full_name"),
                data.get("gender"),
                data.get("birthday"),
                data.get("photo_path"),
                data.get("grade"),
                data.get("section"),
                data.get("adviser"),
                data.get("campus_id"),
                data.get("status", "Good Standing"),
                data.get("notes"),
                student_id,
            ),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Student Updated", data.get("full_name", ""))

    def delete_student(self, student_id: int, actor_user_id=None):
        """Soft delete — sets is_deleted = 1 rather than removing the row."""
        row = self._conn.execute(
            "SELECT full_name FROM students WHERE id = ?", (student_id,)
        ).fetchone()
        self._conn.execute("UPDATE students SET is_deleted = 1 WHERE id = ?", (student_id,))
        self._conn.commit()
        self.log_activity(actor_user_id, "Student Deleted", row["full_name"] if row else "")

    # ------------------------------------------------------------------
    # Generic fetch helpers (used by stub pages / dashboard counts)
    # ------------------------------------------------------------------
    def count(self, table: str, mcat_code: str = None) -> int:
        where_parts = []
        if self._has_soft_delete(table):
            where_parts.append("is_deleted = 0")
        if mcat_code and self._has_column(table, "mcat_code"):
            where_parts.append("mcat_code = :mcat")
        elif mcat_code and table == "activity_logs":
            # activity_logs has no mcat_code of its own — scope through the
            # user who performed the action instead.
            cur = self._conn.execute(
                "SELECT COUNT(*) AS c FROM activity_logs a JOIN users u ON u.id = a.user_id "
                "WHERE u.mcat_code = ?",
                (mcat_code,),
            )
            return cur.fetchone()["c"]
        where_sql = f" WHERE {' AND '.join(where_parts)}" if where_parts else ""
        cur = self._conn.execute(f"SELECT COUNT(*) AS c FROM {table}{where_sql}",
                                  {"mcat": mcat_code} if mcat_code else {})
        return cur.fetchone()["c"]

    def _has_soft_delete(self, table: str) -> bool:
        return self._has_column(table, "is_deleted")

    def _has_column(self, table: str, column: str) -> bool:
        cols = [r["name"] for r in self._conn.execute(f"PRAGMA table_info({table})")]
        return column in cols

    def fetch_all(self, table: str, mcat_code: str = None):
        if mcat_code and table == "activity_logs":
            # Scope activity to accounts under the current Management Code
            # only — otherwise every administrator/officer on this device
            # would see every other tenant's activity feed.
            cur = self._conn.execute(
                """SELECT a.* FROM activity_logs a
                   JOIN users u ON u.id = a.user_id
                   WHERE u.mcat_code = ?
                   ORDER BY a.id DESC""",
                (mcat_code,),
            )
            return [dict(r) for r in cur.fetchall()]
        if mcat_code and self._has_column(table, "mcat_code"):
            cur = self._conn.execute(f"SELECT * FROM {table} WHERE mcat_code = ?", (mcat_code,))
            return [dict(r) for r in cur.fetchall()]
        cur = self._conn.execute(f"SELECT * FROM {table}")
        return [dict(r) for r in cur.fetchall()]

    def close(self):
        self._conn.close()

    # ------------------------------------------------------------------
    # Settings (generic key/value store — school info, appearance, etc.)
    # ------------------------------------------------------------------
    def get_setting(self, key: str, default=None):
        row = self._conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default

    def get_settings(self, keys: list) -> dict:
        return {k: self.get_setting(k) for k in keys}

    def set_setting(self, key: str, value: str):
        self._conn.execute(
            """INSERT INTO settings (key, value) VALUES (?, ?)
               ON CONFLICT(key) DO UPDATE SET value = excluded.value""",
            (key, value),
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Users & Permissions (Settings module)
    # ------------------------------------------------------------------
    def get_all_accounts(self, search: str = ""):
        """Every login account in the system, admin or officer-linked alike."""
        query = """
            SELECT u.id, u.username, u.full_name, u.role, u.officer_id, u.is_active,
                   u.created_at, o.officer_number, o.photo_path
            FROM users u
            LEFT JOIN officers o ON o.id = u.officer_id
        """
        params = []
        if search:
            query += " WHERE u.full_name LIKE ? OR u.username LIKE ?"
            like = f"%{search}%"
            params.extend([like, like])
        query += " ORDER BY u.full_name"
        cur = self._conn.execute(query, params)
        return [dict(r) for r in cur.fetchall()]

    def set_account_active(self, user_id: int, is_active: bool, actor_user_id=None):
        self._conn.execute("UPDATE users SET is_active = ? WHERE id = ?", (1 if is_active else 0, user_id))
        self._conn.commit()
        self.log_activity(actor_user_id, "Account " + ("Activated" if is_active else "Deactivated"), f"user_id={user_id}")

    def reset_account_password(self, user_id: int, new_password: str, actor_user_id=None):
        self._conn.execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            (self.hash_password(new_password), user_id),
        )
        self._conn.commit()
        self.log_activity(actor_user_id, "Password Reset", f"user_id={user_id}")

    # ------------------------------------------------------------------
    # Backup / Restore
    # ------------------------------------------------------------------
    def backup_database(self, dest_dir: Path, actor_user_id=None) -> Path:
        import shutil
        dest_dir = Path(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        dest_path = dest_dir / f"cps_backup_{stamp}.db"
        self._conn.commit()
        shutil.copy2(self.db_path, dest_path)
        self.log_activity(actor_user_id, "Backup Created", str(dest_path))
        return dest_path

    def list_backups(self, backup_dir: Path):
        backup_dir = Path(backup_dir)
        if not backup_dir.exists():
            return []
        files = sorted(backup_dir.glob("cps_backup_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        return files

    def restore_database(self, backup_path: Path, actor_user_id=None):
        """Restores from a backup file. Caller must restart the app afterwards
        since the live SQLite connection needs to be reopened against the
        restored file."""
        import shutil
        self.log_activity(actor_user_id, "Database Restored", str(backup_path))
        self._conn.commit()
        self._conn.close()
        shutil.copy2(backup_path, self.db_path)
        # Reopen so the current session keeps working until the app restarts
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON;")

    # ------------------------------------------------------------------
    # Officer full profile (used to build the ID Card)
    # ------------------------------------------------------------------
    def get_officer_profile_by_number(self, officer_number: str):
        row = self._conn.execute(
            "SELECT id FROM officers WHERE officer_number = ? AND is_deleted = 0", (officer_number,)
        ).fetchone()
        if not row:
            return None
        return self.get_officer_profile(row["id"])

    def get_officer_profile(self, officer_id: int):
        cur = self._conn.execute(
            """SELECT o.*, c.name AS campus_name, b.name AS building_name,
                      u.username AS username, u.role AS account_role, u.id AS user_id,
                      u.mcat_code AS mcat_code
               FROM officers o
               LEFT JOIN campuses c ON c.id = o.campus_id
               LEFT JOIN buildings b ON b.id = o.assigned_building_id
               LEFT JOIN users u ON u.officer_id = o.id
               WHERE o.id = ?""",
            (officer_id,),
        ).fetchone()
        return dict(cur) if cur else None
