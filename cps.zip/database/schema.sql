-- CAT Program System (CPS) — Database Schema

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,           -- no longer globally unique: two different
                                       -- Management Codes (MCAT) can each have their
                                       -- own admin/officer with the same username
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL,               -- free text; admin can type any custom role/title
    officer_id INTEGER,               -- optional link to officers table
    is_active INTEGER NOT NULL DEFAULT 1,
    account_type TEXT NOT NULL DEFAULT 'officer',  -- 'administrator' | 'officer'
    mcat_code TEXT,                   -- Management Code this account belongs to
    photo_path TEXT,
    remember_token TEXT,              -- set when "stay logged in" is checked
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (officer_id) REFERENCES officers(id)
);

-- One row per Administrator account ever created (locally, for now). The
-- mcat_code here is never reused even after deletion, so numbering stays
-- consistent once this device eventually syncs with a real server.
CREATE TABLE IF NOT EXISTS administrators (
    mcat_code TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    is_deleted INTEGER NOT NULL DEFAULT 0,
    is_online INTEGER NOT NULL DEFAULT 0,
    last_seen_at TEXT DEFAULT (datetime('now')),
    deletion_scheduled_at TEXT,       -- set once 30 days inactive; deleted 24h after
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS campuses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT,
    principal TEXT,
    contact_number TEXT,
    mcat_code TEXT,                    -- which Administrator's org this belongs to
    is_deleted INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS buildings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campus_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    building_type TEXT,               -- e.g. Academic, Gym, Library, Clinic
    mcat_code TEXT,
    is_deleted INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (campus_id) REFERENCES campuses(id)
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_number TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    gender TEXT,
    birthday TEXT,
    photo_path TEXT,
    grade TEXT,
    section TEXT,
    adviser TEXT,
    campus_id INTEGER,
    mcat_code TEXT,
    status TEXT DEFAULT 'Good Standing',   -- e.g. Good Standing, Suspicious, Suspended
    incident_count INTEGER NOT NULL DEFAULT 0,
    community_service_hours REAL NOT NULL DEFAULT 0,
    notes TEXT,
    is_deleted INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (campus_id) REFERENCES campuses(id)
);

CREATE TABLE IF NOT EXISTS officers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    officer_number TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    photo_path TEXT,
    biography TEXT,
    birthday TEXT,
    gender TEXT,
    grade TEXT,
    section TEXT,
    rank TEXT,
    position TEXT,
    campus_id INTEGER,
    assigned_building_id INTEGER,
    mcat_code TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    on_duty INTEGER NOT NULL DEFAULT 0,
    is_deleted INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (campus_id) REFERENCES campuses(id),
    FOREIGN KEY (assigned_building_id) REFERENCES buildings(id)
);

CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    officer_id INTEGER NOT NULL,
    date TEXT NOT NULL,               -- YYYY-MM-DD, the calendar day this record belongs to
    login_time TEXT,
    logout_time TEXT,
    hours_worked REAL,
    is_manual_edit INTEGER NOT NULL DEFAULT 0,
    edited_by INTEGER,                -- admin/user who manually corrected this record, if any
    FOREIGN KEY (officer_id) REFERENCES officers(id),
    FOREIGN KEY (edited_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS patrol_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    officer_id INTEGER NOT NULL,
    campus_id INTEGER,
    building_id INTEGER,
    time_started TEXT,
    time_ended TEXT,
    remarks TEXT,
    status TEXT DEFAULT 'In Progress', -- In Progress, Completed
    mcat_code TEXT,
    is_deleted INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (officer_id) REFERENCES officers(id),
    FOREIGN KEY (campus_id) REFERENCES campuses(id),
    FOREIGN KEY (building_id) REFERENCES buildings(id)
);

CREATE TABLE IF NOT EXISTS incidents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    officer_id INTEGER,
    building_id INTEGER,
    campus_id INTEGER,
    date TEXT DEFAULT (datetime('now')),
    category TEXT,
    severity TEXT CHECK(severity IN ('Low','Medium','High','Critical')) DEFAULT 'Low',
    description TEXT,
    evidence_path TEXT,
    resolution TEXT,
    case_stage TEXT CHECK(case_stage IN ('New','Under Review','Resolved','Closed')) DEFAULT 'New',
    mcat_code TEXT,
    is_deleted INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (officer_id) REFERENCES officers(id),
    FOREIGN KEY (building_id) REFERENCES buildings(id),
    FOREIGN KEY (campus_id) REFERENCES campuses(id)
);

CREATE TABLE IF NOT EXISTS case_updates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id INTEGER NOT NULL,
    user_id INTEGER,
    update_text TEXT,
    new_stage TEXT,               -- set when this update also changed the case stage
    timestamp TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (incident_id) REFERENCES incidents(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Shared multi-photo evidence table. A row belongs to either an incident
-- (incident_id) or a confiscated item (confiscated_item_id), never both.
CREATE TABLE IF NOT EXISTS evidence_locker (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id INTEGER,
    confiscated_item_id INTEGER,
    file_path TEXT,
    description TEXT,
    added_by INTEGER,
    is_deleted INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (incident_id) REFERENCES incidents(id),
    FOREIGN KEY (confiscated_item_id) REFERENCES confiscated_items(id),
    FOREIGN KEY (added_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS confiscated_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    officer_id INTEGER,
    item_name TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    reason TEXT,
    evidence_photo_path TEXT,
    returned INTEGER NOT NULL DEFAULT 0,
    return_date TEXT,
    date_confiscated TEXT DEFAULT (datetime('now')),
    mcat_code TEXT,
    is_deleted INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (officer_id) REFERENCES officers(id)
);

CREATE TABLE IF NOT EXISTS irl_sign_book (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    officer_id INTEGER NOT NULL,
    date TEXT NOT NULL,               -- YYYY-MM-DD, the calendar day this record belongs to
    login_time TEXT,
    logout_time TEXT,
    hours_worked REAL,
    is_manual_edit INTEGER NOT NULL DEFAULT 0,
    edited_by INTEGER,                -- admin/user who manually corrected this record, if any
    FOREIGN KEY (officer_id) REFERENCES officers(id),
    FOREIGN KEY (edited_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT NOT NULL,
    details TEXT,
    timestamp TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- Maps a free-text custom account role (e.g. "Squad Leader") to one of the
-- 5 standard permission tiers so it unlocks the right sidebar menus/actions.
-- The 5 standard role names themselves never need an entry here.
CREATE TABLE IF NOT EXISTS role_permissions (
    role_name TEXT PRIMARY KEY,
    base_tier TEXT NOT NULL DEFAULT 'Officer'
);

-- Chat messages waiting to be sent to Supabase because there was no
-- internet (or the send failed) at the moment "Send" was clicked. Cleared
-- automatically the moment a background sync successfully delivers them.
-- The user can also delete a pending row themselves before it goes out —
-- that's the "sent nothing once wifi comes back" behavior that was asked for.
CREATE TABLE IF NOT EXISTS chat_outbox (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_msg_id TEXT NOT NULL UNIQUE,
    mcat_code TEXT NOT NULL,
    scope TEXT NOT NULL,               -- 'global' | 'personal'
    sender_id TEXT NOT NULL,
    sender_name TEXT NOT NULL,
    recipient_id TEXT,
    body TEXT,
    attachment_local_path TEXT,        -- original file, uploaded on flush
    attachment_type TEXT,              -- 'image' | 'video' | NULL
    attachment_url TEXT,               -- already-hosted (e.g. forwarding a
                                        -- message that's already uploaded) —
                                        -- skips a redundant re-upload
    attachment_kb INTEGER,
    reply_to_client_id TEXT,           -- set when this message is a reply
    reply_preview TEXT,
    reply_sender_name TEXT,
    is_forwarded INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending',  -- 'pending' | 'failed'
    last_error TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
