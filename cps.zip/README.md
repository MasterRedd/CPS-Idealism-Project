# CAT Program System (CPS)

Offline Windows desktop app for managing a school's Citizenship Advancement Training
(CAT). Built with Python 3 + PySide6 (Qt6) + SQLite.

This is the **v0.3 build**: navigation, database schema, authentication,
the dashboard, the **Students module**, and the **Officers module with a
full attendance system** are working. Every other module (Campuses,
Buildings, Patrol Logs, Incidents, Confiscated Items, Reports, Analytics,
Settings) is still a wired-up placeholder page, ready to be filled in one
at a time using Students/Officers as the pattern to copy.

## Officer accounts & attendance (new in v0.3)

- Admin creates each officer through **Officers → + Add Officer**. This
  creates the officer record *and* a linked login account (username +
  password) in one step — officers never log in with the admin account.
- The moment an officer signs in with their own account, the app clocks
  them in automatically (`db.officer_clock_in`). Signing out — or just
  closing the window — clocks them out and records hours worked
  (`db.officer_clock_out`). Logging in twice in the same day reuses the
  existing open record instead of creating a duplicate.
- **Officers → 📅 Monthly Attendance** shows every officer across the
  selected month. Weekdays with no record are automatically marked
  **Absent**. Double-clicking any weekday cell — whether it already has a
  record or not — lets an admin set/correct the login and logout time
  (covers "officer came to school but forgot to log in/out").
- Manual corrections are flagged (`is_manual_edit`) and attributed
  (`edited_by`) so there's an audit trail of who changed what.

## Running it

```bash
pip install -r requirements.txt
python main.py
```

Default login (created automatically on first run):

```
username: admin
password: admin123
```

**Change this password immediately once the Settings module supports user
management** — it's a placeholder for development only.

## Project layout

```
cps/
├── main.py                  # Entry point: splash -> login -> main window
├── database/
│   ├── db_manager.py        # The ONLY module that talks to SQLite
│   └── schema.sql           # Full table definitions
├── ui/
│   ├── splash_screen.py
│   ├── login_window.py
│   ├── main_window.py        # Sidebar + top bar + page routing
│   └── pages/
│       ├── base_page.py      # Shared "StubPage" placeholder widget
│       ├── dashboard_page.py # Real, wired to live DB counts
│       ├── students_page.py
│       ├── officers_page.py
│       ├── campuses_page.py
│       ├── buildings_page.py
│       ├── patrol_page.py
│       ├── incidents_page.py
│       ├── confiscated_page.py
│       ├── reports_page.py
│       ├── analytics_page.py
│       └── settings_page.py
├── resources/
│   └── style.qss             # Global dark-sidebar / light-content theme
├── data/
│   └── cps.db                 # Created automatically on first run
└── requirements.txt
```

## Architecture rule

The UI layer never touches `sqlite3` directly. Every page receives a
`DatabaseManager` instance and calls methods on it (`db.fetch_all(...)`,
`db.count(...)`, etc.). Add new query methods to `db_manager.py` as each
module gets built out — that keeps a single, auditable data-access layer,
which matters a lot once role permissions and soft-deletes come into play.

## Role-based navigation

`ui/main_window.py` defines which roles can see which sidebar items in the
`NAV_ITEMS` list. Right now this only controls *visibility* — it does not
yet stop a user from calling a restricted action directly. Real permission
enforcement should happen in `db_manager.py` (e.g. check `current_user.role`
before allowing a delete), not just in the UI.

## Suggested build order (matches the original roadmap)

1. ✅ **Students module**
2. ✅ **Officers module** — accounts, attendance, monthly report, manual
   correction. Use this + Students as the template for everything below.
3. **Campuses & Buildings** — simple CRUD; Officers/Students already have
   working dropdowns for both (`db.get_campuses()`, `db.get_buildings()`,
   `db.create_campus()`), so this mainly needs its own management screen
4. **Patrols & Incidents** — Incidents should implement the case-stage
   workflow (New → Under Review → Resolved → Closed) already present in
   the `incidents` table schema
5. **Confiscated Items**
6. **Reports** (PDF export — `reportlab` or `fpdf2` recommended)
7. **Analytics** (charts — `matplotlib` embedded in a `QWidget`, or
   `QtCharts`)
8. **Settings** — school info, backup/restore, user management
9. Packaging: `pyinstaller --onefile --windowed main.py`

## About mobile + offline sync (future phase, not in this build)

This is a desktop-only PySide6 app. A phone app for officers to
clock in/out — including working offline and syncing once connectivity
returns — would be a **separate application** built with a mobile
framework (Flutter / React Native / native), talking to a small backend
API over a real database (e.g. Postgres) instead of this local SQLite
file. The attendance schema here (`date`, `login_time`, `logout_time`,
`is_manual_edit`, `edited_by`) was designed to translate cleanly into that
setup later — the hard part of that project is the sync/conflict-resolution
layer, not the data model.

## Notes / things to harden before real deployment

- Passwords are hashed with SHA-256 for simplicity. Swap in `bcrypt` or
  `argon2-cffi` before this touches real student data.
- Soft-delete columns (`is_deleted`) already exist on the sensitive
  tables — use them instead of `DELETE` wherever an Administrator isn't
  explicitly force-purging.
- Add a `backup_database()` method to `DatabaseManager` that copies
  `data/cps.db` to a timestamped file before big operations.
