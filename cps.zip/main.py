"""
CAT Program System (CPS) — Entry Point
----------------------------------------
Boot sequence: Splash Screen -> Database Init -> Login -> Main Dashboard.
Logging out returns the user to the Login screen rather than closing the app.
"""

import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from PySide6.QtGui import QPalette, QColor

sys.path.insert(0, str(Path(__file__).resolve().parent))

from database.db_manager import DatabaseManager
from ui.splash_screen import CPSSplashScreen
from ui.login_window import LoginWindow
from ui.main_window import MainWindow
from ui.animations import install_global_animations


class Application:
    def __init__(self):
        self.app = QApplication(sys.argv)
        # Force a consistent look regardless of the OS theme. Without this,
        # Windows dark mode can hand Qt a dark system palette (white text)
        # while our stylesheet still paints white backgrounds -> invisible
        # text on cards, stub pages, dialogs, etc. Fusion + an explicit
        # palette guarantees text is always readable no matter the OS theme.
        self.app.setStyle("Fusion")

        self.db = DatabaseManager()
        theme_mode = self.db.get_setting("theme_mode", "light")
        self._apply_base_palette(theme_mode)
        self._load_stylesheet(theme_mode)
        install_global_animations(self.app)

        self.login_window = None
        self.main_window = None

    def _apply_base_palette(self, theme_mode):
        palette = QPalette()
        if theme_mode == "dark":
            window, base, text, button = "#101826", "#16233A", "#EAF0FA", "#16233A"
        else:
            window, base, text, button = "#F5F8FC", "#FFFFFF", "#10233F", "#FFFFFF"
        palette.setColor(QPalette.Window, QColor(window))
        palette.setColor(QPalette.WindowText, QColor(text))
        palette.setColor(QPalette.Base, QColor(base))
        palette.setColor(QPalette.AlternateBase, QColor(window))
        palette.setColor(QPalette.ToolTipBase, QColor(text))
        palette.setColor(QPalette.ToolTipText, QColor(text))
        palette.setColor(QPalette.Text, QColor(text))
        palette.setColor(QPalette.Button, QColor(button))
        palette.setColor(QPalette.ButtonText, QColor(text))
        palette.setColor(QPalette.BrightText, QColor("#d9453d"))
        palette.setColor(QPalette.Highlight, QColor("#1657A8"))
        palette.setColor(QPalette.HighlightedText, QColor("#FFFFFF"))
        self.app.setPalette(palette)

    def _load_stylesheet(self, theme_mode):
        filename = "style_dark.qss" if theme_mode == "dark" else "style.qss"
        qss_path = Path(__file__).resolve().parent / "resources" / filename
        if qss_path.exists():
            self.app.setStyleSheet(qss_path.read_text(encoding="utf-8"))

    def run(self):
        splash = CPSSplashScreen()
        splash.show()

        steps = [
            (20, "Initializing database..."),
            (55, "Loading modules..."),
            (85, "Preparing interface..."),
            (100, "Ready."),
        ]

        def run_steps():
            if steps:
                value, message = steps.pop(0)
                splash.set_progress(value, message)
                if steps:
                    QTimer.singleShot(300, run_steps)
                else:
                    QTimer.singleShot(300, lambda: self._show_login(splash))

        run_steps()
        sys.exit(self.app.exec())

    def _show_login(self, splash):
        # "Stay logged in on this device?" — check for a saved token before
        # showing the login screen at all.
        remembered = self._try_remembered_login()
        if remembered:
            splash.close()
            self._show_main_window(remembered)
            return

        self.login_window = LoginWindow(self.db)
        self.login_window.login_successful.connect(self._show_main_window)
        self.login_window.show()
        splash.finish(self.login_window)

    def _try_remembered_login(self):
        from PySide6.QtCore import QSettings
        try:
            settings = QSettings("CPS", "CATProgramSystem")
            token = settings.value("remember_token", None)
        except Exception:
            return None
        if not token:
            return None
        try:
            user = self.db.get_user_by_remember_token(token)
        except Exception:
            return None
        return user

    def _show_main_window(self, user):
        if user.get("account_type") == "creator":
            from ui.pages.mcat_dialogs import CreatorDashboard
            dashboard = CreatorDashboard(self.db)
            dashboard.finished.connect(lambda _: self._handle_logout())
            if self.login_window:
                self.login_window.close()
            dashboard.show()
            self.main_window = dashboard
            return

        # If this account is linked to an officer record, logging into the app
        # IS their attendance: clock them in the moment they sign in.
        if user.get("officer_id"):
            self.db.officer_clock_in(user["officer_id"])

        self.main_window = MainWindow(self.db, user)
        self.main_window.logout_requested.connect(self._handle_logout)
        if self.login_window:
            self.login_window.close()
        self.main_window.show()

    def _handle_logout(self):
        self.main_window = None
        self.login_window = LoginWindow(self.db)
        self.login_window.login_successful.connect(self._show_main_window)
        self.login_window.show()


if __name__ == "__main__":
    Application().run()
